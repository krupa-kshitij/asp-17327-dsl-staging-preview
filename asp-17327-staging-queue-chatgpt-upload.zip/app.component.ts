import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MessageService, TreeNode } from 'primeng/api';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { BadgeModule } from 'primeng/badge';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { CheckboxModule } from 'primeng/checkbox';
import { DialogModule } from 'primeng/dialog';
import { DrawerModule } from 'primeng/drawer';
import { FileUploadModule } from 'primeng/fileupload';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { MultiSelectModule } from 'primeng/multiselect';
import { PaginatorModule, PaginatorState } from 'primeng/paginator';
import { AccordionModule } from 'primeng/accordion';
import { PanelModule } from 'primeng/panel';
import { ProgressBarModule } from 'primeng/progressbar';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SelectModule } from 'primeng/select';
import { SkeletonModule } from 'primeng/skeleton';
import { Table, TableModule } from 'primeng/table';
import { TabsModule } from 'primeng/tabs';
import { TagModule } from 'primeng/tag';
import { TextareaModule } from 'primeng/textarea';
import { TimelineModule } from 'primeng/timeline';
import { ToastModule } from 'primeng/toast';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { TreeTableModule } from 'primeng/treetable';

type PageKey =
  | 'substances'
  | 'staging'
  | 'groups'
  | 'closedGroups'
  | 'exemptions'
  | 'lists'
  | 'modules'
  | 'bulk'
  | 'downloads'
  | 'publish'
  | 'preview'
  | 'log';

type Severity = 'success' | 'info' | 'warn' | 'danger' | 'secondary' | 'contrast';
type EditorMode = 'create' | 'edit';
type BulkSubstanceAction = 'export' | 'stage' | 'archive';
type DrawerTab = 'overview' | 'parameters' | 'dependencies' | 'activity';
type GroupViewMode = 'cards' | 'table';
type DslListViewMode = 'cards' | 'table';
type ModuleViewMode = 'cards' | 'table';
type ExemptionSetViewMode = 'cards' | 'table';
type GroupQuickFilter = 'all' | 'drafts' | 'active' | 'most-used' | 'largest';
type GroupDetailTab = 'details' | 'members' | 'subgroups' | 'versions' | 'references' | 'activity';
type ExemptionSetFilter = 'all' | 'drafts' | 'published' | 'expiry-risk' | 'warnings' | 'archived';
type ExemptionSetDetailTab = 'details' | 'exemptions' | 'applicability' | 'references' | 'versions' | 'activity';
type DslListFilter = 'all' | 'drafts' | 'large' | 'custom';
type DslDetailTab = 'details' | 'contents' | 'exemptions' | 'versions' | 'activity';
type ModuleFilter = 'all' | 'drafts' | 'ready' | 'blocked';
type ModuleDetailTab = 'details' | 'components' | 'readiness' | 'versions' | 'activity';
type DslContentKind = 'Substance' | 'Group';
type BulkStep = 'template' | 'upload' | 'validate' | 'review';
type BulkValidationId = 'structure' | 'matching' | 'duplicates' | 'dates' | 'commit';
type BulkReviewActionKey = 'stage' | 'link' | 'alias' | 'create' | 'editDate' | 'defer' | 'reject';
type SubstanceApiStatus = 'Available' | 'Pending validation' | 'Blocked';
type SubstanceReviewIssueKey = 'duplicate' | 'cas-check' | 'ec-check' | 'alias-conflict' | 'staged';
type SubstanceReviewFilter = 'all' | 'needs-review' | 'duplicates' | 'check-digit' | 'alias-conflicts' | 'staged';
type WorkspaceLoadMode = 'page' | 'subpage';
type GroupLoadMode = 'filter' | 'view' | 'search';
type ExportLockState = 'Unlocked' | 'Locked' | 'Committed' | 'Released';
type ExportSourceType = 'DSL' | 'Group' | 'Subgroup';
type ExportFormat = 'CSV' | 'Excel';
type ExportStatus = 'Requested' | 'Generating' | 'Ready' | 'Downloaded' | 'Failed' | 'Retrying' | 'Expired';
type ExemptionLifecycleStatus = 'Published' | 'Draft' | 'Draft add' | 'Draft edit' | 'Expiring soon' | 'Expired' | 'Archived';
type ExemptionWarningKey = 'duplicate-code' | 'threshold-conflict' | 'missing-threshold' | 'missing-applicability' | 'missing-expiry' | 'expired';
type SourceType = 'Supplier input' | 'PubChem' | 'CAS' | 'Third-party integration' | 'Bulk upload';
type DataConfidence = 'High' | 'Medium' | 'Low';
type StagingStatus = 'New' | 'Ready for Review' | 'In Review' | 'Pending Investigation' | 'Approved' | 'Rejected';
type MatchStatus = 'Match Found' | 'No Match' | 'Potential Match' | 'Duplicate Risk' | 'Needs Review';
type MatchType = 'CAS match' | 'EC match' | 'Name match' | 'Alias match' | 'Partial match' | 'No match';
type StagingDetailTab = 'details' | 'candidates' | 'metadata' | 'audit';
type StagingSortOption = 'Newest first' | 'Oldest first' | 'Confidence high to low' | 'Completeness low to high';
type NotificationStatus = 'Not required' | 'Required' | 'Queued' | 'Sent';
type SignoffStatus = 'Not required' | 'Required' | 'Requested' | 'Approved';
type ExistenceCheckState = 'Found' | 'Not found' | 'Warning';
type ParentContextType = 'DSL' | 'Group' | 'Subgroup';
type ArchiveParentFilter = ParentContextType | 'All';
type ImpactSeverity = 'Low' | 'Medium' | 'High' | 'Unknown';
type DataCompleteness = 'Complete' | 'Partial' | 'Unknown';
type ArchiveLifecycleState =
  | 'Active'
  | 'Archive Requested'
  | 'Impact Assessment Generating'
  | 'Impact Assessment Generated'
  | 'Pending Investigation'
  | 'Archive Approved'
  | 'Archived'
  | 'Archive Cancelled';
type ArchiveDecisionValue = 'Proceed with Archive' | 'Delay Archive' | 'Mark Pending Investigation' | 'Cancel';
type ArchiveDetailTab = 'suppliers' | 'customers' | 'match' | 'limitations' | 'audit';

interface NavItem {
  key: PageKey;
  label: string;
  icon: string;
  count?: string;
}

interface PageCopy {
  title: string;
  kicker: string;
  subtitle: string;
}

interface Substance {
  id: string;
  name: string;
  cas: string;
  ec: string;
  authority: string;
  aliases: number;
  aliasNames: string;
  alternativeIds: string;
  source: string;
  created: string;
  status: 'Active' | 'Staged' | 'Archived';
  apiStatus: SubstanceApiStatus;
  reviewIssue?: SubstanceReviewIssue;
  modified: string;
  references: {
    lists: number;
    groups: number;
    materials: number;
  };
}

type SubstanceSeed =
  Omit<Substance, 'aliasNames' | 'alternativeIds' | 'created' | 'apiStatus' | 'reviewIssue'> &
  Partial<Pick<Substance, 'aliasNames' | 'alternativeIds' | 'created' | 'apiStatus' | 'reviewIssue'>>;

interface SubstanceReviewIssue {
  key: SubstanceReviewIssueKey;
  label: string;
  detail: string;
  resolutionSummary: string;
  recommendedAction: string;
  resolutionOptions: string[];
  severity: Severity;
  priority: number;
}

interface SubstanceQuickFilterOption {
  key: SubstanceReviewFilter;
  label: string;
  icon: string;
}

interface GroupQuickFilterOption {
  key: GroupQuickFilter;
  label: string;
  icon: string;
}

interface ExemptionSetQuickFilterOption {
  key: ExemptionSetFilter;
  label: string;
  icon: string;
}

interface SubstanceSkeletonRow {
  id: string;
  loading: true;
}

type SubstanceTableRow = Substance | SubstanceSkeletonRow;

interface GroupSkeletonRow {
  id: string;
  loading: true;
}

type GroupTableRow = SubstanceGroup | GroupSkeletonRow;

interface SupplierContext {
  supplierName: string;
  supplierId: string;
  partNumber: string;
  submissionId: string;
  notificationStatus: NotificationStatus;
}

interface SourceMetadata {
  sourceSystem: string;
  submittedBy: string;
  originalSubmittedName: string;
  originalCAS: string;
  originalEC: string;
  externalReference: string;
  ingestionBatch: string;
  confidenceRating: DataConfidence;
  completenessScore: number;
}

interface StagedSubstance {
  stagedSubstanceId: string;
  substanceName: string;
  CAS: string;
  EC: string;
  aliases: string[];
  source: string;
  sourceType: SourceType;
  dateReceived: string;
  dataConfidence: DataConfidence;
  completenessScore: number;
  stagingStatus: StagingStatus;
  matchStatus: MatchStatus;
  assignedReviewer: string;
  supplierContext?: SupplierContext;
  sourceMetadata: SourceMetadata;
  notificationStatus: NotificationStatus;
  signoffStatus: SignoffStatus;
  decision: 'Approve existing match' | 'Create new substance' | 'Reject substance' | 'Mark pending investigation' | 'Leave unassigned / no action';
  currentLibraryStatus?: string;
}

interface SubstanceLibraryCandidate {
  masterSubstanceId: string;
  stagedSubstanceId: string;
  substanceName: string;
  CAS: string;
  EC: string;
  aliases: string[];
  authority: string;
  source: string;
  matchScore: number;
  matchReason: string;
  matchType: MatchType;
  currentLibraryStatus: string;
  existingDslUsageCount: number;
  lastUpdated: string;
}

interface StagingFilters {
  query: string;
  sourceTypes: SourceType[];
  statuses: StagingStatus[];
  matchStatuses: MatchStatus[];
  confidences: DataConfidence[];
  reviewer: string;
  sort: StagingSortOption;
}

interface StagingAuditEvent {
  id: string;
  user: string;
  dateTime: string;
  action: string;
  stagedSubstanceId: string;
  stagedSubstanceName: string;
  decision: string;
  reason: string;
  beforeAfter: string;
  notes: string;
}

interface CreateSubstanceDraft {
  substanceName: string;
  CAS: string;
  EC: string;
  aliases: string;
  authority: string;
  source: string;
  sourceMetadata: string;
  notes: string;
}

interface ExistenceCheckRow {
  label: string;
  state: ExistenceCheckState;
  detail: string;
  severity: Severity;
}

interface SubstanceGroup {
  id: string;
  name: string;
  description: string;
  members: number;
  dslCount: number;
  version: string;
  status: 'Active' | 'Draft' | 'Closed subset';
  owner: string;
  modified: string;
  created: string;
  lastActivated: string;
  color: string;
  signal?: string;
}

interface GroupMember {
  name: string;
  id: string;
  cas?: string;
  ec?: string;
  threshold?: string;
  effective: string;
  status: 'Active' | 'Pending' | 'Draft add' | 'Draft remove';
  kind: 'Substance' | 'Subgroup';
  children?: Array<{ name: string; cas: string; ec: string }>;
}

interface SubgroupCandidate {
  id: string;
  name: string;
  members: number;
  owner: string;
  version: string;
  safe: boolean;
  reason: string;
}

interface GroupDslReference {
  name: string;
  id: string;
  owner: string;
  version: string;
  status: 'Active' | 'Draft';
  decision: 'Receives draft version' | 'Keeps current version';
}

interface DrawerContext {
  groupName: string;
  groupId: string;
  memberStatus: string;
  effective: string;
  threshold: string;
}

interface DslList {
  id: string;
  name: string;
  description: string;
  authority: string;
  created: string;
  version: string;
  versionNote: string;
  substances: number;
  groups: number;
  exemptionSets: number;
  modules: number;
  status: 'Active' | 'Draft';
  effective: string;
  owner: string;
  scope: 'Standard' | 'Custom';
  modified: string;
}

interface DslContentChild {
  name: string;
  id: string;
  cas?: string;
  ec?: string;
  kind: 'Substance' | 'Subgroup';
}

interface DslContentItem {
  id: string;
  name: string;
  kind: DslContentKind;
  authority: string;
  version?: string;
  cas?: string;
  ec?: string;
  substances?: number;
  groups?: number;
  effective: string;
  inclusion: string;
  internalNote: string;
  externalNote: string;
  status: 'Active' | 'Draft add' | 'Draft remove';
  children?: DslContentChild[];
}

interface ParentContext {
  type: ParentContextType;
  name: string;
  version: string;
  status: string;
  substanceCount: number;
}

interface ArchiveCandidateSubstance {
  substanceId: string;
  substanceName: string;
  CAS: string;
  EC: string;
  aliases: string[];
  status: ArchiveLifecycleState;
  currentLocation: string;
  parentType: ParentContextType;
  parentName: string;
  parentVersion: string;
  parentStatus: string;
  parentSubstanceCount: number;
  groupName: string;
  subgroupName: string;
  lastUpdated: string;
}

interface ImpactAssessment {
  assessmentId: string;
  substanceId: string;
  generatedDate: string;
  generatedBy: string;
  status: ArchiveLifecycleState;
  overallImpactSeverity: ImpactSeverity;
  supplierImpactCount: number;
  customerImpactCount: number;
  declarationCount: number;
  disclosureCount: number;
  matchContext: string;
  dataCompleteness: DataCompleteness;
  assessmentLimitations: string[];
}

interface SupplierImpact {
  assessmentId: string;
  supplierName: string;
  supplierId: string;
  declarationCount: number;
  lastDeclarationDate: string;
  declarationStatus: string;
  matchType: string;
  impactSeverity: ImpactSeverity;
}

interface CustomerImpact {
  assessmentId: string;
  customerName: string;
  customerId: string;
  disclosureCount: number;
  lastDisclosureDate: string;
  affectedDSL: string;
  affectedGroup: string;
  impactSeverity: ImpactSeverity;
}

interface ArchiveMatchContext {
  assessmentId: string;
  matchType: string;
  matchedOn: string[];
  matchConfidence: number;
  CASMatch: boolean;
  ECMatch: boolean;
  aliasMatch: boolean;
  nameMatch: boolean;
  explanation: string;
}

interface ArchiveDecision {
  decisionId: string;
  assessmentId: string;
  decision: ArchiveDecisionValue;
  rationale: string;
  notes: string;
  decidedBy: string;
  decidedDate: string;
}

interface ArchiveAuditEvent {
  user: string;
  dateTime: string;
  action: string;
  object: string;
  impactSeverity: ImpactSeverity;
  decision: ArchiveDecisionValue | 'None';
  rationale: string;
  beforeStatus: ArchiveLifecycleState;
  afterStatus: ArchiveLifecycleState;
}

interface DslExemptionReference {
  code: string;
  name: string;
  exemptions: number;
  authority: string;
  effective: string;
  status: 'Active' | 'Draft add' | 'Draft remove' | 'Expiring';
}

interface DslGroupCandidate {
  id: string;
  name: string;
  members: number;
  owner: string;
  version: string;
  safe: boolean;
  reason: string;
}

interface ModuleRecord {
  id: string;
  name: string;
  description: string;
  list: string;
  listId: string;
  created: string;
  version: string;
  versionNote: string;
  owner: string;
  groups: number;
  exemptionSets: number;
  resources: ModuleResource[];
  customers: number;
  checks: number;
  status: 'Ready' | 'Draft' | 'Blocked';
  impact: string;
  modified: string;
}

interface ModuleResource {
  name: string;
  type: string;
  status: 'Ready' | 'Draft' | 'Missing';
  detail: string;
}

interface ModuleReadinessCheck {
  label: string;
  status: 'Ready' | 'Needs review' | 'Blocked';
  detail: string;
  severity: Severity;
}

interface ExemptionSet {
  code: string;
  name: string;
  description: string;
  authority: string;
  scope: string;
  version: string;
  lastPublishedVersion: string;
  draftVersion: string;
  exemptions: number;
  expiryWatchCount: number;
  status: ExemptionLifecycleStatus;
  owner: string;
  created: string;
  modified: string;
  lastPublished: string;
  publishedBy: string;
  dslReferenceCount: number;
  versionNote: string;
  warnings: ExemptionWarningKey[];
}

interface ExemptionApplicability {
  kind: 'Substance' | 'Group';
  id: string;
  name: string;
  detail: string;
}

interface ExemptionRecord {
  id: string;
  setCode: string;
  code: string;
  description: string;
  thresholdMin: string;
  thresholdMax: string;
  applicability: ExemptionApplicability[];
  expiryDate: string;
  effectiveDate: string;
  status: ExemptionLifecycleStatus;
  notes: string;
  warningKeys: ExemptionWarningKey[];
}

interface ExemptionSetDslReference {
  setCode: string;
  id: string;
  name: string;
  owner: string;
  version: string;
  status: 'Active' | 'Draft';
  impact: string;
}

interface ExemptionSetVersionRecord {
  setCode: string;
  version: string;
  status: 'Current draft' | 'Published' | 'Superseded';
  note: string;
  publishedBy: string;
  publishedDate: string;
  changeSummary: string;
}

interface ActivityItem {
  title: string;
  body: string;
  time: string;
  icon: string;
  severity: Severity;
}

interface SubstanceActivityRecord {
  id: string;
  date: string;
  status: string;
  type: string;
  summary: string;
  rationale: string;
  source: string;
  impact: string;
  user: string;
}

interface ExportJob {
  name: string;
  scope: string;
  format: string;
  status: string;
  surface: PageKey;
  fileId?: string;
  downloadedAt?: string;
  parentId?: string;
  parentName?: string;
  recordCount?: string;
  includedFields?: string;
  lockState?: ExportLockState;
  lockOwner?: string;
}

interface ExportSource {
  sourceId: string;
  sourceType: ExportSourceType;
  sourceName: string;
  parentDSL?: string;
  parentGroup?: string;
  substanceCount: number;
  groupCount: number;
  subgroupCount: number;
  archivedSubstanceCount: number;
  lastUpdated: string;
  version: string;
}

interface ExportSubstance {
  sourceId: string;
  substanceId: string;
  substanceName: string;
  CAS: string;
  EC: string;
  group: string;
  subgroup: string;
  status: 'Active' | 'Archived' | 'Draft';
  lastUpdated: string;
}

interface ExportRequest {
  exportRequestId: string;
  sourceId: string;
  sourceType: ExportSourceType;
  sourceName: string;
  parentDSL?: string;
  parentGroup?: string;
  requestedBy: string;
  requestedDate: string;
  exportFormat: ExportFormat;
  includeArchived: boolean;
  includeMetadata: boolean;
  includeHierarchyColumns: boolean;
  includeExportTimestamp: boolean;
  estimatedRows: number;
  estimatedFileSize: string;
  status: ExportStatus;
  fileName: string;
  rowCount: number;
  downloadedDate?: string;
  generatedDate?: string;
  failureMessage?: string;
  errorDetails?: string;
  notes?: string;
}

interface ExportFile {
  exportFileId: string;
  exportRequestId: string;
  fileName: string;
  fileFormat: ExportFormat;
  rowCount: number;
  generatedDate: string;
  downloadUrl: string;
  status: ExportStatus;
}

interface ExportConfig {
  exportFormat: ExportFormat;
  includeArchived: boolean;
  includeMetadata: boolean;
  includeHierarchyColumns: boolean;
  includeExportTimestamp: boolean;
  notes: string;
  confirmEmptyExport: boolean;
}

interface ExportAuditEvent {
  id: string;
  exportRequestId: string;
  user: string;
  dateTime: string;
  action: 'Export requested' | 'Export generated' | 'Export downloaded' | 'Export failed' | 'Export retried';
  source: string;
  fileName: string;
  status: ExportStatus;
}

interface ExportEstimate {
  rows: number;
  fileSize: string;
  isLarge: boolean;
  isEmpty: boolean;
}

interface BulkWorkflowStep {
  key: BulkStep;
  label: string;
  description: string;
}

interface BulkTemplate {
  id: string;
  label: string;
  scope: string;
  description: string;
  columns: string;
  icon: string;
}

interface BulkValidationCheck {
  id: BulkValidationId;
  label: string;
  detail: string;
  severity: Severity;
  status: string;
  icon: string;
  rows: string;
  evidence: string;
  action: string;
}

interface BulkReviewRow {
  row: string;
  item: string;
  issue: BulkValidationId;
  change: string;
  match: string;
  status: string;
  decision: string;
  severity: Severity;
  evidence: string;
  nextAction: string;
  owner: string;
}

interface BulkReviewActionOption {
  key: BulkReviewActionKey;
  label: string;
  icon: string;
  severity: Severity;
  outlined?: boolean;
}

@Component({
  selector: 'dsl-root',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    AccordionModule,
    AutoCompleteModule,
    BadgeModule,
    ButtonModule,
    CardModule,
    CheckboxModule,
    DialogModule,
    DrawerModule,
    FileUploadModule,
    InputTextModule,
    MessageModule,
    MultiSelectModule,
    PaginatorModule,
    PanelModule,
    ProgressBarModule,
    ProgressSpinnerModule,
    RadioButtonModule,
    SelectModule,
    SkeletonModule,
    TableModule,
    TabsModule,
    TagModule,
    TextareaModule,
    TimelineModule,
    ToastModule,
    ToolbarModule,
    TooltipModule,
    TreeTableModule
  ],
  providers: [MessageService],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit, OnDestroy {
  @ViewChild('substanceTable') substanceTable?: Table;

  readonly libraryNav: NavItem[] = [
    { key: 'substances', label: 'Substances', icon: 'pi pi-sitemap', count: '175k' },
    { key: 'groups', label: 'Groups', icon: 'pi pi-th-large', count: '525' },
    { key: 'exemptions', label: 'Exemption sets', icon: 'pi pi-shield', count: '41' },
    { key: 'lists', label: 'DSL lists', icon: 'pi pi-list-check', count: '84' },
    { key: 'modules', label: 'DSL modules', icon: 'pi pi-box', count: '24' }
  ];

  readonly operationsNav: NavItem[] = [
    { key: 'staging', label: 'Staging queue', icon: 'pi pi-inbox', count: '142' },
    { key: 'bulk', label: 'Bulk upload', icon: 'pi pi-upload', count: '3' },
    { key: 'downloads', label: 'Review exports', icon: 'pi pi-download', count: '6' },
    { key: 'publish', label: 'Deployment queue', icon: 'pi pi-send', count: '5' },
    { key: 'log', label: 'Change log', icon: 'pi pi-history' }
  ];

  readonly pageCopy: Record<PageKey, PageCopy> = {
    substances: {
      title: 'Substances',
      kicker: 'Library',
      subtitle: 'Search and maintain the authoritative substance library used by DSL modules, FMD materials, topic declarations, and ASP APIs. Select a substance to view details, make changes, or address review issues.'
    },
    staging: {
      title: 'Substance Staging & Review',
      kicker: 'Operations',
      subtitle: 'Review incoming substances before promotion to the authoritative Substance Library.'
    },
    groups: {
      title: 'Substance Groups',
      kicker: 'Library',
      subtitle: 'Search reusable groups, edit members or nested subgroups in draft, and choose which DSLs receive the active group version.'
    },
    closedGroups: {
      title: 'Groups',
      kicker: 'Library',
      subtitle: 'Review industry-specific closed subsets while preserving their parent group relationship and usage context.'
    },
    exemptions: {
      title: 'Exemption sets',
      kicker: 'Library',
      subtitle: 'Maintain reusable exemption sets, expiry watches, and applicability rules used by one or more DSL lists.'
    },
    lists: {
      title: 'DSL lists',
      kicker: 'Library',
      subtitle: 'Search governed DSLs, open a list, and manage substances, groups, and exemption sets by reference with effective dates and notes.'
    },
    modules: {
      title: 'DSL modules',
      kicker: 'Library',
      subtitle: 'Create reusable, licensable module packages from active DSL lists, add the required resources, and finalize them as Ready before deployment.'
    },
    bulk: {
      title: 'Bulk upload',
      kicker: 'Operations',
      subtitle: 'Stage templates and scope sheets through validation, matching, reconciliation, and commit review.'
    },
    downloads: {
      title: 'Download Review Exports',
      kicker: 'Operations',
      subtitle: 'Export complete DSL, group, and subgroup substance lists for offline review, collaboration, validation, and reporting.'
    },
    publish: {
      title: 'Deployment queue',
      kicker: 'Operations',
      subtitle: 'Ready module packages wait here before release. Review impact, source-target health, preview, and environment readiness before they go live.'
    },
    preview: {
      title: 'Customer preview',
      kicker: 'Module readiness',
      subtitle: 'Preview what customers will see from module and deployment flows before production release.'
    },
    log: {
      title: 'Change log',
      kicker: 'Operations',
      subtitle: 'Trace who changed what, when, why, and which downstream objects or environments were affected.'
    }
  };

  activePage: PageKey = 'substances';
  selectedExportSource: ExportSource | undefined;
  selectedExportRequest: ExportRequest | undefined;
  exportConfigDialogOpen = false;
  largeExportDialogOpen = false;
  exportGeneratingOpen = false;
  exportReadyOpen = false;
  exportFailedOpen = false;
  exportHistoryOpen = false;
  exportDetailsDrawerOpen = false;
  exportContentQuery = '';
  exportStatusFilter = 'All statuses';
  exportGroupFilter = 'All groups';
  exportSubgroupFilter = 'All subgroups';
  exportHistorySourceTypeFilter = 'All types';
  exportHistoryStatusFilter = 'All statuses';
  exportHistoryRequestedByFilter = 'All users';
  exportHistoryDateRangeFilter = 'All dates';
  exportHistoryFormatFilter = 'All formats';
  isExportContentLoading = false;
  exportConfig: ExportConfig = this.defaultExportConfig();
  stagingFilters: StagingFilters = {
    query: '',
    sourceTypes: [],
    statuses: [],
    matchStatuses: [],
    confidences: [],
    reviewer: 'All reviewers',
    sort: 'Newest first'
  };
  stagingSearchSuggestions: string[] = [];
  activeStagedSubstanceId = 'STG-0001';
  activeCandidateId = 'MS-0042844';
  stagingDetailTab: StagingDetailTab = 'details';
  reviewDrawerOpen = false;
  comparisonDrawerOpen = false;
  rejectDialogOpen = false;
  investigationDialogOpen = false;
  createSubstanceDrawerOpen = false;
  approveMatchDialogOpen = false;
  stagingDialogOpenedFromReview = false;
  isStagingLoading = false;
  matchingServiceAvailable = true;
  approvalAuditNote = '';
  rejectionReason = '';
  rejectionNotes = '';
  rejectionNotifySupplier = false;
  rejectionInternalOnly = false;
  investigationReason = '';
  investigationNotes = '';
  investigationReviewer = '';
  investigationFollowUpDate = '';
  createSubstanceDraft: CreateSubstanceDraft = {
    substanceName: '',
    CAS: '',
    EC: '',
    aliases: '',
    authority: 'Assent',
    source: '',
    sourceMetadata: '',
    notes: ''
  };
  groupViewMode: GroupViewMode = 'cards';
  groupFilter: GroupQuickFilter = 'all';
  groupDetailTab: GroupDetailTab = 'members';
  groupQuery = '';
  activeGroup: SubstanceGroup | undefined;
  exemptionSetViewMode: ExemptionSetViewMode = 'cards';
  exemptionSetFilter: ExemptionSetFilter = 'all';
  exemptionSetDetailTab: ExemptionSetDetailTab = 'exemptions';
  exemptionSetQuery = '';
  activeExemptionSet: ExemptionSet | undefined;
  exemptionSetDialogVisible = false;
  exemptionDialogVisible = false;
  exemptionPublishDialogVisible = false;
  exemptionArchiveDialogVisible = false;
  exemptionSetEditorMode: EditorMode = 'create';
  exemptionEditorMode: EditorMode = 'create';
  exemptionArchiveReason = '';
  exemptionApplicabilityQuery = '';
  dslListViewMode: DslListViewMode = 'cards';
  dslListFilter: DslListFilter = 'all';
  dslListQuery = '';
  dslContentQuery = '';
  activeDslList: DslList | undefined;
  dslDetailTab: DslDetailTab = 'contents';
  moduleViewMode: ModuleViewMode = 'cards';
  moduleFilter: ModuleFilter = 'all';
  moduleQuery = '';
  moduleListQuery = '';
  activeModule: ModuleRecord | undefined;
  moduleDetailTab: ModuleDetailTab = 'components';
  dslAddSubstanceDialogVisible = false;
  dslAddGroupDialogVisible = false;
  dslAddExemptionDialogVisible = false;
  dslActivationDialogVisible = false;
  dslSubstanceQuery = '';
  dslGroupQuery = '';
  dslExemptionQuery = '';
  expandedDslContentIds: string[] = ['GRP-00042'];
  dslContentPageFirst = 0;
  dslContentRows = 4;
  readonly dslContentRowsPerPageOptions = [4, 8, 16];
  selectedDslSubstanceIds: string[] = [];
  selectedDslGroupIds: string[] = [];
  selectedDslExemptionCodes: string[] = [];
  dslEntryEffectiveDate = '2026-06-23';
  dslEntryInclusion = 'Declarable when present above the reporting threshold.';
  dslEntryInternalNote = 'Confirm authority source before activation.';
  dslEntryExternalNote = 'Report this item when it is present or reasonably expected.';
  archiveParentFilter: ArchiveParentFilter = 'DSL';
  archiveSearchQuery = '';
  archiveStatusFilter: ArchiveLifecycleState[] = [];
  archiveGroupFilter: string[] = [];
  archiveImpactFilter: ImpactSeverity[] = [];
  archiveHistorySeverityFilter: ImpactSeverity | 'All' = 'All';
  archiveHistoryDecisionFilter: ArchiveDecisionValue | 'All' = 'All';
  archiveHistoryUserFilter = '';
  archiveHistoryDateFilter = '';
  archiveHistoryParentFilter: ArchiveParentFilter = 'All';
  selectedArchiveSubstance: ArchiveCandidateSubstance | undefined;
  selectedImpactAssessment: ImpactAssessment | undefined;
  archiveRequestDialogOpen = false;
  assessmentGenerating = false;
  assessmentGenerationFailed = false;
  assessmentSummaryOpen = false;
  assessmentDetailOpen = false;
  highImpactDialogOpen = false;
  lowImpactDialogOpen = false;
  missingDataDialogOpen = false;
  pendingInvestigationDialogOpen = false;
  finalDecisionDialogOpen = false;
  archiveCompleteDialogOpen = false;
  assessmentProgress = 0;
  archiveRequestTimestamp = '';
  archiveDetailTab: ArchiveDetailTab = 'suppliers';
  archiveDecisionRationale = '';
  archiveDecisionNotes = '';
  finalArchiveDecision: ArchiveDecisionValue = 'Proceed with Archive';
  archiveInvestigationReason = '';
  archiveInvestigationNotes = '';
  archiveInvestigationReviewer = 'Regulatory Ops';
  archiveInvestigationFollowUpDate = '2026-07-08';
  pendingInvestigationMode: 'Delay Archive' | 'Mark Pending Investigation' = 'Mark Pending Investigation';
  readonly archiveParentTypeOptions: ArchiveParentFilter[] = ['DSL', 'Group', 'Subgroup', 'All'];
  readonly archiveLifecycleOptions: ArchiveLifecycleState[] = [
    'Active',
    'Archive Requested',
    'Impact Assessment Generating',
    'Impact Assessment Generated',
    'Pending Investigation',
    'Archive Approved',
    'Archived',
    'Archive Cancelled'
  ];
  readonly archiveImpactSeverityOptions: ImpactSeverity[] = ['High', 'Medium', 'Low', 'Unknown'];
  readonly archiveDecisionOptions: ArchiveDecisionValue[] = ['Proceed with Archive', 'Delay Archive', 'Mark Pending Investigation', 'Cancel'];
  readonly archiveHistorySeverityOptions: Array<ImpactSeverity | 'All'> = ['All', 'High', 'Medium', 'Low', 'Unknown'];
  readonly archiveHistoryDecisionOptions: Array<ArchiveDecisionValue | 'All'> = ['All', 'Proceed with Archive', 'Delay Archive', 'Mark Pending Investigation', 'Cancel'];
  readonly investigationReasonOptions = [
    'High supplier impact',
    'High customer impact',
    'Missing impact data',
    'Alias-based match ambiguity',
    'Customer disclosure review required',
    'Supplier declaration review required',
    'Regulatory sign-off required',
    'Other'
  ];
  archiveCandidateSubstances: ArchiveCandidateSubstance[] = [
    {
      substanceId: 'ASP-17320-001',
      substanceName: 'Lead monoxide',
      CAS: '1317-36-8',
      EC: '215-267-0',
      aliases: ['Lead(II) oxide', 'Litharge'],
      status: 'Active',
      currentLocation: 'EU RoHS DSL',
      parentType: 'DSL',
      parentName: 'EU RoHS DSL',
      parentVersion: 'v4.1',
      parentStatus: 'Active',
      parentSubstanceCount: 10,
      groupName: 'Lead Compounds',
      subgroupName: 'Inorganic lead oxides',
      lastUpdated: '2026-06-18'
    },
    {
      substanceId: 'ASP-17320-002',
      substanceName: 'Cadmium oxide',
      CAS: '1306-19-0',
      EC: '215-146-2',
      aliases: ['Cadmium monoxide'],
      status: 'Active',
      currentLocation: 'Restricted Metals Group',
      parentType: 'Group',
      parentName: 'Restricted Metals Group',
      parentVersion: 'v5.1',
      parentStatus: 'Active',
      parentSubstanceCount: 16,
      groupName: 'Restricted Metals Group',
      subgroupName: 'Cadmium compounds',
      lastUpdated: '2026-06-12'
    },
    {
      substanceId: 'ASP-17320-003',
      substanceName: 'Chromium VI compound',
      CAS: '',
      EC: '',
      aliases: ['Hexavalent chromium compound', 'Cr(VI) compound'],
      status: 'Active',
      currentLocation: 'Chromium Subgroup',
      parentType: 'Subgroup',
      parentName: 'Chromium Subgroup',
      parentVersion: 'v2.9',
      parentStatus: 'Draft',
      parentSubstanceCount: 9,
      groupName: 'Chromium Compounds Group',
      subgroupName: 'Chromium Subgroup',
      lastUpdated: '2026-06-21'
    },
    {
      substanceId: 'ASP-17320-004',
      substanceName: 'Bisphenol A',
      CAS: '80-05-7',
      EC: '201-245-8',
      aliases: ['BPA', '4,4-isopropylidenediphenol'],
      status: 'Archived',
      currentLocation: 'REACH Candidate DSL',
      parentType: 'DSL',
      parentName: 'REACH Candidate DSL',
      parentVersion: 'v3.0.2',
      parentStatus: 'Draft',
      parentSubstanceCount: 4128,
      groupName: 'Phenols',
      subgroupName: 'Bisphenols',
      lastUpdated: '2026-06-08'
    },
    {
      substanceId: 'ASP-17320-005',
      substanceName: 'Nickel sulfate',
      CAS: '7786-81-4',
      EC: '232-104-9',
      aliases: ['Nickelous sulfate', 'Nickel sulphate'],
      status: 'Active',
      currentLocation: 'Nickel Compounds Group',
      parentType: 'Group',
      parentName: 'Nickel Compounds Group',
      parentVersion: 'v4.4',
      parentStatus: 'Active',
      parentSubstanceCount: 22,
      groupName: 'Nickel Compounds Group',
      subgroupName: 'Soluble nickel salts',
      lastUpdated: '2026-06-17'
    },
    {
      substanceId: 'ASP-17320-006',
      substanceName: 'Lead glass ceramic material',
      CAS: '',
      EC: '',
      aliases: ['Lead glass ceramic', 'Pb glass ceramic matrix'],
      status: 'Pending Investigation',
      currentLocation: 'Lead Compounds Subgroup',
      parentType: 'Subgroup',
      parentName: 'Lead Compounds Subgroup',
      parentVersion: 'v3.7',
      parentStatus: 'Active',
      parentSubstanceCount: 28,
      groupName: 'Lead Compounds',
      subgroupName: 'Lead Compounds Subgroup',
      lastUpdated: '2026-06-10'
    },
    {
      substanceId: 'ASP-17320-007',
      substanceName: 'Phthalate mixture',
      CAS: '',
      EC: '',
      aliases: ['Mixed phthalates', 'Phthalate blend'],
      status: 'Active',
      currentLocation: 'Phthalates Group',
      parentType: 'Group',
      parentName: 'Phthalates Group',
      parentVersion: 'v4.2',
      parentStatus: 'Active',
      parentSubstanceCount: 6,
      groupName: 'Phthalates Group',
      subgroupName: 'Long-chain Phthalates',
      lastUpdated: '2026-06-22'
    },
    {
      substanceId: 'ASP-17320-008',
      substanceName: 'Mercury compound',
      CAS: '7439-97-6',
      EC: '231-106-7',
      aliases: ['Mercury', 'Hydrargyrum'],
      status: 'Active',
      currentLocation: 'Global Restricted DSL',
      parentType: 'DSL',
      parentName: 'Global Restricted DSL',
      parentVersion: 'v6.0',
      parentStatus: 'Active',
      parentSubstanceCount: 248,
      groupName: 'Heavy Metals',
      subgroupName: 'Mercury compounds',
      lastUpdated: '2026-06-19'
    }
  ];
  impactAssessments: ImpactAssessment[] = [
    {
      assessmentId: 'AIA-17320-001',
      substanceId: 'ASP-17320-001',
      generatedDate: '2026-07-01 09:10',
      generatedBy: 'Maya Chen',
      status: 'Impact Assessment Generated',
      overallImpactSeverity: 'High',
      supplierImpactCount: 6,
      customerImpactCount: 4,
      declarationCount: 42,
      disclosureCount: 18,
      matchContext: 'CAS match',
      dataCompleteness: 'Complete',
      assessmentLimitations: []
    },
    {
      assessmentId: 'AIA-17320-002',
      substanceId: 'ASP-17320-002',
      generatedDate: '2026-07-01 09:12',
      generatedBy: 'Maya Chen',
      status: 'Impact Assessment Generated',
      overallImpactSeverity: 'Medium',
      supplierImpactCount: 3,
      customerImpactCount: 2,
      declarationCount: 12,
      disclosureCount: 7,
      matchContext: 'CAS + EC match',
      dataCompleteness: 'Complete',
      assessmentLimitations: []
    },
    {
      assessmentId: 'AIA-17320-003',
      substanceId: 'ASP-17320-003',
      generatedDate: '2026-07-01 09:14',
      generatedBy: 'Maya Chen',
      status: 'Impact Assessment Generated',
      overallImpactSeverity: 'Unknown',
      supplierImpactCount: 0,
      customerImpactCount: 0,
      declarationCount: 0,
      disclosureCount: 0,
      matchContext: 'Alias match',
      dataCompleteness: 'Unknown',
      assessmentLimitations: ['Missing historical declaration data', 'Incomplete customer disclosure references', 'Unknown match basis']
    },
    {
      assessmentId: 'AIA-17320-004',
      substanceId: 'ASP-17320-004',
      generatedDate: '2026-06-28 15:20',
      generatedBy: 'Regulatory Ops',
      status: 'Archived',
      overallImpactSeverity: 'Low',
      supplierImpactCount: 1,
      customerImpactCount: 0,
      declarationCount: 1,
      disclosureCount: 0,
      matchContext: 'CAS match',
      dataCompleteness: 'Complete',
      assessmentLimitations: []
    },
    {
      assessmentId: 'AIA-17320-005',
      substanceId: 'ASP-17320-005',
      generatedDate: '2026-07-01 09:18',
      generatedBy: 'Maya Chen',
      status: 'Impact Assessment Generated',
      overallImpactSeverity: 'High',
      supplierImpactCount: 8,
      customerImpactCount: 5,
      declarationCount: 55,
      disclosureCount: 21,
      matchContext: 'Alias + CAS match',
      dataCompleteness: 'Complete',
      assessmentLimitations: ['Alias-based match should be reviewed because supplier labels vary by spelling.']
    },
    {
      assessmentId: 'AIA-17320-006',
      substanceId: 'ASP-17320-006',
      generatedDate: '2026-06-29 11:04',
      generatedBy: 'Regulatory Ops',
      status: 'Pending Investigation',
      overallImpactSeverity: 'Medium',
      supplierImpactCount: 2,
      customerImpactCount: 2,
      declarationCount: 9,
      disclosureCount: 5,
      matchContext: 'Name match',
      dataCompleteness: 'Partial',
      assessmentLimitations: ['Archived DSL references not included', 'Name-only match requires reviewer confirmation']
    },
    {
      assessmentId: 'AIA-17320-007',
      substanceId: 'ASP-17320-007',
      generatedDate: '2026-07-01 09:22',
      generatedBy: 'Maya Chen',
      status: 'Impact Assessment Generated',
      overallImpactSeverity: 'Unknown',
      supplierImpactCount: 1,
      customerImpactCount: 1,
      declarationCount: 0,
      disclosureCount: 0,
      matchContext: 'Alias match',
      dataCompleteness: 'Partial',
      assessmentLimitations: ['Supplier impact data is partial', 'Customer impact data is partial', 'Alias-based match ambiguity']
    },
    {
      assessmentId: 'AIA-17320-008',
      substanceId: 'ASP-17320-008',
      generatedDate: '2026-07-01 09:24',
      generatedBy: 'Maya Chen',
      status: 'Impact Assessment Generated',
      overallImpactSeverity: 'Low',
      supplierImpactCount: 0,
      customerImpactCount: 1,
      declarationCount: 0,
      disclosureCount: 1,
      matchContext: 'CAS match',
      dataCompleteness: 'Complete',
      assessmentLimitations: []
    }
  ];
  supplierImpacts: SupplierImpact[] = [
    { assessmentId: 'AIA-17320-001', supplierName: 'Apex Components', supplierId: 'SUP-01842', declarationCount: 18, lastDeclarationDate: '2026-06-11', declarationStatus: 'Active', matchType: 'CAS match', impactSeverity: 'High' },
    { assessmentId: 'AIA-17320-001', supplierName: 'Northstar Electronics', supplierId: 'SUP-00675', declarationCount: 12, lastDeclarationDate: '2026-05-28', declarationStatus: 'Active', matchType: 'CAS match', impactSeverity: 'High' },
    { assessmentId: 'AIA-17320-001', supplierName: 'Galen Materials', supplierId: 'SUP-02601', declarationCount: 12, lastDeclarationDate: '2026-04-30', declarationStatus: 'Submitted', matchType: 'CAS match', impactSeverity: 'Medium' },
    { assessmentId: 'AIA-17320-002', supplierName: 'Terra Metals', supplierId: 'SUP-01004', declarationCount: 7, lastDeclarationDate: '2026-06-06', declarationStatus: 'Active', matchType: 'CAS + EC match', impactSeverity: 'Medium' },
    { assessmentId: 'AIA-17320-002', supplierName: 'Mira Industrial', supplierId: 'SUP-01428', declarationCount: 5, lastDeclarationDate: '2026-03-19', declarationStatus: 'Accepted', matchType: 'CAS match', impactSeverity: 'Low' },
    { assessmentId: 'AIA-17320-003', supplierName: 'Unknown supplier impact', supplierId: 'SUP-UNKNOWN', declarationCount: 0, lastDeclarationDate: 'Unknown', declarationStatus: 'Missing impact data', matchType: 'Alias match', impactSeverity: 'Unknown' },
    { assessmentId: 'AIA-17320-004', supplierName: 'Polymer Source Co.', supplierId: 'SUP-03112', declarationCount: 1, lastDeclarationDate: '2025-11-08', declarationStatus: 'Historical', matchType: 'CAS match', impactSeverity: 'Low' },
    { assessmentId: 'AIA-17320-005', supplierName: 'Helio Plating', supplierId: 'SUP-00491', declarationCount: 22, lastDeclarationDate: '2026-06-16', declarationStatus: 'Active', matchType: 'Alias + CAS match', impactSeverity: 'High' },
    { assessmentId: 'AIA-17320-005', supplierName: 'Boreal Parts', supplierId: 'SUP-00987', declarationCount: 17, lastDeclarationDate: '2026-06-02', declarationStatus: 'Active', matchType: 'CAS match', impactSeverity: 'High' },
    { assessmentId: 'AIA-17320-005', supplierName: 'Vertex Hardware', supplierId: 'SUP-02071', declarationCount: 16, lastDeclarationDate: '2026-05-19', declarationStatus: 'In review', matchType: 'Alias match', impactSeverity: 'Medium' },
    { assessmentId: 'AIA-17320-006', supplierName: 'CeramicWorks', supplierId: 'SUP-03314', declarationCount: 5, lastDeclarationDate: '2026-02-10', declarationStatus: 'Accepted', matchType: 'Name match', impactSeverity: 'Medium' },
    { assessmentId: 'AIA-17320-006', supplierName: 'GlassTech EU', supplierId: 'SUP-04155', declarationCount: 4, lastDeclarationDate: 'Unknown', declarationStatus: 'Historical data partial', matchType: 'Name match', impactSeverity: 'Unknown' },
    { assessmentId: 'AIA-17320-007', supplierName: 'Supplier impact partially indexed', supplierId: 'SUP-PARTIAL', declarationCount: 0, lastDeclarationDate: 'Unknown', declarationStatus: 'Partial', matchType: 'Alias match', impactSeverity: 'Unknown' }
  ];
  customerImpacts: CustomerImpact[] = [
    { assessmentId: 'AIA-17320-001', customerName: 'Meridian Mobility', customerId: 'CUS-1007', disclosureCount: 8, lastDisclosureDate: '2026-06-15', affectedDSL: 'EU RoHS DSL', affectedGroup: 'Lead Compounds', impactSeverity: 'High' },
    { assessmentId: 'AIA-17320-001', customerName: 'Atlas Controls', customerId: 'CUS-0442', disclosureCount: 5, lastDisclosureDate: '2026-05-21', affectedDSL: 'EU RoHS DSL', affectedGroup: 'Lead Compounds', impactSeverity: 'Medium' },
    { assessmentId: 'AIA-17320-001', customerName: 'Nova Devices', customerId: 'CUS-0370', disclosureCount: 5, lastDisclosureDate: '2026-05-02', affectedDSL: 'Global Restricted DSL', affectedGroup: 'Heavy Metals', impactSeverity: 'High' },
    { assessmentId: 'AIA-17320-002', customerName: 'Kinetic Tools', customerId: 'CUS-0810', disclosureCount: 4, lastDisclosureDate: '2026-04-16', affectedDSL: 'REACH Restricted DSL', affectedGroup: 'Restricted Metals Group', impactSeverity: 'Medium' },
    { assessmentId: 'AIA-17320-002', customerName: 'Omni Manufacturing', customerId: 'CUS-0194', disclosureCount: 3, lastDisclosureDate: '2026-03-22', affectedDSL: 'Global Restricted DSL', affectedGroup: 'Restricted Metals Group', impactSeverity: 'Low' },
    { assessmentId: 'AIA-17320-003', customerName: 'Unknown customer impact', customerId: 'CUS-UNKNOWN', disclosureCount: 0, lastDisclosureDate: 'Unknown', affectedDSL: 'Chromium review list', affectedGroup: 'Chromium Subgroup', impactSeverity: 'Unknown' },
    { assessmentId: 'AIA-17320-005', customerName: 'Quantum Appliances', customerId: 'CUS-0555', disclosureCount: 9, lastDisclosureDate: '2026-06-12', affectedDSL: 'Global Restricted DSL', affectedGroup: 'Nickel Compounds Group', impactSeverity: 'High' },
    { assessmentId: 'AIA-17320-005', customerName: 'Helix Medical', customerId: 'CUS-0729', disclosureCount: 6, lastDisclosureDate: '2026-05-29', affectedDSL: 'REACH Candidate DSL', affectedGroup: 'Nickel Compounds Group', impactSeverity: 'High' },
    { assessmentId: 'AIA-17320-005', customerName: 'Wayline Systems', customerId: 'CUS-0128', disclosureCount: 6, lastDisclosureDate: '2026-05-04', affectedDSL: 'California Prop 65', affectedGroup: 'Nickel Compounds Group', impactSeverity: 'Medium' },
    { assessmentId: 'AIA-17320-006', customerName: 'Artisan Ceramics', customerId: 'CUS-0633', disclosureCount: 3, lastDisclosureDate: '2026-02-28', affectedDSL: 'EU RoHS DSL', affectedGroup: 'Lead Compounds Subgroup', impactSeverity: 'Medium' },
    { assessmentId: 'AIA-17320-006', customerName: 'Futura Displays', customerId: 'CUS-0901', disclosureCount: 2, lastDisclosureDate: 'Unknown', affectedDSL: 'Archived RoHS Variant', affectedGroup: 'Lead Compounds Subgroup', impactSeverity: 'Unknown' },
    { assessmentId: 'AIA-17320-007', customerName: 'Customer impact partially indexed', customerId: 'CUS-PARTIAL', disclosureCount: 0, lastDisclosureDate: 'Unknown', affectedDSL: 'REACH Candidate DSL', affectedGroup: 'Phthalates Group', impactSeverity: 'Unknown' },
    { assessmentId: 'AIA-17320-008', customerName: 'Atlas Controls', customerId: 'CUS-0442', disclosureCount: 1, lastDisclosureDate: '2025-12-14', affectedDSL: 'Global Restricted DSL', affectedGroup: 'Heavy Metals', impactSeverity: 'Low' }
  ];
  matchContexts: ArchiveMatchContext[] = [
    { assessmentId: 'AIA-17320-001', matchType: 'CAS match', matchedOn: ['CAS'], matchConfidence: 99, CASMatch: true, ECMatch: false, aliasMatch: false, nameMatch: false, explanation: 'This substance appears in downstream records because it was matched using CAS 1317-36-8.' },
    { assessmentId: 'AIA-17320-002', matchType: 'CAS + EC match', matchedOn: ['CAS', 'EC'], matchConfidence: 98, CASMatch: true, ECMatch: true, aliasMatch: false, nameMatch: false, explanation: 'This substance appears in downstream records because it was matched using CAS 1306-19-0 and EC 215-146-2.' },
    { assessmentId: 'AIA-17320-003', matchType: 'Alias match', matchedOn: ['Alias'], matchConfidence: 54, CASMatch: false, ECMatch: false, aliasMatch: true, nameMatch: false, explanation: 'This substance appears in downstream records because it was matched using chromium VI aliases. Alias-only matches may be ambiguous.' },
    { assessmentId: 'AIA-17320-004', matchType: 'CAS match', matchedOn: ['CAS'], matchConfidence: 99, CASMatch: true, ECMatch: false, aliasMatch: false, nameMatch: false, explanation: 'This substance appears in downstream records because it was matched using CAS 80-05-7.' },
    { assessmentId: 'AIA-17320-005', matchType: 'Alias + CAS match', matchedOn: ['CAS', 'Alias'], matchConfidence: 91, CASMatch: true, ECMatch: false, aliasMatch: true, nameMatch: false, explanation: 'This substance appears in downstream records because it was matched using CAS 7786-81-4 and supplier aliases for nickel sulphate.' },
    { assessmentId: 'AIA-17320-006', matchType: 'Name match', matchedOn: ['Name'], matchConfidence: 72, CASMatch: false, ECMatch: false, aliasMatch: false, nameMatch: true, explanation: 'This substance appears in downstream records because it was matched using the material name. No CAS or EC identifier was available.' },
    { assessmentId: 'AIA-17320-007', matchType: 'Alias match', matchedOn: ['Alias'], matchConfidence: 49, CASMatch: false, ECMatch: false, aliasMatch: true, nameMatch: false, explanation: 'This substance appears in downstream records because it was matched using mixture aliases. Alias-only matches may combine multiple phthalate records.' },
    { assessmentId: 'AIA-17320-008', matchType: 'CAS match', matchedOn: ['CAS'], matchConfidence: 99, CASMatch: true, ECMatch: false, aliasMatch: false, nameMatch: false, explanation: 'This substance appears in downstream records because it was matched using CAS 7439-97-6.' }
  ];
  archiveDecisions: ArchiveDecision[] = [
    {
      decisionId: 'ADEC-17320-004',
      assessmentId: 'AIA-17320-004',
      decision: 'Proceed with Archive',
      rationale: 'Only one historical supplier declaration remained and no customer disclosures were active.',
      notes: 'Archived from REACH Candidate DSL after low-impact confirmation.',
      decidedBy: 'Regulatory Ops',
      decidedDate: '2026-06-28 15:32'
    },
    {
      decisionId: 'ADEC-17320-006',
      assessmentId: 'AIA-17320-006',
      decision: 'Mark Pending Investigation',
      rationale: 'Name-only match and archived DSL references require confirmation before archive.',
      notes: 'Assigned to Regulatory Ops for source review.',
      decidedBy: 'Maya Chen',
      decidedDate: '2026-06-29 11:17'
    }
  ];
  archiveAuditEvents: ArchiveAuditEvent[] = [
    { user: 'Regulatory Ops', dateTime: '2026-06-28 15:20', action: 'Impact assessment generated', object: 'Bisphenol A', impactSeverity: 'Low', decision: 'None', rationale: 'Generated before archival decision.', beforeStatus: 'Archive Requested', afterStatus: 'Impact Assessment Generated' },
    { user: 'Regulatory Ops', dateTime: '2026-06-28 15:32', action: 'Archive completed', object: 'Bisphenol A', impactSeverity: 'Low', decision: 'Proceed with Archive', rationale: 'Only one historical supplier declaration remained and no customer disclosures were active.', beforeStatus: 'Archive Approved', afterStatus: 'Archived' },
    { user: 'Maya Chen', dateTime: '2026-06-29 11:04', action: 'Impact assessment generated', object: 'Lead glass ceramic material', impactSeverity: 'Medium', decision: 'None', rationale: 'Generated before archival decision.', beforeStatus: 'Archive Requested', afterStatus: 'Impact Assessment Generated' },
    { user: 'Maya Chen', dateTime: '2026-06-29 11:17', action: 'Pending investigation marked', object: 'Lead glass ceramic material', impactSeverity: 'Medium', decision: 'Mark Pending Investigation', rationale: 'Name-only match and archived DSL references require confirmation before archive.', beforeStatus: 'Impact Assessment Generated', afterStatus: 'Pending Investigation' }
  ];
  sidebarCollapsed = false;
  isWorkspaceLoading = false;
  workspaceLoadMode: WorkspaceLoadMode = 'page';
  substanceQuery = '';
  isSubstanceLoading = false;
  hasLoadedSubstanceIndex = false;
  substanceLoadMode: 'initial' | 'server-search' = 'initial';
  substanceServiceQuery = '';
  substanceServerResults: Substance[] = [];
  selectedSubstances: Substance[] = [];
  substanceReviewFilter: SubstanceReviewFilter = 'all';
  activeSubstance: Substance;
  editDrawerVisible = false;
  archiveDialogVisible = false;
  groupPublishDialogVisible = false;
  groupAddSubstanceDialogVisible = false;
  subgroupCheckDialogVisible = false;
  publishDialogVisible = false;
  editorMode: EditorMode = 'edit';
  drawerTab: DrawerTab = 'overview';
  drawerContext: DrawerContext | undefined;
  activityQuery = '';
  activityStatus = 'All';
  editorDraft: Substance = {
    id: '',
    name: '',
    cas: '',
    ec: '',
    authority: 'ECHA',
    aliases: 0,
    aliasNames: '',
    alternativeIds: '',
    source: 'Assent',
    created: 'Draft',
    status: 'Active',
    apiStatus: 'Pending validation',
    modified: 'Draft',
    references: { lists: 0, groups: 0, materials: 0 }
  };
  editorRationale = '';
  lastChangeSummary = 'No pending substance changes';
  startupWarning = '';
  selectedGroupStatus = 'Draft v4.3';
  versionNote = 'Adding DBP per ECHA bulletin 2026-05-12. Lifecycle impact requires review before activation.';
  groupDefaultThreshold = '0.1%';
  groupDefaultEffectiveDate = '2026-05-22';
  groupSourceNote = 'Source review pending';
  groupSubstanceQuery = '';
  selectedGroupSubstanceIds: string[] = [];
  groupMemberThreshold = '0.1%';
  groupMemberEffectiveDate = '2026-05-22';
  subgroupQuery = '';
  selectedSubgroupIds: string[] = [];
  exemptionSetDraft: ExemptionSet = {
    code: '',
    name: '',
    description: '',
    authority: 'ECHA',
    scope: '',
    version: 'Draft v1.0',
    lastPublishedVersion: 'Not published yet',
    draftVersion: 'v1.0',
    exemptions: 0,
    expiryWatchCount: 0,
    status: 'Draft',
    owner: 'Regulatory',
    created: 'Today',
    modified: 'Just now',
    lastPublished: 'Not published yet',
    publishedBy: 'Not published yet',
    dslReferenceCount: 0,
    versionNote: 'New exemption set draft. Add a version note before publish.',
    warnings: []
  };
  activeExemptionDraft: ExemptionRecord = {
    id: '',
    setCode: '',
    code: '',
    description: '',
    thresholdMin: '',
    thresholdMax: '',
    applicability: [],
    expiryDate: '',
    effectiveDate: '2026-06-25',
    status: 'Draft add',
    notes: '',
    warningKeys: []
  };
  bulkStep: BulkStep = 'template';
  selectedBulkTemplateId = '';
  bulkUploadFileName = '';
  bulkDetectedType = '';
  bulkValidationReady = false;
  bulkReviewCommitted = false;
  expandedBulkValidationId: BulkValidationId | undefined;
  activeBulkReviewFilter: BulkValidationId | 'all' = 'all';
  activeBulkReviewRowId = '12';
  bulkDecisionDrawerVisible = false;
  isGroupLoading = false;
  groupLoadMode: GroupLoadMode = 'filter';
  readonly substancePageSize = 18;
  readonly substanceRowsPerPageOptions = [18, 36, 72];
  readonly substanceSkeletonRows: SubstanceSkeletonRow[] = Array.from({ length: this.substancePageSize }, (_, index) => ({
    id: `substance-skeleton-${index}`,
    loading: true
  }));
  readonly groupSkeletonRows: GroupSkeletonRow[] = Array.from({ length: 6 }, (_, index) => ({
    id: `group-skeleton-${index}`,
    loading: true
  }));
  readonly substanceReviewFilters: SubstanceQuickFilterOption[] = [
    { key: 'all', label: 'All', icon: 'pi pi-list' },
    { key: 'needs-review', label: 'Needs review', icon: 'pi pi-exclamation-triangle' },
    { key: 'duplicates', label: 'Duplicates', icon: 'pi pi-copy' },
    { key: 'check-digit', label: 'Check-digit', icon: 'pi pi-verified' },
    { key: 'alias-conflicts', label: 'Alias conflicts', icon: 'pi pi-link' },
    { key: 'staged', label: 'Staged', icon: 'pi pi-inbox' }
  ];
  readonly groupQuickFilters: GroupQuickFilterOption[] = [
    { key: 'all', label: 'All', icon: 'pi pi-list' },
    { key: 'drafts', label: 'Drafts', icon: 'pi pi-pencil' },
    { key: 'active', label: 'Active', icon: 'pi pi-check-circle' },
    { key: 'most-used', label: 'Most used', icon: 'pi pi-chart-line' },
    { key: 'largest', label: 'Largest', icon: 'pi pi-database' }
  ];
  readonly exemptionSetQuickFilters: ExemptionSetQuickFilterOption[] = [
    { key: 'all', label: 'All', icon: 'pi pi-list' },
    { key: 'drafts', label: 'Drafts', icon: 'pi pi-pencil' },
    { key: 'published', label: 'Published', icon: 'pi pi-check-circle' },
    { key: 'expiry-risk', label: 'Expiry risk', icon: 'pi pi-clock' },
    { key: 'warnings', label: 'Warnings', icon: 'pi pi-exclamation-triangle' },
    { key: 'archived', label: 'Archived', icon: 'pi pi-archive' }
  ];
  readonly stagingStatusOptions: StagingStatus[] = ['New', 'Ready for Review', 'In Review', 'Pending Investigation', 'Approved', 'Rejected'];
  readonly matchStatusOptions: MatchStatus[] = ['Match Found', 'No Match', 'Potential Match', 'Duplicate Risk', 'Needs Review'];
  readonly sourceTypeOptions: SourceType[] = ['Supplier input', 'PubChem', 'CAS', 'Third-party integration', 'Bulk upload'];
  readonly confidenceOptions: DataConfidence[] = ['High', 'Medium', 'Low'];
  readonly reviewerOptions = ['All reviewers', 'Unassigned', 'You', 'Emma Chen', 'Regulatory Ops', 'Maya Singh', 'Assentee QA'];
  readonly assignmentReviewerOptions = this.reviewerOptions.filter((reviewer) => reviewer !== 'All reviewers');
  readonly stagingSortOptions: StagingSortOption[] = ['Newest first', 'Oldest first', 'Confidence high to low', 'Completeness low to high'];
  readonly rejectionReasons = ['Invalid CAS', 'Invalid EC', 'Duplicate substance', 'Incomplete data', 'Not a substance', 'Unsupported source', 'Supplier entry error', 'Other'];
  readonly investigationReasons = ['Ambiguous match', 'Missing CAS', 'Missing EC', 'Name-only record', 'Supplier clarification needed', 'Source conflict', 'Regulatory sign-off needed', 'Other'];
  readonly candidateComparisonFields = ['Substance name', 'CAS', 'EC', 'Aliases', 'Source / Authority', 'Match score', 'Match reason', 'Match type', 'Existing DSL usage count', 'Last updated'];
  readonly stagingSkeletonRows = Array.from({ length: 6 }, (_, index) => ({ stagedSubstanceId: `staging-skeleton-${index}` }));
  readonly dependencyListExamples = ['REACH SVHC', 'EU RoHS Directive', 'California Prop 65'];
  readonly dependencyGroupExamples = ['Heavy Metals', 'Restricted Substances', 'Battery substances'];
  private readonly reviewIssueBySubstanceIndex = new Map<number, SubstanceReviewIssueKey>([
    [0, 'duplicate'],
    [2, 'cas-check'],
    [4, 'alias-conflict'],
    [5, 'staged'],
    [6, 'ec-check'],
    [8, 'duplicate'],
    [10, 'cas-check'],
    [11, 'staged'],
    [12, 'alias-conflict'],
    [14, 'duplicate'],
    [16, 'cas-check'],
    [18, 'ec-check'],
    [20, 'alias-conflict'],
    [22, 'duplicate'],
    [24, 'cas-check'],
    [26, 'ec-check'],
    [28, 'alias-conflict'],
    [30, 'duplicate'],
    [32, 'staged'],
    [34, 'cas-check'],
    [36, 'ec-check'],
    [38, 'alias-conflict'],
    [40, 'duplicate'],
    [42, 'cas-check'],
    [44, 'ec-check'],
    [46, 'alias-conflict'],
    [50, 'duplicate']
  ]);
  private substanceLoadTimer: ReturnType<typeof setTimeout> | undefined;
  private groupLoadTimer: ReturnType<typeof setTimeout> | undefined;
  private workspaceLoadTimer: ReturnType<typeof setTimeout> | undefined;
  private assessmentGenerationTimer: ReturnType<typeof setInterval> | undefined;
  private exportSequence = 221;

  readonly substances: Substance[] = [
    ...([
    { id: 'MS-0042819', name: 'Cadmium', cas: '7440-43-9', ec: '231-152-8', authority: 'ECHA', aliases: 3, source: 'Assent', status: 'Active', modified: '2d ago', references: { lists: 9, groups: 14, materials: 427 } },
    { id: 'MS-0042820', name: 'Lead', cas: '7439-92-1', ec: '231-100-4', authority: 'ECHA', aliases: 5, source: 'Assent', status: 'Active', modified: '3d ago', references: { lists: 12, groups: 18, materials: 612 } },
    { id: 'MS-0042821', name: 'Mercury', cas: '7439-97-6', ec: '231-106-7', authority: 'ECHA', aliases: 2, source: 'Assent', status: 'Active', modified: '5d ago', references: { lists: 11, groups: 9, materials: 301 } },
    { id: 'MS-0042822', name: 'Bis(2-ethylhexyl) phthalate', cas: '117-81-7', ec: '204-211-0', authority: 'ECHA', aliases: 7, source: 'Assent', status: 'Active', modified: '1w ago', references: { lists: 12, groups: 3, materials: 908 } },
    { id: 'MS-0042823', name: 'Benzyl butyl phthalate', cas: '85-68-7', ec: '201-622-7', authority: 'ECHA', aliases: 4, source: 'Assent', status: 'Active', modified: '1w ago', references: { lists: 12, groups: 2, materials: 517 } },
    { id: 'MS-0042824', name: 'Dibutyl phthalate', cas: '84-74-2', ec: '201-557-4', authority: 'ECHA', aliases: 3, source: 'ECHA import', status: 'Staged', modified: 'today', references: { lists: 0, groups: 1, materials: 0 } },
    { id: 'MS-0042825', name: 'Perfluorooctanoic acid', cas: '335-67-1', ec: '206-397-9', authority: 'ECHA, EPA', aliases: 6, source: 'EPA', status: 'Active', modified: '2w ago', references: { lists: 16, groups: 24, materials: 1216 } },
    { id: 'MS-0042826', name: 'Perfluorooctane sulfonic acid', cas: '1763-23-1', ec: '217-179-8', authority: 'ECHA, EPA', aliases: 5, source: 'EPA', status: 'Active', modified: '3w ago', references: { lists: 17, groups: 24, materials: 1107 } },
    { id: 'MS-0042827', name: 'Hexabromocyclododecane', cas: '25637-99-4', ec: '247-148-4', authority: 'ECHA', aliases: 8, source: 'ECHA import', status: 'Active', modified: '1mo ago', references: { lists: 7, groups: 4, materials: 233 } },
    { id: 'MS-0042828', name: 'Short-chain chlorinated paraffins', cas: '85535-84-8', ec: '287-476-5', authority: 'ECHA, POPs', aliases: 6, source: 'Assent', status: 'Active', modified: '1mo ago', references: { lists: 10, groups: 5, materials: 489 } },
    { id: 'MS-0042829', name: 'Tetrabromobisphenol A', cas: '79-94-7', ec: '201-236-9', authority: 'ECHA', aliases: 4, source: 'Assent', status: 'Active', modified: '1mo ago', references: { lists: 8, groups: 3, materials: 351 } },
    { id: 'MS-0042830', name: 'Tris(2-chloroethyl) phosphate', cas: '115-96-8', ec: '204-118-5', authority: 'ECHA', aliases: 5, source: 'ECHA import', status: 'Staged', modified: 'yesterday', references: { lists: 1, groups: 2, materials: 16 } },
    { id: 'MS-0042831', name: 'Decabromodiphenyl ether', cas: '1163-19-5', ec: '214-604-9', authority: 'ECHA, EPA', aliases: 7, source: 'EPA', status: 'Active', modified: '2mo ago', references: { lists: 13, groups: 8, materials: 742 } },
    { id: 'MS-0042832', name: 'Naphthalene', cas: '91-20-3', ec: '202-049-5', authority: 'ECHA, EPA', aliases: 2, source: 'Assent', status: 'Active', modified: '2mo ago', references: { lists: 5, groups: 2, materials: 188 } },
    { id: 'MS-0042833', name: 'Formaldehyde', cas: '50-00-0', ec: '200-001-8', authority: 'ECHA, EPA', aliases: 9, source: 'Assent', status: 'Active', modified: '3mo ago', references: { lists: 15, groups: 11, materials: 934 } },
    { id: 'MS-0042834', name: 'Diisobutyl phthalate', cas: '84-69-5', ec: '201-553-2', authority: 'ECHA', aliases: 3, source: 'ECHA import', status: 'Active', modified: '3mo ago', references: { lists: 11, groups: 3, materials: 405 } },
    { id: 'MS-0042835', name: 'Anthracene', cas: '120-12-7', ec: '204-371-1', authority: 'ECHA', aliases: 2, source: 'Assent', status: 'Active', modified: '3mo ago', references: { lists: 4, groups: 1, materials: 122 } },
    { id: 'MS-0042836', name: 'Chromium trioxide', cas: '1333-82-0', ec: '215-607-8', authority: 'ECHA', aliases: 4, source: 'Assent', status: 'Active', modified: '4mo ago', references: { lists: 14, groups: 10, materials: 658 } }
    ] as SubstanceSeed[]).map((substance, index) => this.withSubstanceGovernance(substance, index)),
    ...this.createIndexedSubstanceRows()
  ];

  readonly stagedSubstances: StagedSubstance[] = [
    {
      stagedSubstanceId: 'STG-0001',
      substanceName: 'Lead monoxide',
      CAS: '1317-36-8',
      EC: '215-267-0',
      aliases: ['Lead(II) oxide', 'Litharge', 'Massicot'],
      source: 'PubChem',
      sourceType: 'PubChem',
      dateReceived: '2026-06-30',
      dataConfidence: 'High',
      completenessScore: 96,
      stagingStatus: 'Ready for Review',
      matchStatus: 'Match Found',
      assignedReviewer: 'Unassigned',
      notificationStatus: 'Not required',
      signoffStatus: 'Not required',
      decision: 'Leave unassigned / no action',
      currentLibraryStatus: 'Active',
      sourceMetadata: {
        sourceSystem: 'PubChem PUG-View',
        submittedBy: 'Automated intake',
        originalSubmittedName: 'Lead monoxide',
        originalCAS: '1317-36-8',
        originalEC: '215-267-0',
        externalReference: 'CID 14827',
        ingestionBatch: 'PUBCHEM-20260630-02',
        confidenceRating: 'High',
        completenessScore: 96
      }
    },
    {
      stagedSubstanceId: 'STG-0002',
      substanceName: 'Chromium VI compound',
      CAS: '',
      EC: '',
      aliases: ['Hexavalent chromium compound', 'Cr(VI) compound'],
      source: 'Supplier portal',
      sourceType: 'Supplier input',
      dateReceived: '2026-06-29',
      dataConfidence: 'Low',
      completenessScore: 42,
      stagingStatus: 'Ready for Review',
      matchStatus: 'Potential Match',
      assignedReviewer: 'Emma Chen',
      notificationStatus: 'Required',
      signoffStatus: 'Required',
      decision: 'Leave unassigned / no action',
      currentLibraryStatus: 'Candidate review',
      supplierContext: {
        supplierName: 'Northlake Components',
        supplierId: 'SUP-10482',
        partNumber: 'NL-CR6-119',
        submissionId: 'FMD-20260629-771',
        notificationStatus: 'Required'
      },
      sourceMetadata: {
        sourceSystem: 'Supplier FMD intake',
        submittedBy: 'A. Patel',
        originalSubmittedName: 'Chromium VI compound',
        originalCAS: '',
        originalEC: '',
        externalReference: 'FMD-20260629-771',
        ingestionBatch: 'SUPPLIER-20260629-04',
        confidenceRating: 'Low',
        completenessScore: 42
      }
    },
    {
      stagedSubstanceId: 'STG-0003',
      substanceName: 'Bisphenol A',
      CAS: '80-05-7',
      EC: '201-245-8',
      aliases: ['BPA', '4,4-isopropylidenediphenol'],
      source: 'CAS',
      sourceType: 'CAS',
      dateReceived: '2026-06-28',
      dataConfidence: 'High',
      completenessScore: 98,
      stagingStatus: 'In Review',
      matchStatus: 'Match Found',
      assignedReviewer: 'You',
      notificationStatus: 'Not required',
      signoffStatus: 'Not required',
      decision: 'Approve existing match',
      currentLibraryStatus: 'Active',
      sourceMetadata: {
        sourceSystem: 'CAS Registry feed',
        submittedBy: 'Automated intake',
        originalSubmittedName: 'Bisphenol A',
        originalCAS: '80-05-7',
        originalEC: '201-245-8',
        externalReference: 'CAS-RN-80-05-7',
        ingestionBatch: 'CAS-20260628-01',
        confidenceRating: 'High',
        completenessScore: 98
      }
    },
    {
      stagedSubstanceId: 'STG-0004',
      substanceName: 'Unknown flame retardant additive',
      CAS: '',
      EC: '',
      aliases: ['FR additive', 'Confidential flame retardant blend'],
      source: 'Supplier portal',
      sourceType: 'Supplier input',
      dateReceived: '2026-06-28',
      dataConfidence: 'Low',
      completenessScore: 28,
      stagingStatus: 'Pending Investigation',
      matchStatus: 'No Match',
      assignedReviewer: 'Maya Singh',
      notificationStatus: 'Required',
      signoffStatus: 'Required',
      decision: 'Mark pending investigation',
      currentLibraryStatus: 'Not promoted',
      supplierContext: {
        supplierName: 'Kestrel Plastics',
        supplierId: 'SUP-11890',
        partNumber: 'KP-FR-7742',
        submissionId: 'FMD-20260628-218',
        notificationStatus: 'Required'
      },
      sourceMetadata: {
        sourceSystem: 'Supplier FMD intake',
        submittedBy: 'M. Wu',
        originalSubmittedName: 'Unknown flame retardant additive',
        originalCAS: '',
        originalEC: '',
        externalReference: 'FMD-20260628-218',
        ingestionBatch: 'SUPPLIER-20260628-02',
        confidenceRating: 'Low',
        completenessScore: 28
      }
    },
    {
      stagedSubstanceId: 'STG-0005',
      substanceName: 'Cadmium oxide',
      CAS: '1306-19-0',
      EC: '215-146-2',
      aliases: ['Cadmium monoxide', 'Oxocadmium'],
      source: 'Vendor API',
      sourceType: 'Third-party integration',
      dateReceived: '2026-06-27',
      dataConfidence: 'High',
      completenessScore: 95,
      stagingStatus: 'Ready for Review',
      matchStatus: 'Match Found',
      assignedReviewer: 'Regulatory Ops',
      notificationStatus: 'Not required',
      signoffStatus: 'Not required',
      decision: 'Leave unassigned / no action',
      currentLibraryStatus: 'Active',
      sourceMetadata: {
        sourceSystem: 'ChemData connector',
        submittedBy: 'Connector service',
        originalSubmittedName: 'Cadmium oxide',
        originalCAS: '1306-19-0',
        originalEC: '215-146-2',
        externalReference: 'CHEMDATA-CDO-1306190',
        ingestionBatch: '3P-20260627-11',
        confidenceRating: 'High',
        completenessScore: 95
      }
    },
    {
      stagedSubstanceId: 'STG-0006',
      substanceName: 'Lead glass ceramic material',
      CAS: '',
      EC: '',
      aliases: ['Lead glass ceramic', 'Pb glass ceramic frit'],
      source: 'Supplier portal',
      sourceType: 'Supplier input',
      dateReceived: '2026-06-26',
      dataConfidence: 'Medium',
      completenessScore: 64,
      stagingStatus: 'Ready for Review',
      matchStatus: 'Potential Match',
      assignedReviewer: 'Unassigned',
      notificationStatus: 'Required',
      signoffStatus: 'Required',
      decision: 'Leave unassigned / no action',
      currentLibraryStatus: 'Candidate review',
      supplierContext: {
        supplierName: 'Aster Electronics',
        supplierId: 'SUP-11357',
        partNumber: 'AE-LGC-44',
        submissionId: 'FMD-20260626-044',
        notificationStatus: 'Required'
      },
      sourceMetadata: {
        sourceSystem: 'Supplier FMD intake',
        submittedBy: 'S. Rivera',
        originalSubmittedName: 'Lead glass ceramic material',
        originalCAS: '',
        originalEC: '',
        externalReference: 'FMD-20260626-044',
        ingestionBatch: 'SUPPLIER-20260626-01',
        confidenceRating: 'Medium',
        completenessScore: 64
      }
    },
    {
      stagedSubstanceId: 'STG-0007',
      substanceName: 'Nickel sulfate',
      CAS: '7786-81-4',
      EC: '232-104-9',
      aliases: ['Nickel sulphate', 'Nickel(II) sulfate'],
      source: 'PubChem',
      sourceType: 'PubChem',
      dateReceived: '2026-06-25',
      dataConfidence: 'High',
      completenessScore: 94,
      stagingStatus: 'Ready for Review',
      matchStatus: 'Duplicate Risk',
      assignedReviewer: 'Assentee QA',
      notificationStatus: 'Not required',
      signoffStatus: 'Required',
      decision: 'Leave unassigned / no action',
      currentLibraryStatus: 'Active duplicate risk',
      sourceMetadata: {
        sourceSystem: 'PubChem PUG-View',
        submittedBy: 'Automated intake',
        originalSubmittedName: 'Nickel sulfate',
        originalCAS: '7786-81-4',
        originalEC: '232-104-9',
        externalReference: 'CID 24586',
        ingestionBatch: 'PUBCHEM-20260625-03',
        confidenceRating: 'High',
        completenessScore: 94
      }
    },
    {
      stagedSubstanceId: 'STG-0008',
      substanceName: 'Invalid CAS sample',
      CAS: '123-45-6',
      EC: '',
      aliases: ['Supplier placeholder substance'],
      source: 'Supplier portal',
      sourceType: 'Supplier input',
      dateReceived: '2026-06-24',
      dataConfidence: 'Low',
      completenessScore: 35,
      stagingStatus: 'New',
      matchStatus: 'Needs Review',
      assignedReviewer: 'Unassigned',
      notificationStatus: 'Required',
      signoffStatus: 'Required',
      decision: 'Leave unassigned / no action',
      currentLibraryStatus: 'Not promoted',
      supplierContext: {
        supplierName: 'Vertex Manufacturing',
        supplierId: 'SUP-12045',
        partNumber: 'VX-CAS-TEST',
        submissionId: 'FMD-20260624-601',
        notificationStatus: 'Required'
      },
      sourceMetadata: {
        sourceSystem: 'Supplier FMD intake',
        submittedBy: 'J. Nguyen',
        originalSubmittedName: 'Invalid CAS sample',
        originalCAS: '123-45-6',
        originalEC: '',
        externalReference: 'FMD-20260624-601',
        ingestionBatch: 'SUPPLIER-20260624-08',
        confidenceRating: 'Low',
        completenessScore: 35
      }
    }
  ];

  readonly matchCandidates: SubstanceLibraryCandidate[] = [
    { stagedSubstanceId: 'STG-0001', masterSubstanceId: 'MS-0042844', substanceName: 'Lead monoxide', CAS: '1317-36-8', EC: '215-267-0', aliases: ['Lead(II) oxide', 'Litharge'], authority: 'ECHA', source: 'Assent library', matchScore: 98, matchReason: 'Exact CAS and EC match. Incoming name is already an approved alias.', matchType: 'CAS match', currentLibraryStatus: 'Active', existingDslUsageCount: 7, lastUpdated: '2026-05-19' },
    { stagedSubstanceId: 'STG-0002', masterSubstanceId: 'MS-0042836', substanceName: 'Chromium trioxide', CAS: '1333-82-0', EC: '215-607-8', aliases: ['Chromium(VI) oxide', 'Chromic anhydride'], authority: 'ECHA', source: 'Assent library', matchScore: 71, matchReason: 'Name-only supplier entry mentions Cr(VI); candidate is a known hexavalent chromium substance.', matchType: 'Name match', currentLibraryStatus: 'Active', existingDslUsageCount: 14, lastUpdated: '2026-02-22' },
    { stagedSubstanceId: 'STG-0002', masterSubstanceId: 'MS-0042876', substanceName: 'Sodium chromate', CAS: '7775-11-3', EC: '231-889-5', aliases: ['Chromic acid disodium salt'], authority: 'ECHA', source: 'Assent library', matchScore: 63, matchReason: 'Alias includes chromium(VI), but identifiers are missing from the staged record.', matchType: 'Alias match', currentLibraryStatus: 'Active', existingDslUsageCount: 5, lastUpdated: '2026-04-11' },
    { stagedSubstanceId: 'STG-0002', masterSubstanceId: 'MS-0042877', substanceName: 'Potassium dichromate', CAS: '7778-50-9', EC: '231-906-6', aliases: ['Dipotassium dichromate'], authority: 'ECHA', source: 'Assent library', matchScore: 59, matchReason: 'Partial name and regulatory family overlap only. Manual resolution required.', matchType: 'Partial match', currentLibraryStatus: 'Active', existingDslUsageCount: 8, lastUpdated: '2026-03-08' },
    { stagedSubstanceId: 'STG-0003', masterSubstanceId: 'MS-0042860', substanceName: 'Bisphenol A', CAS: '80-05-7', EC: '201-245-8', aliases: ['BPA', '4,4-isopropylidenediphenol'], authority: 'ECHA', source: 'Assent library', matchScore: 99, matchReason: 'Exact CAS, EC, and canonical name match the active master record.', matchType: 'CAS match', currentLibraryStatus: 'Active', existingDslUsageCount: 11, lastUpdated: '2026-05-02' },
    { stagedSubstanceId: 'STG-0005', masterSubstanceId: 'MS-0042861', substanceName: 'Cadmium oxide', CAS: '1306-19-0', EC: '215-146-2', aliases: ['Cadmium monoxide', 'Oxocadmium'], authority: 'ECHA', source: 'Assent library', matchScore: 97, matchReason: 'Exact CAS and EC match. Third-party source adds one synonym already present.', matchType: 'CAS match', currentLibraryStatus: 'Active', existingDslUsageCount: 9, lastUpdated: '2026-06-02' },
    { stagedSubstanceId: 'STG-0006', masterSubstanceId: 'MS-0042820', substanceName: 'Lead', CAS: '7439-92-1', EC: '231-100-4', aliases: ['Pb', 'Lead metal'], authority: 'ECHA', source: 'Assent library', matchScore: 58, matchReason: 'Supplier name contains lead, but the staged item may be an article material rather than a substance.', matchType: 'Partial match', currentLibraryStatus: 'Active', existingDslUsageCount: 12, lastUpdated: '2026-04-16' },
    { stagedSubstanceId: 'STG-0006', masterSubstanceId: 'MS-0042880', substanceName: 'Lead silicate', CAS: '11120-22-2', EC: '234-363-3', aliases: ['Lead glass frit', 'Silicic acid lead salt'], authority: 'ECHA', source: 'Assent library', matchScore: 67, matchReason: 'Alias overlap with glass/ceramic lead material. CAS is absent in the supplier submission.', matchType: 'Alias match', currentLibraryStatus: 'Active', existingDslUsageCount: 4, lastUpdated: '2026-01-30' },
    { stagedSubstanceId: 'STG-0006', masterSubstanceId: 'MS-0042881', substanceName: 'Lead titanium zirconium oxide', CAS: '12626-81-2', EC: '235-727-4', aliases: ['PZT ceramic'], authority: 'ECHA', source: 'Assent library', matchScore: 52, matchReason: 'Ceramic context overlaps, but no identifier evidence is present.', matchType: 'Partial match', currentLibraryStatus: 'Active', existingDslUsageCount: 2, lastUpdated: '2026-03-18' },
    { stagedSubstanceId: 'STG-0007', masterSubstanceId: 'MS-0042882', substanceName: 'Nickel sulfate', CAS: '7786-81-4', EC: '232-104-9', aliases: ['Nickel sulphate', 'Nickel(II) sulfate'], authority: 'ECHA', source: 'Assent library', matchScore: 98, matchReason: 'Exact CAS and EC match an active master. Incoming record should link, not create a duplicate.', matchType: 'CAS match', currentLibraryStatus: 'Active', existingDslUsageCount: 10, lastUpdated: '2026-06-10' },
    { stagedSubstanceId: 'STG-0007', masterSubstanceId: 'MS-0042883', substanceName: 'Nickel sulfate hexahydrate', CAS: '10101-97-0', EC: '600-070-7', aliases: ['Nickel(II) sulfate hexahydrate'], authority: 'ECHA', source: 'Assent library', matchScore: 79, matchReason: 'Name is similar, but hydrate identifier differs from the staged CAS.', matchType: 'Name match', currentLibraryStatus: 'Active', existingDslUsageCount: 6, lastUpdated: '2026-02-04' }
  ];

  auditEvents: StagingAuditEvent[] = [
    { id: 'AUD-STG-0001-01', stagedSubstanceId: 'STG-0001', stagedSubstanceName: 'Lead monoxide', dateTime: '2026-06-30 09:42', user: 'System', action: 'Staged record created', decision: 'No action', reason: 'PubChem intake created a staged record.', beforeAfter: 'Before: not present | After: Ready for Review', notes: 'Source attribution retained from PubChem batch PUBCHEM-20260630-02.' },
    { id: 'AUD-STG-0001-02', stagedSubstanceId: 'STG-0001', stagedSubstanceName: 'Lead monoxide', dateTime: '2026-06-30 09:44', user: 'Matching service', action: 'Matching attempted', decision: 'Match Found', reason: 'CAS and EC matched active library record MS-0042844.', beforeAfter: 'Before: Needs Review | After: Match Found', notes: 'Lead(II) oxide confirmed as existing alias.' },
    { id: 'AUD-STG-0002-01', stagedSubstanceId: 'STG-0002', stagedSubstanceName: 'Chromium VI compound', dateTime: '2026-06-29 15:21', user: 'System', action: 'Staged record created', decision: 'No action', reason: 'Supplier-entered substance entered staging instead of auto-promotion.', beforeAfter: 'Before: not present | After: Ready for Review', notes: 'Supplier notification awareness set to Required.' },
    { id: 'AUD-STG-0002-02', stagedSubstanceId: 'STG-0002', stagedSubstanceName: 'Chromium VI compound', dateTime: '2026-06-29 15:24', user: 'Matching service', action: 'Matching attempted', decision: 'Potential Match', reason: 'Name-only chromium(VI) entry returned three candidates.', beforeAfter: 'Before: Needs Review | After: Potential Match', notes: 'Regulatory sign-off required for manual resolution.' },
    { id: 'AUD-STG-0002-03', stagedSubstanceId: 'STG-0002', stagedSubstanceName: 'Chromium VI compound', dateTime: '2026-06-29 16:02', user: 'Emma Chen', action: 'Reviewer changed', decision: 'Assigned reviewer', reason: 'Supplier clarification likely needed.', beforeAfter: 'Before: Unassigned | After: Emma Chen', notes: 'Reviewer assignment kept with the staged record.' },
    { id: 'AUD-STG-0003-01', stagedSubstanceId: 'STG-0003', stagedSubstanceName: 'Bisphenol A', dateTime: '2026-06-28 11:16', user: 'Matching service', action: 'Candidate selected', decision: 'Approve existing match', reason: 'Exact CAS, EC, and name match MS-0042860.', beforeAfter: 'Before: Ready for Review | After: In Review', notes: 'Reviewer opened record and selected best suggested match.' },
    { id: 'AUD-STG-0003-02', stagedSubstanceId: 'STG-0003', stagedSubstanceName: 'Bisphenol A', dateTime: '2026-06-28 11:20', user: 'You', action: 'Reviewer opened record', decision: 'Review details before approval', reason: 'Exact match still needs reviewer confirmation.', beforeAfter: 'Before: Ready for Review | After: In Review', notes: 'Source attribution retained; no duplicate created.' },
    { id: 'AUD-STG-0004-01', stagedSubstanceId: 'STG-0004', stagedSubstanceName: 'Unknown flame retardant additive', dateTime: '2026-06-28 10:04', user: 'Maya Singh', action: 'Marked pending investigation', decision: 'Mark pending investigation', reason: 'Name-only supplier record with no CAS or EC.', beforeAfter: 'Before: Ready for Review | After: Pending Investigation', notes: 'Supplier clarification needed before promotion.' },
    { id: 'AUD-STG-0004-02', stagedSubstanceId: 'STG-0004', stagedSubstanceName: 'Unknown flame retardant additive', dateTime: '2026-06-28 10:08', user: 'Maya Singh', action: 'Supplier notification triggered', decision: 'Supplier clarification', reason: 'Source is supplier input with missing identifiers.', beforeAfter: 'Before: Required | After: Queued', notes: 'Notification awareness only; communication workflow is outside ASP-17327.' },
    { id: 'AUD-STG-0005-01', stagedSubstanceId: 'STG-0005', stagedSubstanceName: 'Cadmium oxide', dateTime: '2026-06-27 14:36', user: 'Matching service', action: 'Matching attempted', decision: 'Match Found', reason: 'CAS and EC matched the active Cadmium oxide record.', beforeAfter: 'Before: Needs Review | After: Match Found', notes: 'Source attribution retained from third-party connector.' },
    { id: 'AUD-STG-0008-01', stagedSubstanceId: 'STG-0008', stagedSubstanceName: 'Invalid CAS sample', dateTime: '2026-06-24 08:11', user: 'Matching service', action: 'Matching attempted', decision: 'Needs Review', reason: 'CAS check-digit failed and EC is missing.', beforeAfter: 'Before: New | After: Needs Review', notes: 'Supplier-originated record requires notification awareness.' }
  ];

  readonly groups: SubstanceGroup[] = [
    { id: 'GRP-00042', name: 'Phthalates', description: 'ECHA plasticizers with 4 direct members and 1 nested subgroup.', members: 6, dslCount: 12, version: 'v4.2', status: 'Draft', owner: 'Regulatory', modified: '2h ago', created: 'Jun 14, 2019', lastActivated: 'Mar 02, 2026', color: '#dfecea', signal: 'Draft v4.3' },
    { id: 'GRP-00018', name: 'Lead Compounds', description: 'Authoritative lead compound group used across ECHA lists.', members: 28, dslCount: 18, version: 'v3.7', status: 'Active', owner: 'Regulatory', modified: '3d ago', created: 'Apr 20, 2020', lastActivated: 'Apr 16, 2026', color: '#ffd7a3' },
    { id: 'GRP-00007', name: 'Heavy Metals', description: 'Multiple authorities, 16 substances, 22 active DSL references.', members: 16, dslCount: 22, version: 'v5.1', status: 'Active', owner: 'Solutions Delivery', modified: '1w ago', created: 'Jan 12, 2018', lastActivated: 'Feb 21, 2026', color: '#dfecea' },
    { id: 'GRP-00204', name: 'Per- and Polyfluoroalkyl Substances (PFAS)', description: 'Large PFAS collection spanning EPA and ECHA scope updates.', members: 5732, dslCount: 24, version: 'v8.4', status: 'Draft', owner: 'Regulatory', modified: '5h ago', created: 'Oct 05, 2017', lastActivated: 'May 10, 2026', color: '#ffd7a3', signal: 'Largest' },
    { id: 'GRP-00088', name: 'Polycyclic Aromatic Hydrocarbons', description: 'ECHA PAH group reused by standard and customer lists.', members: 18, dslCount: 8, version: 'v2.7', status: 'Active', owner: 'Regulatory', modified: '2w ago', created: 'Aug 22, 2021', lastActivated: 'Apr 29, 2026', color: '#dfecea' },
    { id: 'GRP-00103', name: 'Brominated Flame Retardants', description: 'BFR substances with current ECHA source alignment.', members: 12, dslCount: 6, version: 'v3.1', status: 'Active', owner: 'Regulatory', modified: '3w ago', created: 'Feb 18, 2020', lastActivated: 'Apr 08, 2026', color: '#dfecea' },
    { id: 'GRP-00301', name: 'Conflict Minerals (3TG)', description: 'SEC and RBA minerals group for targeted collection workflows.', members: 4, dslCount: 3, version: 'v2.0', status: 'Active', owner: 'Regulatory', modified: '1m ago', created: 'May 11, 2022', lastActivated: 'Feb 14, 2026', color: '#e9e2ff' },
    { id: 'GRP-00112', name: 'REACH Restricted (Annex XVII)', description: 'Closed regulatory subset used by REACH Restricted list work.', members: 1287, dslCount: 5, version: 'v15.2', status: 'Closed subset', owner: 'Regulatory', modified: '1m ago', created: 'Mar 07, 2019', lastActivated: 'Mar 21, 2026', color: '#ffd7a3' },
    { id: 'GRP-00056', name: 'China RoHS Listed', description: 'MIIT-scoped group maintained for China RoHS reporting.', members: 10, dslCount: 3, version: 'v4.5', status: 'Closed subset', owner: 'Regulatory', modified: '2m ago', created: 'Sep 15, 2018', lastActivated: 'Jan 18, 2026', color: '#dfecea' }
  ];

  readonly groupMembers: GroupMember[] = [
    { name: 'Bis(2-ethylhexyl) phthalate (DEHP)', id: 'MS-0042822', cas: '117-81-7', ec: '204-211-0', threshold: '0.1%', effective: '2024-01-15', status: 'Active', kind: 'Substance' },
    { name: 'Benzyl butyl phthalate (BBP)', id: 'MS-0042823', cas: '85-68-7', ec: '201-622-7', threshold: '0.1%', effective: '2024-01-15', status: 'Active', kind: 'Substance' },
    { name: 'Dibutyl phthalate (DBP)', id: 'MS-0042824', cas: '84-74-2', ec: '201-557-4', threshold: '0.1%', effective: '2026-05-22', status: 'Draft add', kind: 'Substance' },
    { name: 'Diisobutyl phthalate (DIBP)', id: 'MS-0042834', cas: '84-69-5', ec: '201-553-2', threshold: '0.1%', effective: '2024-06-01', status: 'Active', kind: 'Substance' },
    {
      name: 'Long-chain Phthalates',
      id: 'GRP-00078',
      effective: '2025-11-04',
      status: 'Active',
      kind: 'Subgroup',
      children: [
        { name: 'Di-n-octyl phthalate (DnOP)', cas: '117-84-0', ec: '204-214-7' },
        { name: 'Diisononyl phthalate (DINP)', cas: '28553-12-0', ec: '249-079-5' }
      ]
    }
  ];

  readonly groupDraftMembers: GroupMember[] = [];

  readonly availableSubgroups: SubgroupCandidate[] = [
    {
      id: 'GRP-00144',
      name: 'Short-chain Phthalates',
      members: 4,
      owner: 'Regulatory',
      version: 'v1.9',
      safe: true,
      reason: 'No parent path loops back to the active group.'
    },
    {
      id: 'GRP-00412',
      name: 'Phthalate esters for packaging',
      members: 11,
      owner: 'Regulatory',
      version: 'v2.1',
      safe: true,
      reason: 'Reusable subgroup with no circular dependency.'
    },
    {
      id: 'GRP-00042',
      name: 'Phthalates',
      members: 6,
      owner: 'Regulatory',
      version: 'v4.2',
      safe: false,
      reason: 'Blocked because this would nest the parent group inside itself.'
    }
  ];

  readonly groupDslReferences: GroupDslReference[] = [
    { id: 'DSL-00007', name: 'REACH SVHC', owner: 'Regulatory', version: 'v3.0.2', status: 'Draft', decision: 'Receives draft version' },
    { id: 'DSL-00008', name: 'REACH Restricted (Annex XVII)', owner: 'Regulatory', version: 'v2.4', status: 'Active', decision: 'Receives draft version' },
    { id: 'DSL-00001', name: 'RoHS Directive', owner: 'Solutions Delivery', version: 'v4.1', status: 'Active', decision: 'Receives draft version' },
    { id: 'DSL-00012', name: 'California Prop 65', owner: 'Customer programs', version: 'v8.2.1', status: 'Active', decision: 'Keeps current version' }
  ];

  readonly dslLists: DslList[] = [
    {
      id: 'DSL-00007',
      name: 'REACH SVHC',
      description: 'Candidate list substances and reusable groups used for REACH supplier declarations.',
      authority: 'ECHA',
      created: 'Feb 11, 2018',
      version: 'v3.0.2',
      versionNote: 'DBP and Phthalates draft references are staged for the next list version.',
      substances: 4128,
      groups: 38,
      exemptionSets: 2,
      modules: 1,
      status: 'Draft',
      effective: '2024-01-15',
      owner: 'Regulatory',
      scope: 'Standard',
      modified: '2h ago'
    },
    {
      id: 'DSL-00008',
      name: 'REACH Restricted (Annex XVII)',
      description: 'Restricted substances and groups used for Annex XVII compliance workflows.',
      authority: 'ECHA',
      created: 'Mar 05, 2019',
      version: 'v2.4',
      versionNote: 'Active state retained after Annex XVII review.',
      substances: 1287,
      groups: 12,
      exemptionSets: 1,
      modules: 1,
      status: 'Active',
      effective: '2025-03-10',
      owner: 'Regulatory',
      scope: 'Standard',
      modified: '1w ago'
    },
    {
      id: 'DSL-00001',
      name: 'RoHS Directive',
      description: 'RoHS restricted substances, exemptions, and groups used by standard modules.',
      authority: 'EU',
      created: 'Aug 17, 2017',
      version: 'v4.1',
      versionNote: 'Article exemption updates reviewed and activated.',
      substances: 10,
      groups: 2,
      exemptionSets: 2,
      modules: 1,
      status: 'Active',
      effective: '2024-06-01',
      owner: 'Regulatory',
      scope: 'Standard',
      modified: '3w ago'
    },
    {
      id: 'DSL-00012',
      name: 'California Prop 65',
      description: 'Custom program list maintained for California Proposition 65 reporting.',
      authority: 'CA OEHHA',
      created: 'Jan 22, 2020',
      version: 'v8.2.1',
      versionNote: 'OEHHA update reconciled with customer-specific notes.',
      substances: 1012,
      groups: 4,
      exemptionSets: 0,
      modules: 1,
      status: 'Active',
      effective: '2026-01-08',
      owner: 'Customer programs',
      scope: 'Custom',
      modified: '5d ago'
    },
    {
      id: 'DSL-00031',
      name: 'PFAS Working List',
      description: 'Large PFAS list used to review EPA and ECHA scope updates before module deployment.',
      authority: 'EPA, ECHA',
      created: 'Nov 09, 2022',
      version: 'Draft v1.7',
      versionNote: 'Large PFAS update is still being reconciled with nested group contents.',
      substances: 7326,
      groups: 24,
      exemptionSets: 1,
      modules: 2,
      status: 'Draft',
      effective: '2026-06-01',
      owner: 'Regulatory',
      scope: 'Custom',
      modified: 'Today'
    }
  ];

  readonly dslContentItems: DslContentItem[] = [
    {
      id: 'MS-0042819',
      name: 'Cadmium',
      kind: 'Substance',
      authority: 'ECHA',
      cas: '7440-43-9',
      ec: '231-152-8',
      effective: '2024-01-15',
      inclusion: 'Declarable above 0.1% w/w.',
      internalNote: 'Included from Candidate List review.',
      externalNote: 'Report when present above threshold.',
      status: 'Active'
    },
    {
      id: 'GRP-00042',
      name: 'Phthalates',
      kind: 'Group',
      authority: 'ECHA',
      version: 'v4.2',
      substances: 6,
      groups: 1,
      effective: '2024-01-15',
      inclusion: 'Use group definition current at selected version.',
      internalNote: 'Draft v4.3 exists but this DSL still points at v4.2 until activation review.',
      externalNote: 'Declare listed phthalates when present above threshold.',
      status: 'Active',
      children: [
        { kind: 'Substance', id: 'MS-0042822', name: 'Bis(2-ethylhexyl) phthalate (DEHP)', cas: '117-81-7', ec: '204-211-0' },
        { kind: 'Substance', id: 'MS-0042823', name: 'Benzyl butyl phthalate (BBP)', cas: '85-68-7', ec: '201-622-7' },
        { kind: 'Subgroup', id: 'GRP-00078', name: 'Long-chain Phthalates' }
      ]
    },
    {
      id: 'GRP-00007',
      name: 'Heavy Metals',
      kind: 'Group',
      authority: 'Solutions Delivery',
      version: 'v5.1',
      substances: 16,
      groups: 0,
      effective: '2024-06-01',
      inclusion: 'All active group members are in scope.',
      internalNote: 'High reuse group; changes require activation impact review.',
      externalNote: 'Report metals as required by list instructions.',
      status: 'Active',
      children: [
        { kind: 'Substance', id: 'MS-0042819', name: 'Cadmium', cas: '7440-43-9', ec: '231-152-8' },
        { kind: 'Substance', id: 'MS-0042820', name: 'Lead', cas: '7439-92-1', ec: '231-100-4' },
        { kind: 'Substance', id: 'MS-0042821', name: 'Mercury', cas: '7439-97-6', ec: '231-106-7' }
      ]
    },
    {
      id: 'MS-0042824',
      name: 'Dibutyl phthalate',
      kind: 'Substance',
      authority: 'ECHA',
      cas: '84-74-2',
      ec: '201-557-4',
      effective: '2026-05-22',
      inclusion: 'Added for next Candidate List update.',
      internalNote: 'Source bulletin reviewed; waiting for activation.',
      externalNote: 'Newly declarable after effective date.',
      status: 'Draft add'
    }
  ];

  readonly dslExemptionReferences: DslExemptionReference[] = [
    { code: 'EXS-00012', name: 'REACH Exemptions (Annex XVII)', exemptions: 23, authority: 'ECHA', effective: '2024-01-15', status: 'Active' },
    { code: 'EXS-00021', name: 'Industrial Use Exemptions', exemptions: 11, authority: 'ECHA', effective: '2026-01-01', status: 'Draft add' }
  ];

  readonly dslGroupCandidates: DslGroupCandidate[] = [
    { id: 'GRP-00018', name: 'Lead Compounds', members: 28, owner: 'Regulatory', version: 'v3.7', safe: true, reason: 'No nested path returns to this DSL content branch.' },
    { id: 'GRP-00204', name: 'Per- and Polyfluoroalkyl Substances (PFAS)', members: 5732, owner: 'Regulatory', version: 'v8.4', safe: true, reason: 'Large group; contents stay expandable after it is referenced.' },
    { id: 'GRP-00042', name: 'Phthalates', members: 6, owner: 'Regulatory', version: 'v4.2', safe: false, reason: 'Already referenced by this DSL. Add the new group version through activation review instead.' },
    { id: 'GRP-00412', name: 'Phthalate esters for packaging', members: 11, owner: 'Regulatory', version: 'v1.4', safe: false, reason: 'Blocked because this subgroup path already rolls up through Phthalates.' }
  ];

  readonly modules: ModuleRecord[] = [
    {
      id: 'MOD-REACH-SVHC',
      name: 'REACH SVHC Module',
      description: 'Customer-facing package for REACH SVHC supplier declarations and support resources.',
      list: 'REACH SVHC',
      listId: 'DSL-00007',
      created: 'Mar 18, 2018',
      version: 'Draft v3.1',
      versionNote: 'DBP list update and support-resource relink need readiness review before the module is ready.',
      owner: 'Regulatory',
      groups: 38,
      exemptionSets: 2,
      resources: [
        { name: 'Supplier declaration guidance', type: 'PDF', status: 'Ready', detail: 'Latest customer-facing help file is attached.' },
        { name: 'Declaration workflow mapping', type: 'Template', status: 'Ready', detail: 'Field mapping matches the active DSL list.' },
        { name: 'Customer preview bundle', type: 'HTML', status: 'Missing', detail: 'Preview needs to be regenerated after the DBP change.' }
      ],
      customers: 184,
      checks: 75,
      status: 'Draft',
      impact: 'Needs resource relink before Ready',
      modified: '2h ago'
    },
    {
      id: 'MOD-ROHS',
      name: 'RoHS Module',
      description: 'Reusable RoHS compliance module assembled from the active RoHS DSL list and exemptions.',
      list: 'RoHS Directive',
      listId: 'DSL-00001',
      created: 'Aug 21, 2017',
      version: 'v4.1',
      versionNote: 'RoHS article exemption update finalized for downstream consumption.',
      owner: 'Regulatory',
      groups: 2,
      exemptionSets: 2,
      resources: [
        { name: 'Supplier declaration guidance', type: 'PDF', status: 'Ready', detail: 'Guidance reviewed with active exemption set.' },
        { name: 'Customer preview bundle', type: 'HTML', status: 'Ready', detail: 'Preview matches the ready module package.' }
      ],
      customers: 322,
      checks: 100,
      status: 'Ready',
      impact: 'Ready for deployment queue',
      modified: '3w ago'
    },
    {
      id: 'MOD-PROP65',
      name: 'California Prop 65 Module',
      description: 'Customer-program module for California Proposition 65 reporting scope.',
      list: 'California Prop 65',
      listId: 'DSL-00012',
      created: 'Jan 29, 2020',
      version: 'v8.2.1',
      versionNote: 'OEHHA update is complete and ready for downstream consumption.',
      owner: 'Customer programs',
      groups: 4,
      exemptionSets: 0,
      resources: [
        { name: 'Customer preview bundle', type: 'HTML', status: 'Ready', detail: 'Preview reflects current list contents.' },
        { name: 'External note pack', type: 'Copy deck', status: 'Ready', detail: 'Customer-facing notes are attached.' }
      ],
      customers: 118,
      checks: 92,
      status: 'Ready',
      impact: 'Ready with low lifecycle risk',
      modified: '5d ago'
    },
    {
      id: 'MOD-PFAS',
      name: 'PFAS Module',
      description: 'Large PFAS module package waiting on list reconciliation and source-target health.',
      list: 'PFAS Working List',
      listId: 'DSL-00031',
      created: 'Nov 14, 2022',
      version: 'Draft v1.7',
      versionNote: 'PFAS list reconciliation and importer sync must pass before finalization.',
      owner: 'Regulatory',
      groups: 24,
      exemptionSets: 1,
      resources: [
        { name: 'PFAS scope explainer', type: 'PDF', status: 'Draft', detail: 'Draft resource is attached but not approved.' },
        { name: 'Customer preview bundle', type: 'HTML', status: 'Missing', detail: 'Preview is blocked until list reconciliation finishes.' }
      ],
      customers: 76,
      checks: 48,
      status: 'Blocked',
      impact: 'Importer sync failing',
      modified: 'Today'
    }
  ];

  readonly exemptionSets: ExemptionSet[] = [
    {
      code: 'EXS-00012',
      name: 'REACH Exemptions (Annex XVII)',
      description: 'Reusable Annex XVII exemption rules with thresholds, applicability, and expiry dates for REACH DSLs.',
      authority: 'ECHA',
      scope: 'REACH SVHC, REACH Restricted',
      version: 'Draft v2.5',
      lastPublishedVersion: 'v2.4',
      draftVersion: 'v2.5',
      exemptions: 4,
      expiryWatchCount: 2,
      status: 'Draft',
      owner: 'Regulatory',
      created: 'Mar 05, 2019',
      modified: 'Today',
      lastPublished: 'May 17, 2026',
      publishedBy: 'Emma Chen',
      dslReferenceCount: 2,
      versionNote: 'Lead article exemption expiry update and Annex XVII threshold cleanup for Q3 review.',
      warnings: ['threshold-conflict', 'expired']
    },
    {
      code: 'EXS-00021',
      name: 'Industrial Use Exemptions',
      description: 'Production-process exemptions for substances that are restricted in consumer article contexts but allowed under industrial-use conditions.',
      authority: 'ECHA',
      scope: 'REACH SVHC',
      version: 'v1.8',
      lastPublishedVersion: 'v1.8',
      draftVersion: 'v1.9',
      exemptions: 2,
      expiryWatchCount: 0,
      status: 'Published',
      owner: 'Regulatory',
      created: 'Oct 12, 2022',
      modified: '1w ago',
      lastPublished: 'Apr 22, 2026',
      publishedBy: 'Regulatory Ops',
      dslReferenceCount: 1,
      versionNote: 'Annual review complete. No threshold or applicability changes required.',
      warnings: []
    },
    {
      code: 'EXS-00044',
      name: 'RoHS Article Exemptions',
      description: 'RoHS article-level exemptions used by standard RoHS modules, including lead, cadmium, and chromium use cases.',
      authority: 'EU Commission',
      scope: 'RoHS Directive',
      version: 'Draft v4.2',
      lastPublishedVersion: 'v4.1',
      draftVersion: 'v4.2',
      exemptions: 3,
      expiryWatchCount: 2,
      status: 'Expiring soon',
      owner: 'Solutions Delivery',
      created: 'Aug 17, 2017',
      modified: '2d ago',
      lastPublished: 'Mar 08, 2026',
      publishedBy: 'Solutions Delivery',
      dslReferenceCount: 2,
      versionNote: 'Article exemption renewal dates added. Four downstream DSL consumers need impact review before publish.',
      warnings: ['duplicate-code', 'missing-expiry']
    },
    {
      code: 'EXS-00057',
      name: 'PFAS Essential Use Exemptions',
      description: 'Draft PFAS essential-use exemption set for analysis before any downstream DSL consumes it.',
      authority: 'EPA, ECHA',
      scope: 'PFAS Working List',
      version: 'Draft v0.3',
      lastPublishedVersion: 'Not published yet',
      draftVersion: 'v0.3',
      exemptions: 1,
      expiryWatchCount: 1,
      status: 'Draft',
      owner: 'Regulatory',
      created: 'Today',
      modified: 'Today',
      lastPublished: 'Not published yet',
      publishedBy: 'Not published yet',
      dslReferenceCount: 0,
      versionNote: 'Drafting PFAS essential-use exemptions from stakeholder source material.',
      warnings: ['missing-applicability']
    }
  ];

  readonly exemptionRecords: ExemptionRecord[] = [
    {
      id: 'EXM-00012-6A',
      setCode: 'EXS-00012',
      code: 'RoHS 6(a)',
      description: 'Lead as an alloying element in steel for machining purposes and in galvanized steel.',
      thresholdMin: '0.1%',
      thresholdMax: '0.35%',
      applicability: [
        { kind: 'Substance', id: 'MS-0042820', name: 'Lead', detail: 'CAS 7439-92-1' },
        { kind: 'Group', id: 'GRP-00018', name: 'Lead Compounds', detail: '28 substances' }
      ],
      expiryDate: '2026-07-31',
      effectiveDate: '2024-01-15',
      status: 'Expiring soon',
      notes: 'Renewal status under regulatory review. Review before publishing this set.',
      warningKeys: ['threshold-conflict']
    },
    {
      id: 'EXM-00012-6A-DRAFT',
      setCode: 'EXS-00012',
      code: 'RoHS 6(a)',
      description: 'Draft split for higher lead thresholds in machining steel where renewal text differs.',
      thresholdMin: '0.2%',
      thresholdMax: '0.4%',
      applicability: [
        { kind: 'Substance', id: 'MS-0042820', name: 'Lead', detail: 'CAS 7439-92-1' }
      ],
      expiryDate: '2026-09-30',
      effectiveDate: '2026-06-25',
      status: 'Draft add',
      notes: 'Duplicate code and overlapping threshold range need resolution before publish.',
      warningKeys: ['duplicate-code', 'threshold-conflict']
    },
    {
      id: 'EXM-00012-23',
      setCode: 'EXS-00012',
      code: 'Annex XVII 23',
      description: 'Cadmium and cadmium compounds in selected plastic materials.',
      thresholdMin: '',
      thresholdMax: '0.01%',
      applicability: [],
      expiryDate: '',
      effectiveDate: '2026-06-25',
      status: 'Draft edit',
      notes: 'Applicability and expiry are required before this exemption can be published.',
      warningKeys: ['missing-threshold', 'missing-applicability', 'missing-expiry']
    },
    {
      id: 'EXM-00012-63',
      setCode: 'EXS-00012',
      code: 'Annex XVII 63',
      description: 'Lead and lead compounds in consumer articles above the allowed concentration.',
      thresholdMin: '0.05%',
      thresholdMax: '0.1%',
      applicability: [
        { kind: 'Substance', id: 'MS-0042820', name: 'Lead', detail: 'CAS 7439-92-1' }
      ],
      expiryDate: '2026-03-31',
      effectiveDate: '2024-01-15',
      status: 'Expired',
      notes: 'Expired exemption remains visible for audit and historical declarations.',
      warningKeys: ['expired']
    },
    {
      id: 'EXM-00021-01',
      setCode: 'EXS-00021',
      code: 'IU-01',
      description: 'Industrial closed-system use where worker exposure controls are documented.',
      thresholdMin: '0%',
      thresholdMax: '0.1%',
      applicability: [
        { kind: 'Group', id: 'GRP-00088', name: 'Polycyclic Aromatic Hydrocarbons', detail: '18 substances' }
      ],
      expiryDate: '2028-12-31',
      effectiveDate: '2025-01-01',
      status: 'Published',
      notes: 'No near-term expiry risk.',
      warningKeys: []
    },
    {
      id: 'EXM-00021-02',
      setCode: 'EXS-00021',
      code: 'IU-02',
      description: 'Manufacturing process exemption for intermediate-use materials.',
      thresholdMin: '0%',
      thresholdMax: '1%',
      applicability: [
        { kind: 'Substance', id: 'MS-0042828', name: 'Short-chain chlorinated paraffins', detail: 'CAS 85535-84-8' }
      ],
      expiryDate: '2029-06-30',
      effectiveDate: '2025-06-01',
      status: 'Published',
      notes: 'Reviewed during annual REACH update.',
      warningKeys: []
    },
    {
      id: 'EXM-00044-7CI',
      setCode: 'EXS-00044',
      code: 'RoHS 7(c)-I',
      description: 'Electrical and electronic components containing lead in glass or ceramic.',
      thresholdMin: '0.1%',
      thresholdMax: '0.1%',
      applicability: [
        { kind: 'Substance', id: 'MS-0042820', name: 'Lead', detail: 'CAS 7439-92-1' },
        { kind: 'Group', id: 'GRP-00018', name: 'Lead Compounds', detail: '28 substances' }
      ],
      expiryDate: '2026-08-15',
      effectiveDate: '2024-06-01',
      status: 'Expiring soon',
      notes: 'Close to expiry; publish impact must warn downstream DSL owners.',
      warningKeys: []
    },
    {
      id: 'EXM-00044-8B',
      setCode: 'EXS-00044',
      code: 'RoHS 8(b)',
      description: 'Cadmium and its compounds in electrical contacts.',
      thresholdMin: '0.01%',
      thresholdMax: '',
      applicability: [
        { kind: 'Substance', id: 'MS-0042819', name: 'Cadmium', detail: 'CAS 7440-43-9' }
      ],
      expiryDate: '',
      effectiveDate: '2026-06-25',
      status: 'Draft edit',
      notes: 'Missing max threshold and expiry date.',
      warningKeys: ['missing-threshold', 'missing-expiry']
    },
    {
      id: 'EXM-00044-8B-DUPE',
      setCode: 'EXS-00044',
      code: 'RoHS 8(b)',
      description: 'Draft alternate cadmium contact exemption imported from source review.',
      thresholdMin: '0.01%',
      thresholdMax: '0.02%',
      applicability: [
        { kind: 'Substance', id: 'MS-0042819', name: 'Cadmium', detail: 'CAS 7440-43-9' }
      ],
      expiryDate: '2027-02-28',
      effectiveDate: '2026-06-25',
      status: 'Draft add',
      notes: 'Duplicate code should be resolved or merged.',
      warningKeys: ['duplicate-code']
    },
    {
      id: 'EXM-00057-01',
      setCode: 'EXS-00057',
      code: 'PFAS-EU-01',
      description: 'Essential-use exemption candidate for semiconductor manufacturing equipment.',
      thresholdMin: '0%',
      thresholdMax: '0.1%',
      applicability: [],
      expiryDate: '2026-10-31',
      effectiveDate: '2026-06-25',
      status: 'Draft add',
      notes: 'Applicability must be tied to PFAS substances or groups once the substance library dependency is ready.',
      warningKeys: ['missing-applicability']
    }
  ];

  readonly exemptionSetDslReferences: ExemptionSetDslReference[] = [
    { setCode: 'EXS-00012', id: 'DSL-00007', name: 'REACH SVHC', owner: 'Regulatory', version: 'Draft v3.1', status: 'Draft', impact: 'Draft publish updates the REACH module source package after list activation.' },
    { setCode: 'EXS-00012', id: 'DSL-00008', name: 'REACH Restricted (Annex XVII)', owner: 'Regulatory', version: 'v2.4', status: 'Active', impact: 'Published changes can alter downstream compliance determinations.' },
    { setCode: 'EXS-00021', id: 'DSL-00007', name: 'REACH SVHC', owner: 'Regulatory', version: 'Draft v3.1', status: 'Draft', impact: 'Industrial-use exemptions are referenced with an effective date.' },
    { setCode: 'EXS-00044', id: 'DSL-00001', name: 'RoHS Directive', owner: 'Regulatory', version: 'v4.1', status: 'Active', impact: 'RoHS module customers receive new article exemption rules after downstream release.' },
    { setCode: 'EXS-00044', id: 'DSL-00031', name: 'PFAS Working List', owner: 'Regulatory', version: 'Draft v1.7', status: 'Draft', impact: 'Draft list is using RoHS article examples during shaping review.' }
  ];

  readonly exemptionSetVersions: ExemptionSetVersionRecord[] = [
    { setCode: 'EXS-00012', version: 'v2.5', status: 'Current draft', note: 'Lead article expiry and threshold cleanup.', publishedBy: 'Not published yet', publishedDate: 'Draft', changeSummary: '2 draft adds, 1 edit, 2 unresolved warnings.' },
    { setCode: 'EXS-00012', version: 'v2.4', status: 'Published', note: 'Annex XVII update from May source review.', publishedBy: 'Emma Chen', publishedDate: 'May 17, 2026', changeSummary: 'Current authoritative published version.' },
    { setCode: 'EXS-00012', version: 'v2.3', status: 'Superseded', note: 'Annual threshold refresh.', publishedBy: 'Regulatory Ops', publishedDate: 'Jan 19, 2026', changeSummary: 'Historical declarations stay pinned to this version where applicable.' },
    { setCode: 'EXS-00021', version: 'v1.8', status: 'Published', note: 'Annual industrial-use review.', publishedBy: 'Regulatory Ops', publishedDate: 'Apr 22, 2026', changeSummary: 'No unresolved warnings.' },
    { setCode: 'EXS-00044', version: 'v4.2', status: 'Current draft', note: 'Article exemption renewal dates added.', publishedBy: 'Not published yet', publishedDate: 'Draft', changeSummary: '2 expiry risks and 2 validation warnings before publish.' },
    { setCode: 'EXS-00044', version: 'v4.1', status: 'Published', note: 'RoHS article exemption update finalized.', publishedBy: 'Solutions Delivery', publishedDate: 'Mar 08, 2026', changeSummary: 'Current authoritative published version.' },
    { setCode: 'EXS-00057', version: 'v0.3', status: 'Current draft', note: 'PFAS essential-use shaping draft.', publishedBy: 'Not published yet', publishedDate: 'Draft', changeSummary: 'Not yet published or referenced by DSLs.' }
  ];

  readonly deploymentSteps: ActivityItem[] = [
    { title: 'Preflight validation', body: 'Scope sheet, GUIDs, and required resources passed.', time: 'Complete', icon: 'pi pi-check', severity: 'success' },
    { title: 'Importer sync health', body: 'One timeout detected on ASP path; ASM path is clean.', time: 'Needs attention', icon: 'pi pi-exclamation-triangle', severity: 'warn' },
    { title: 'UAT smoke test', body: 'ASP-equivalent verification queued after promotion.', time: 'Queued', icon: 'pi pi-clock', severity: 'info' },
    { title: 'Production deployment', body: 'Blocked until lifecycle impact is accepted.', time: 'Blocked', icon: 'pi pi-lock', severity: 'danger' }
  ];

  readonly actionLog: ActivityItem[] = [
    { title: 'Phthalates v4.3 draft opened', body: 'DBP added with effective date 2026-05-22.', time: '2h ago', icon: 'pi pi-pencil', severity: 'info' },
    { title: 'Scope sheet reconciled', body: 'REACH SVHC matched 4,128 of 4,128 expected rows.', time: '4h ago', icon: 'pi pi-verified', severity: 'success' },
    { title: 'Importer warning recorded', body: 'Generic network error split into timeout, auth, and backend categories.', time: 'Yesterday', icon: 'pi pi-wifi', severity: 'warn' },
    { title: 'Archive attempt blocked', body: 'Cadmium referenced by 450 downstream objects.', time: '2d ago', icon: 'pi pi-ban', severity: 'danger' }
  ];

  readonly activityStatusOptions = ['All', 'Draft saved', 'Active', 'Published', 'Expired', 'Archived', 'Blocked', 'Reviewed', 'Context'];

  readonly substanceActivityHistory: Record<string, SubstanceActivityRecord[]> = {
    'MS-0042819': [
      {
        id: 'TXN-2026-0520-001',
        date: '2026-05-20 14:18',
        status: 'Blocked',
        type: 'Archive review',
        summary: 'Archive attempt blocked by downstream usage.',
        rationale: 'Cadmium still appears in active DSL lists, groups, and ASP material references.',
        source: 'Archive guardrail',
        impact: '9 lists, 14 groups, 427 materials remain attached.',
        user: 'Chaukat'
      },
      {
        id: 'TXN-2026-0518-014',
        date: '2026-05-18 09:42',
        status: 'Reviewed',
        type: 'Identifier review',
        summary: 'CAS and EC identifiers validated.',
        rationale: 'Check-digit validation passed before source reconciliation.',
        source: 'Assent master data',
        impact: 'No lifecycle change.',
        user: 'Emma'
      },
      {
        id: 'TXN-2026-0509-006',
        date: '2026-05-09 11:05',
        status: 'Active',
        type: 'API availability',
        summary: 'Active substance remained available to material APIs.',
        rationale: 'No archive or status change was approved.',
        source: 'ASP material API',
        impact: 'Customer-facing module state unchanged.',
        user: 'System'
      }
    ],
    'MS-0042822': [
      {
        id: 'TXN-2026-0522-019',
        date: '2026-05-22 10:21',
        status: 'Reviewed',
        type: 'Group membership',
        summary: 'Confirmed DEHP remains active in Phthalates draft review.',
        rationale: 'No identifier change; membership was checked before DBP was added to the same group draft.',
        source: 'Phthalates GRP-00042',
        impact: 'No supplier action or recollection triggered.',
        user: 'Chaukat'
      },
      {
        id: 'TXN-2026-0506-007',
        date: '2026-05-06 15:44',
        status: 'Active',
        type: 'Reference validation',
        summary: 'Downstream references reconciled for DSL list usage.',
        rationale: 'All referenced lists resolve through the canonical substance ID.',
        source: 'REACH SVHC scope check',
        impact: '12 lists and 3 groups remain valid.',
        user: 'Renato'
      },
      {
        id: 'TXN-2026-0429-011',
        date: '2026-04-29 08:37',
        status: 'Reviewed',
        type: 'Alias review',
        summary: 'Alias set reviewed against ECHA source naming.',
        rationale: 'Complementary names were retained as aliases instead of creating duplicate records.',
        source: 'ECHA source review',
        impact: 'Duplicate prevention preserved historical declaration matching.',
        user: 'Emma'
      }
    ],
    'MS-0042824': [
      {
        id: 'TXN-2026-0522-031',
        date: '2026-05-22 12:03',
        status: 'Draft saved',
        type: 'Group membership',
        summary: 'DBP added to Phthalates as a draft member.',
        rationale: 'ECHA bulletin indicates DBP should be included with a 0.1% threshold.',
        source: 'ECHA bulletin 2026-05-12',
        impact: 'Lifecycle review required before group activation.',
        user: 'Chaukat'
      },
      {
        id: 'TXN-2026-0522-029',
        date: '2026-05-22 11:47',
        status: 'Reviewed',
        type: 'Staging promotion',
        summary: 'Candidate record matched and promoted from staging.',
        rationale: 'CAS and EC matched expected source data and no duplicate master record was found.',
        source: 'ECHA import',
        impact: 'New authoritative record created for review.',
        user: 'Emma'
      }
    ]
  };

  readonly groupActivityHistory: Record<string, SubstanceActivityRecord[]> = {
    'GRP-00042': [
      {
        id: 'GTXN-2026-0522-017',
        date: '2026-05-22 13:14',
        status: 'Draft saved',
        type: 'Member change',
        summary: 'DBP added to the draft group version.',
        rationale: 'ECHA bulletin 2026-05-12 adds DBP to the Phthalates scope with the group default threshold.',
        source: 'ECHA bulletin 2026-05-12',
        impact: 'Draft v4.3 is not active yet; selected DSLs receive it only after activation impact is approved.',
        user: 'Chaukat'
      },
      {
        id: 'GTXN-2026-0522-011',
        date: '2026-05-22 10:08',
        status: 'Reviewed',
        type: 'Nesting check',
        summary: 'Circular subgroup check passed for draft edits.',
        rationale: 'Nested subgroup paths were checked before the draft was saved.',
        source: 'Group dependency guardrail',
        impact: 'No circular reference found; current active version remains v4.2.',
        user: 'System'
      },
      {
        id: 'GTXN-2026-0302-004',
        date: '2026-03-02 09:35',
        status: 'Active',
        type: 'Group activation',
        summary: 'Phthalates v4.2 activated for associated DSLs.',
        rationale: 'Prior draft review completed and associated DSL selections were approved.',
        source: 'Activation impact review',
        impact: '12 associated DSLs continued resolving against the governed Phthalates group definition.',
        user: 'Renato'
      }
    ]
  };

  readonly exemptionActivityHistory: Record<string, SubstanceActivityRecord[]> = {
    'EXS-00012': [
      {
        id: 'EXTXN-2026-0624-011',
        date: '2026-06-24 09:17',
        status: 'Draft saved',
        type: 'Exemption edited',
        summary: 'RoHS 6(a) draft split added with duplicate-code warning.',
        rationale: 'The source update has a different threshold range and needs review before publish.',
        source: 'ECHA/RoHS source review',
        impact: '2 DSL references will see this in publish impact before the authoritative version changes.',
        user: 'Jeff Tengwall'
      },
      {
        id: 'EXTXN-2026-0624-010',
        date: '2026-06-24 08:52',
        status: 'Blocked',
        type: 'Threshold changed',
        summary: 'Threshold overlap detected for RoHS 6(a).',
        rationale: 'The draft range overlaps an existing lead applicability rule.',
        source: 'Threshold validation',
        impact: 'Publish panel warns until the conflict is resolved or accepted.',
        user: 'System'
      },
      {
        id: 'EXTXN-2026-0623-018',
        date: '2026-06-23 14:30',
        status: 'Reviewed',
        type: 'Applicability changed',
        summary: 'Lead and Lead Compounds applicability confirmed.',
        rationale: 'Applicability depends on the Substance Library and Substance Groups records.',
        source: 'Substance Library + Substance Groups',
        impact: 'Applicability summary now appears on exemption rows.',
        user: 'Regulatory'
      },
      {
        id: 'EXTXN-2026-0618-009',
        date: '2026-06-18 10:05',
        status: 'Draft saved',
        type: 'Expiry changed',
        summary: 'RoHS 6(a) expiry moved into the 90-day watch window.',
        rationale: 'The exemption is close to expiry and must be reviewed before publish.',
        source: 'Regulatory expiry watch',
        impact: 'Expiry watch count increased at exemption set level.',
        user: 'Solutions Delivery'
      },
      {
        id: 'EXTXN-2026-0517-004',
        date: '2026-05-17 16:20',
        status: 'Published',
        type: 'Draft published',
        summary: 'REACH Exemptions (Annex XVII) v2.4 published.',
        rationale: 'Version note and downstream DSL impact were accepted.',
        source: 'Publish impact review',
        impact: 'Published version became authoritative for REACH SVHC and REACH Restricted DSL references.',
        user: 'Emma Chen'
      },
      {
        id: 'EXTXN-2026-0502-002',
        date: '2026-05-02 11:48',
        status: 'Reviewed',
        type: 'Exemption set assigned to DSL',
        summary: 'Exemption set referenced by REACH Restricted.',
        rationale: 'The DSL stores a reference to the exemption set rather than copying exemption records.',
        source: 'DSL References tab',
        impact: 'DSL reference count increased and publish impact started including the DSL.',
        user: 'Regulatory'
      },
      {
        id: 'EXTXN-2026-0331-001',
        date: '2026-03-31 00:00',
        status: 'Expired',
        type: 'Exemption expired',
        summary: 'Annex XVII 63 reached expiry.',
        rationale: 'Declarations using this exemption are no longer valid after the expiry date.',
        source: 'Expiry watch automation',
        impact: 'Expired status remains visible for audit and publish warning.',
        user: 'System'
      }
    ],
    'EXS-00044': [
      {
        id: 'EXTXN-2026-0623-044',
        date: '2026-06-23 13:42',
        status: 'Draft saved',
        type: 'Exemption added',
        summary: 'RoHS 8(b) alternate draft imported.',
        rationale: 'Source review found an overlapping cadmium contact exemption.',
        source: 'RoHS source review',
        impact: 'Duplicate exemption code warning appears before publish.',
        user: 'Solutions Delivery'
      },
      {
        id: 'EXTXN-2026-0608-017',
        date: '2026-06-08 09:05',
        status: 'Published',
        type: 'Draft published',
        summary: 'RoHS Article Exemptions v4.1 published.',
        rationale: 'Article exemption update finalized after downstream impact review.',
        source: 'Publish impact review',
        impact: 'RoHS Directive DSL continued using the authoritative v4.1 set.',
        user: 'Solutions Delivery'
      }
    ]
  };

  readonly sourceTargetChecks = [
    { environment: 'UAT source', state: 'Ready', detail: '4,128 rows reconciled; action log complete.', severity: 'success' as Severity },
    { environment: 'ASM target', state: 'Clean', detail: 'Module structure and resources validate.', severity: 'success' as Severity },
    { environment: 'ASP target', state: 'Retry needed', detail: 'Importer timeout surfaced with retryable job id.', severity: 'warn' as Severity },
    { environment: 'Production', state: 'Blocked', detail: 'Lifecycle impact acceptance is still required.', severity: 'danger' as Severity }
  ];

  readonly exportSources: ExportSource[] = [
    { sourceId: 'EXP-SRC-001', sourceType: 'DSL', sourceName: 'EU RoHS DSL', parentDSL: 'EU RoHS DSL', substanceCount: 4820, groupCount: 12, subgroupCount: 38, archivedSubstanceCount: 310, lastUpdated: '2h ago', version: 'v4.2' },
    { sourceId: 'EXP-SRC-002', sourceType: 'DSL', sourceName: 'REACH Candidate List DSL', parentDSL: 'REACH Candidate List DSL', substanceCount: 1940, groupCount: 8, subgroupCount: 22, archivedSubstanceCount: 88, lastUpdated: '1d ago', version: 'v3.8' },
    { sourceId: 'EXP-SRC-003', sourceType: 'Group', sourceName: 'Restricted Metals Group', parentDSL: 'EU RoHS DSL', substanceCount: 420, groupCount: 0, subgroupCount: 5, archivedSubstanceCount: 22, lastUpdated: '3h ago', version: 'v2.7' },
    { sourceId: 'EXP-SRC-004', sourceType: 'Group', sourceName: 'Lead Compounds Group', parentDSL: 'EU RoHS DSL', substanceCount: 265, groupCount: 0, subgroupCount: 7, archivedSubstanceCount: 18, lastUpdated: '5h ago', version: 'v3.1' },
    { sourceId: 'EXP-SRC-005', sourceType: 'Subgroup', sourceName: 'Chromium VI Subgroup', parentDSL: 'EU RoHS DSL', parentGroup: 'Restricted Metals Group', substanceCount: 48, groupCount: 0, subgroupCount: 0, archivedSubstanceCount: 3, lastUpdated: '2d ago', version: 'v1.9' },
    { sourceId: 'EXP-SRC-006', sourceType: 'Group', sourceName: 'Phthalates Group', parentDSL: 'REACH Candidate List DSL', substanceCount: 188, groupCount: 0, subgroupCount: 4, archivedSubstanceCount: 7, lastUpdated: '1d ago', version: 'v4.3 draft' },
    { sourceId: 'EXP-SRC-007', sourceType: 'Subgroup', sourceName: 'Empty Test Subgroup', parentDSL: 'Internal Review DSL', parentGroup: 'Draft Group', substanceCount: 0, groupCount: 0, subgroupCount: 0, archivedSubstanceCount: 0, lastUpdated: '4d ago', version: 'Draft v0.1' },
    { sourceId: 'EXP-SRC-008', sourceType: 'DSL', sourceName: 'Global Restricted DSL', parentDSL: 'Global Restricted DSL', substanceCount: 12450, groupCount: 20, subgroupCount: 64, archivedSubstanceCount: 900, lastUpdated: '30m ago', version: 'v6.1' }
  ];

  readonly exportSubstances: ExportSubstance[] = [
    { sourceId: 'EXP-SRC-001', substanceId: 'MS-0042819', substanceName: 'Cadmium', CAS: '7440-43-9', EC: '231-152-8', group: 'Restricted Metals Group', subgroup: 'Cadmium compounds', status: 'Active', lastUpdated: '2026-06-30' },
    { sourceId: 'EXP-SRC-001', substanceId: 'MS-0042820', substanceName: 'Lead', CAS: '7439-92-1', EC: '231-100-4', group: 'Lead Compounds Group', subgroup: 'Lead metal', status: 'Active', lastUpdated: '2026-06-29' },
    { sourceId: 'EXP-SRC-001', substanceId: 'MS-0042836', substanceName: 'Chromium trioxide', CAS: '1333-82-0', EC: '215-607-8', group: 'Restricted Metals Group', subgroup: 'Chromium VI Subgroup', status: 'Active', lastUpdated: '2026-06-28' },
    { sourceId: 'EXP-SRC-001', substanceId: 'MS-0042877', substanceName: 'Potassium dichromate', CAS: '7778-50-9', EC: '231-906-6', group: 'Restricted Metals Group', subgroup: 'Chromium VI Subgroup', status: 'Archived', lastUpdated: '2026-06-14' },
    { sourceId: 'EXP-SRC-002', substanceId: 'MS-0042822', substanceName: 'Bis(2-ethylhexyl) phthalate', CAS: '117-81-7', EC: '204-211-0', group: 'Phthalates Group', subgroup: 'Short-chain Phthalates', status: 'Active', lastUpdated: '2026-06-29' },
    { sourceId: 'EXP-SRC-002', substanceId: 'MS-0042823', substanceName: 'Benzyl butyl phthalate', CAS: '85-68-7', EC: '201-622-7', group: 'Phthalates Group', subgroup: 'Short-chain Phthalates', status: 'Active', lastUpdated: '2026-06-29' },
    { sourceId: 'EXP-SRC-002', substanceId: 'MS-0042824', substanceName: 'Dibutyl phthalate', CAS: '84-74-2', EC: '201-557-4', group: 'Phthalates Group', subgroup: 'Short-chain Phthalates', status: 'Draft', lastUpdated: '2026-06-30' },
    { sourceId: 'EXP-SRC-003', substanceId: 'MS-0042819', substanceName: 'Cadmium', CAS: '7440-43-9', EC: '231-152-8', group: 'Restricted Metals Group', subgroup: 'Cadmium compounds', status: 'Active', lastUpdated: '2026-06-30' },
    { sourceId: 'EXP-SRC-003', substanceId: 'MS-0042836', substanceName: 'Chromium trioxide', CAS: '1333-82-0', EC: '215-607-8', group: 'Restricted Metals Group', subgroup: 'Chromium VI Subgroup', status: 'Active', lastUpdated: '2026-06-28' },
    { sourceId: 'EXP-SRC-004', substanceId: 'MS-0042820', substanceName: 'Lead', CAS: '7439-92-1', EC: '231-100-4', group: 'Lead Compounds Group', subgroup: 'Lead metal', status: 'Active', lastUpdated: '2026-06-29' },
    { sourceId: 'EXP-SRC-004', substanceId: 'MS-0042844', substanceName: 'Lead monoxide', CAS: '1317-36-8', EC: '215-267-0', group: 'Lead Compounds Group', subgroup: 'Lead oxides', status: 'Active', lastUpdated: '2026-06-27' },
    { sourceId: 'EXP-SRC-005', substanceId: 'MS-0042836', substanceName: 'Chromium trioxide', CAS: '1333-82-0', EC: '215-607-8', group: 'Restricted Metals Group', subgroup: 'Chromium VI Subgroup', status: 'Active', lastUpdated: '2026-06-28' },
    { sourceId: 'EXP-SRC-005', substanceId: 'MS-0042877', substanceName: 'Potassium dichromate', CAS: '7778-50-9', EC: '231-906-6', group: 'Restricted Metals Group', subgroup: 'Chromium VI Subgroup', status: 'Archived', lastUpdated: '2026-06-14' },
    { sourceId: 'EXP-SRC-006', substanceId: 'MS-0042822', substanceName: 'Bis(2-ethylhexyl) phthalate', CAS: '117-81-7', EC: '204-211-0', group: 'Phthalates Group', subgroup: 'Short-chain Phthalates', status: 'Active', lastUpdated: '2026-06-29' },
    { sourceId: 'EXP-SRC-006', substanceId: 'MS-0042834', substanceName: 'Diisobutyl phthalate', CAS: '84-69-5', EC: '201-553-2', group: 'Phthalates Group', subgroup: 'Short-chain Phthalates', status: 'Active', lastUpdated: '2026-06-21' },
    { sourceId: 'EXP-SRC-008', substanceId: 'MS-0198842', substanceName: 'Arsenic', CAS: '7440-38-2', EC: '231-148-6', group: 'Global restricted substances', subgroup: 'Metals', status: 'Active', lastUpdated: '2026-07-01' },
    { sourceId: 'EXP-SRC-008', substanceId: 'MS-0198843', substanceName: 'Nickel', CAS: '7440-02-0', EC: '231-111-4', group: 'Global restricted substances', subgroup: 'Metals', status: 'Active', lastUpdated: '2026-06-30' }
  ];

  exportRequests: ExportRequest[] = [
    { exportRequestId: 'EXREQ-2025-0910-001', sourceId: 'EXP-SRC-001', sourceType: 'DSL', sourceName: 'EU RoHS DSL', parentDSL: 'EU RoHS DSL', requestedBy: 'Emma Chen', requestedDate: '2025-09-10 09:12', exportFormat: 'Excel', includeArchived: false, includeMetadata: true, includeHierarchyColumns: true, includeExportTimestamp: true, estimatedRows: 4820, estimatedFileSize: '18.4 MB', status: 'Ready', fileName: 'EU_RoHS_DSL_export_2025_09_10.xlsx', rowCount: 4820, generatedDate: '2025-09-10 09:14' },
    { exportRequestId: 'EXREQ-2026-0601-014', sourceId: 'EXP-SRC-003', sourceType: 'Group', sourceName: 'Restricted Metals Group', parentDSL: 'EU RoHS DSL', requestedBy: 'Regulatory', requestedDate: '2026-06-01 11:30', exportFormat: 'CSV', includeArchived: true, includeMetadata: true, includeHierarchyColumns: true, includeExportTimestamp: true, estimatedRows: 420, estimatedFileSize: '1.8 MB', status: 'Downloaded', fileName: 'Restricted_Metals_Group_export.csv', rowCount: 420, generatedDate: '2026-06-01 11:31', downloadedDate: '2026-06-01 12:05' },
    { exportRequestId: 'EXREQ-2026-0701-003', sourceId: 'EXP-SRC-008', sourceType: 'DSL', sourceName: 'Global Restricted DSL', parentDSL: 'Global Restricted DSL', requestedBy: 'You', requestedDate: '2026-07-01 10:04', exportFormat: 'Excel', includeArchived: true, includeMetadata: true, includeHierarchyColumns: true, includeExportTimestamp: true, estimatedRows: 12450, estimatedFileSize: '48.7 MB', status: 'Generating', fileName: 'Global_Restricted_DSL_export.xlsx', rowCount: 12450 },
    { exportRequestId: 'EXREQ-2026-0628-009', sourceId: 'EXP-SRC-005', sourceType: 'Subgroup', sourceName: 'Chromium VI Subgroup', parentDSL: 'EU RoHS DSL', parentGroup: 'Restricted Metals Group', requestedBy: 'Maya Singh', requestedDate: '2026-06-28 15:48', exportFormat: 'CSV', includeArchived: false, includeMetadata: true, includeHierarchyColumns: true, includeExportTimestamp: true, estimatedRows: 48, estimatedFileSize: '260 KB', status: 'Failed', fileName: 'Chromium_VI_Subgroup_export.csv', rowCount: 48, failureMessage: 'The export service could not resolve one subgroup hierarchy path.', errorDetails: 'Hierarchy path GRP-ROHS-01 > SUB-CR6 returned a transient dependency lookup failure.' },
    { exportRequestId: 'EXREQ-2026-0630-018', sourceId: 'EXP-SRC-002', sourceType: 'DSL', sourceName: 'REACH Candidate List DSL', parentDSL: 'REACH Candidate List DSL', requestedBy: 'Ava Patel', requestedDate: '2026-06-30 13:20', exportFormat: 'Excel', includeArchived: false, includeMetadata: true, includeHierarchyColumns: true, includeExportTimestamp: true, estimatedRows: 1940, estimatedFileSize: '7.2 MB', status: 'Requested', fileName: 'REACH_Candidate_List_export.xlsx', rowCount: 1940 },
    { exportRequestId: 'EXREQ-2026-0627-004', sourceId: 'EXP-SRC-007', sourceType: 'Subgroup', sourceName: 'Empty Test Subgroup', parentDSL: 'Internal Review DSL', parentGroup: 'Draft Group', requestedBy: 'System', requestedDate: '2026-06-27 08:22', exportFormat: 'CSV', includeArchived: false, includeMetadata: true, includeHierarchyColumns: true, includeExportTimestamp: true, estimatedRows: 0, estimatedFileSize: '0 KB', status: 'Failed', fileName: 'Empty_Test_Subgroup_export.csv', rowCount: 0, failureMessage: 'No substances are available for export from this source.', errorDetails: 'The selected subgroup contains no active or archived substances.' }
  ];

  exportFiles: ExportFile[] = [
    { exportFileId: 'EXFILE-2025-0910-001', exportRequestId: 'EXREQ-2025-0910-001', fileName: 'EU_RoHS_DSL_export_2025_09_10.xlsx', fileFormat: 'Excel', rowCount: 4820, generatedDate: '2025-09-10 09:14', downloadUrl: '#', status: 'Ready' },
    { exportFileId: 'EXFILE-2026-0601-014', exportRequestId: 'EXREQ-2026-0601-014', fileName: 'Restricted_Metals_Group_export.csv', fileFormat: 'CSV', rowCount: 420, generatedDate: '2026-06-01 11:31', downloadUrl: '#', status: 'Downloaded' }
  ];

  exportAuditEvents: ExportAuditEvent[] = [
    { id: 'EXAUD-001', exportRequestId: 'EXREQ-2025-0910-001', user: 'Emma Chen', dateTime: '2025-09-10 09:12', action: 'Export requested', source: 'EU RoHS DSL', fileName: 'EU_RoHS_DSL_export_2025_09_10.xlsx', status: 'Requested' },
    { id: 'EXAUD-002', exportRequestId: 'EXREQ-2025-0910-001', user: 'System', dateTime: '2025-09-10 09:14', action: 'Export generated', source: 'EU RoHS DSL', fileName: 'EU_RoHS_DSL_export_2025_09_10.xlsx', status: 'Ready' },
    { id: 'EXAUD-003', exportRequestId: 'EXREQ-2026-0601-014', user: 'Regulatory', dateTime: '2026-06-01 11:30', action: 'Export requested', source: 'Restricted Metals Group', fileName: 'Restricted_Metals_Group_export.csv', status: 'Requested' },
    { id: 'EXAUD-004', exportRequestId: 'EXREQ-2026-0601-014', user: 'Regulatory', dateTime: '2026-06-01 12:05', action: 'Export downloaded', source: 'Restricted Metals Group', fileName: 'Restricted_Metals_Group_export.csv', status: 'Downloaded' },
    { id: 'EXAUD-005', exportRequestId: 'EXREQ-2026-0628-009', user: 'System', dateTime: '2026-06-28 15:49', action: 'Export failed', source: 'Chromium VI Subgroup', fileName: 'Chromium_VI_Subgroup_export.csv', status: 'Failed' },
    { id: 'EXAUD-006', exportRequestId: 'EXREQ-2026-0701-003', user: 'You', dateTime: '2026-07-01 10:04', action: 'Export requested', source: 'Global Restricted DSL', fileName: 'Global_Restricted_DSL_export.xlsx', status: 'Generating' }
  ];

  readonly downloadJobs: ExportJob[] = [
    {
      name: 'Master substances review export',
      scope: 'Indexed subset, identifiers, references, and audit flags',
      format: 'XLSX',
      status: 'Ready',
      surface: 'substances',
      fileId: 'SUB-REV-20260622-044',
      downloadedAt: 'Jun 22, 2026 14:10',
      includedFields: 'Name, aliases, CAS #, EC #, source, dependency counts',
      lockState: 'Unlocked'
    },
    {
      name: 'REACH SVHC download for review',
      scope: '4,128 substances, 38 groups/subgroups, 2 exemption sets',
      format: 'XLSX',
      status: 'Ready',
      surface: 'lists',
      fileId: 'DSL-REV-20260623-018',
      downloadedAt: 'Jun 23, 2026 07:01',
      parentId: 'DSL-00007',
      parentName: 'REACH SVHC',
      recordCount: '4,128 substances + 38 groups/subgroups + 2 exemption sets',
      includedFields: 'Parent item, downloaded date, substance name, aliases, CAS #, EC #, effective date, notes',
      lockState: 'Unlocked',
      lockOwner: 'Jeff Tengwall'
    },
    {
      name: 'Phthalates group review pack',
      scope: '6 substances, 12 consuming DSLs, action log',
      format: 'XLSX + CSV',
      status: 'Ready',
      surface: 'groups',
      fileId: 'GRP-REV-20260620-067',
      downloadedAt: 'Jun 20, 2026 10:42',
      parentName: 'Phthalates',
      includedFields: 'Parent group, subgroup path, substance name, aliases, CAS #, EC #',
      lockState: 'Unlocked'
    },
    { name: 'PFAS group review pack', scope: '5,732 substances with source references', format: 'XLSX', status: 'Reviewing', surface: 'groups', fileId: 'GRP-REV-20260621-031', downloadedAt: 'Jun 21, 2026 16:30', parentName: 'PFAS', includedFields: 'Parent group, substance metadata, source evidence', lockState: 'Unlocked' },
    { name: 'REACH SVHC customer preview bundle', scope: 'Module package, resource links, version note', format: 'HTML', status: 'Draft', surface: 'modules', fileId: 'MOD-REV-20260618-009', downloadedAt: 'Queued', parentName: 'REACH SVHC Module', lockState: 'Unlocked' }
  ];

  readonly customerPreviews = [
    { module: 'REACH SVHC Module', environment: 'UAT ASM', customers: 184, state: 'Ready', notes: 'Shows DBP addition, effective date, and support-resource warning before deployment.' },
    { module: 'REACH SVHC Module', environment: 'ASP equivalent', customers: 184, state: 'Needs verification', notes: 'Smoke test queued because ASM/SUPO paths are changing.' },
    { module: 'PFAS Module', environment: 'UAT ASM', customers: 76, state: 'Blocked', notes: 'Importer sync must pass before a customer-safe preview can be shared.' }
  ];

  readonly bulkSteps: BulkWorkflowStep[] = [
    { key: 'template', label: 'Template', description: 'Choose the right structure before edits begin.' },
    { key: 'upload', label: 'Upload', description: 'Drop in a completed template or source file.' },
    { key: 'validate', label: 'Validate', description: 'Check schema, identifiers, matches, and dates.' },
    { key: 'review', label: 'Review', description: 'Commit clean rows and leave conflicts staged.' }
  ];

  readonly bulkTemplates: BulkTemplate[] = [
    {
      id: 'substances',
      label: 'Substances',
      scope: 'Create or update authoritative substance records',
      description: 'Use for names, CAS, EC, authority, source, aliases, and archive flags.',
      columns: 'Master ID, name, CAS, EC, authority, source, aliases, status, reason',
      icon: 'pi pi-sitemap'
    },
    {
      id: 'groups',
      label: 'Groups and subgroups',
      scope: 'Add, remove, or nest group members by reference',
      description: 'Use for group membership updates, thresholds, effective dates, and subgroup links.',
      columns: 'Group ID, member ID, CAS, EC, threshold, effective date, action',
      icon: 'pi pi-th-large'
    },
    {
      id: 'lists',
      label: 'DSL lists',
      scope: 'Update list contents with substances, groups, and exemption sets',
      description: 'Use for DSL membership, inclusion criteria, internal notes, and external notes.',
      columns: 'DSL ID, item type, item ID, effective date, criteria, notes',
      icon: 'pi pi-list-check'
    },
    {
      id: 'exemptions',
      label: 'Exemption sets',
      scope: 'Maintain reusable exemptions and expiry details',
      description: 'Use for exemption codes, thresholds, applicability, and expiry windows.',
      columns: 'Set ID, exemption code, description, threshold min/max, applies to, expiry',
      icon: 'pi pi-shield'
    }
  ];

  readonly bulkValidationChecks: BulkValidationCheck[] = [
    {
      id: 'structure',
      label: 'Template structure',
      detail: 'Required columns found and file scope detected.',
      severity: 'success',
      status: 'Passed',
      icon: 'pi pi-check-circle',
      rows: 'All rows',
      evidence: 'The file contains required group, member, threshold, effective date, and action columns.',
      action: 'No reviewer action needed.'
    },
    {
      id: 'matching',
      label: 'Identifier matching',
      detail: '24 rows matched by Master ID, CAS, EC, or alias.',
      severity: 'success',
      status: 'Passed',
      icon: 'pi pi-check-circle',
      rows: '24 rows',
      evidence: 'Matches are tied to existing authoritative records so duplicates are not created.',
      action: 'Clean matches can be staged after review.'
    },
    {
      id: 'duplicates',
      label: 'Potential duplicates',
      detail: '3 rows need review before they can become authoritative records.',
      severity: 'warn',
      status: 'Review',
      icon: 'pi pi-exclamation-triangle',
      rows: 'Rows 31, 44, 52',
      evidence: 'The system found similar names, aliases, or authority conflicts that require a Regulatory decision.',
      action: 'Review affected rows and decide whether to link, alias, or leave staged.'
    },
    {
      id: 'dates',
      label: 'Effective dates',
      detail: '1 row has a future date that needs reviewer confirmation.',
      severity: 'warn',
      status: 'Review',
      icon: 'pi pi-exclamation-triangle',
      rows: 'Row 57',
      evidence: 'The proposed effective date is after the current activation window.',
      action: 'Confirm whether the future date should be staged or corrected.'
    },
    {
      id: 'commit',
      label: 'Commit safety',
      detail: 'Clean rows can be staged without changing production.',
      severity: 'info',
      status: 'Review',
      icon: 'pi pi-shield',
      rows: 'Ready rows',
      evidence: 'Committing this upload creates draft or staging records only.',
      action: 'Review the clean rows before staging them.'
    }
  ];

  readonly bulkReviewRows: BulkReviewRow[] = [
    {
      row: '12',
      item: 'Dibutyl phthalate',
      issue: 'commit',
      change: 'Add to Phthalates draft',
      match: 'CAS 84-74-2 matched existing staged record',
      status: 'Ready',
      decision: 'Stage as draft member',
      severity: 'success',
      evidence: 'Existing staged DBP record is already tied to the Phthalates draft definition.',
      nextAction: 'Accept this row into the draft group update, or defer it if the activation window is not ready.',
      owner: 'Regulatory'
    },
    {
      row: '18',
      item: 'Cadmium oxide alternate name',
      issue: 'matching',
      change: 'Add alias to existing substance',
      match: 'CAS 1306-19-0 matched Cadmium compound candidate',
      status: 'Ready',
      decision: 'Append alias, no duplicate record',
      severity: 'success',
      evidence: 'CAS and authority point to an existing substance; the uploaded name is not authoritative yet.',
      nextAction: 'Add the uploaded value as an alias so search and future imports can match it.',
      owner: 'Regulatory'
    },
    {
      row: '31',
      item: 'Unknown flame retardant blend',
      issue: 'duplicates',
      change: 'Create new substance',
      match: 'No CAS or EC supplied',
      status: 'Needs review',
      decision: 'Leave in staging queue',
      severity: 'warn',
      evidence: 'The row has no stable identifier, and two similar aliases exist in supplier-entered data.',
      nextAction: 'Choose whether this should link to an existing substance, become a staged candidate, or be deferred.',
      owner: 'Chaukat'
    },
    {
      row: '44',
      item: 'PFHxA related substance',
      issue: 'duplicates',
      change: 'Update authority and source',
      match: 'Alias conflict across EPA and ECHA',
      status: 'Conflict',
      decision: 'Regulatory review required',
      severity: 'danger',
      evidence: 'EPA and ECHA references disagree on the preferred authority name for this alias.',
      nextAction: 'Resolve the authority conflict before this row can be staged.',
      owner: 'Regulatory'
    },
    {
      row: '52',
      item: 'Lead chromate synonym',
      issue: 'duplicates',
      change: 'Add alias to group member',
      match: 'Similar alias already exists under Lead compounds',
      status: 'Needs review',
      decision: 'Confirm alias before staging',
      severity: 'warn',
      evidence: 'The uploaded synonym is close to an existing Lead compounds alias but differs by punctuation.',
      nextAction: 'Confirm this is a valid alias, link it to the existing record, or defer it for later review.',
      owner: 'Regulatory'
    },
    {
      row: '57',
      item: 'Perfluorohexanoic acid group link',
      issue: 'dates',
      change: 'Set future effective date',
      match: 'Existing group member, date proposed for next activation cycle',
      status: 'Needs review',
      decision: 'Confirm 2026-07-01 effective date',
      severity: 'warn',
      evidence: 'The uploaded effective date is after the current activation window and could alter future collection only.',
      nextAction: 'Confirm the future date, edit it, or keep the row staged for the next activation cycle.',
      owner: 'Regulatory'
    }
  ];

  constructor(private readonly messages: MessageService) {
    this.activeSubstance = this.substances[0];
    this.selectedExportSource = this.exportSources[0];
  }

  ngOnInit(): void {
    const requestedPage = new URLSearchParams(window.location.search).get('page') as PageKey | null;
    if (requestedPage && this.pageCopy[requestedPage]) {
      this.activePage = requestedPage;
    }
    this.ensureSubstanceIndexLoaded();
  }

  ngOnDestroy(): void {
    this.clearSubstanceLoadTimer();
    this.clearGroupLoadTimer();
    this.clearWorkspaceLoadTimer();
    this.clearAssessmentGenerationTimer();
  }

	  get pageTitle(): string {
	    if (this.activePage === 'groups' && this.activeGroup) {
	      return this.activeGroup.name;
	    }
    if (this.activePage === 'exemptions' && this.activeExemptionSet) {
      return this.activeExemptionSet.name;
    }
	    if (this.activePage === 'lists' && this.activeDslList) {
	      return this.activeDslList.name;
	    }
	    if (this.activePage === 'modules' && this.activeModule) {
	      return this.activeModule.name;
	    }
	    return this.pageCopy[this.activePage].title;
	  }

  get pageKicker(): string {
    if (this.activePage === 'groups' && this.activeGroup) {
      return 'Library / Groups';
    }
    if (this.activePage === 'exemptions' && this.activeExemptionSet) {
      return 'Library / Exemption sets';
    }
	    if (this.activePage === 'lists' && this.activeDslList) {
	      return 'Library / DSL lists';
	    }
	    if (this.activePage === 'modules' && this.activeModule) {
	      return 'Library / DSL modules';
	    }
	    return this.pageCopy[this.activePage].kicker;
	  }

  get pageSubtitle(): string {
    if (this.activePage === 'groups' && this.activeGroup) {
      return `${this.activeGroup.description} One canonical group is referenced by ${this.activeGroup.dslCount} DSLs.`;
    }
    if (this.activePage === 'exemptions' && this.activeExemptionSet) {
      return `${this.activeExemptionSet.description} Exemptions are reusable, versioned, and evaluated against substance or group applicability.`;
    }
	    if (this.activePage === 'lists' && this.activeDslList) {
	      return `${this.activeDslList.description} Contents are referenced, not copied, so each substance, group, and exemption keeps its own effective date and notes.`;
	    }
	    if (this.activePage === 'modules' && this.activeModule) {
	      return `${this.activeModule.description} Finalize the package as Ready before it moves to the deployment queue.`;
	    }
	    return this.pageCopy[this.activePage].subtitle;
	  }

  get visibleGroups(): SubstanceGroup[] {
    const query = this.normalizeQuery(this.groupQuery);
    const matches = this.groupScopeRows().filter((group) => {
      const matchesQuery = !query || [
        group.name,
        group.id,
        group.description,
        group.owner,
        group.status,
        group.signal,
        group.version
      ].join(' ').toLowerCase().includes(query);
      return matchesQuery;
    });
    return this.sortGroupsForFilter(this.filterGroupsByQuick(matches, this.groupFilter));
  }

  get groupRows(): GroupTableRow[] {
    return this.isGroupLoading ? this.groupSkeletonRows : this.visibleGroups;
  }

  get visibleExemptionSets(): ExemptionSet[] {
    const query = this.normalizeQuery(this.exemptionSetQuery);
    const matches = this.exemptionSets.filter((set) => {
      const matchesQuery = !query || [
        set.code,
        set.name,
        set.description,
        set.authority,
        set.scope,
        set.version,
        set.status,
        set.owner,
        set.created,
        set.modified,
        set.lastPublished,
        set.publishedBy,
        ...set.warnings.map((warning) => this.exemptionWarningLabel(warning))
      ].join(' ').toLowerCase().includes(query);
      return matchesQuery;
    });
    return this.filterExemptionSets(matches, this.exemptionSetFilter);
  }

  get exemptionSetListSummary(): string {
    const filterLabel = this.exemptionSetFilter === 'all' ? '' : `${this.activeExemptionSetFilterLabel.toLowerCase()} `;
    return `${this.visibleExemptionSets.length} ${filterLabel}exemption set${this.visibleExemptionSets.length === 1 ? '' : 's'} shown`;
  }

  get activeExemptionSetFilterLabel(): string {
    return this.exemptionSetQuickFilters.find((filter) => filter.key === this.exemptionSetFilter)?.label || 'All';
  }

  get exemptionSetDraftCount(): number {
    return this.exemptionSets.filter((set) => set.status === 'Draft' || set.version.startsWith('Draft')).length;
  }

  get exemptionSetPublishedCount(): number {
    return this.exemptionSets.filter((set) => set.status === 'Published').length;
  }

  get exemptionSetExpiryRiskCount(): number {
    return this.exemptionSets.filter((set) => set.expiryWatchCount > 0 || set.status === 'Expiring soon' || set.status === 'Expired').length;
  }

  get exemptionSetWarningCount(): number {
    return this.exemptionSets.filter((set) => this.exemptionWarningCountForSet(set) > 0).length;
  }

  get activeExemptionSetExemptions(): ExemptionRecord[] {
    if (!this.activeExemptionSet) {
      return [];
    }
    return this.exemptionRecords.filter((exemption) => exemption.setCode === this.activeExemptionSet?.code);
  }

  get activeExemptionSetVisibleExemptions(): ExemptionRecord[] {
    return this.activeExemptionSetExemptions.filter((exemption) => exemption.status !== 'Archived');
  }

  get activeExemptionSetDraftChangeCount(): number {
    return this.activeExemptionSetExemptions.filter((exemption) => exemption.status === 'Draft add' || exemption.status === 'Draft edit').length;
  }

  get activeExemptionSetWarnings(): ExemptionWarningKey[] {
    const warnings = new Set<ExemptionWarningKey>(this.activeExemptionSet?.warnings || []);
    this.activeExemptionSetExemptions.forEach((exemption) => {
      this.collectExemptionWarningKeys(exemption).forEach((warning) => warnings.add(warning));
    });
    return [...warnings];
  }

  get activeExemptionSetDslReferences(): ExemptionSetDslReference[] {
    if (!this.activeExemptionSet) {
      return [];
    }
    return this.exemptionSetDslReferences.filter((reference) => reference.setCode === this.activeExemptionSet?.code);
  }

  get activeExemptionSetVersions(): ExemptionSetVersionRecord[] {
    if (!this.activeExemptionSet) {
      return [];
    }
    return this.exemptionSetVersions.filter((version) => version.setCode === this.activeExemptionSet?.code);
  }

  get activeExemptionSetApplicabilityRecords(): ExemptionApplicability[] {
    const keyed = new Map<string, ExemptionApplicability>();
    this.activeExemptionSetExemptions.forEach((exemption) => {
      exemption.applicability.forEach((record) => {
        keyed.set(`${record.kind}-${record.id}`, record);
      });
    });
    return [...keyed.values()];
  }

  get activeExemptionSetApplicabilitySubstanceCount(): number {
    return this.activeExemptionSetApplicabilityRecords.filter((record) => record.kind === 'Substance').length;
  }

  get activeExemptionSetApplicabilityGroupCount(): number {
    return this.activeExemptionSetApplicabilityRecords.filter((record) => record.kind === 'Group').length;
  }

  get activeExemptionDraftWarningKeys(): ExemptionWarningKey[] {
    return this.collectExemptionWarningKeys(this.activeExemptionDraft);
  }

  get activeExemptionPublishWarnings(): string[] {
    const warnings = new Set<string>();
    this.activeExemptionSetWarnings.forEach((warning) => warnings.add(this.exemptionWarningLabel(warning)));
    const expired = this.activeExemptionSetExemptions.filter((exemption) => exemption.status === 'Expired' || this.isExpiredDate(exemption.expiryDate)).length;
    const expiringSoon = this.activeExemptionSetExemptions.filter((exemption) => this.isExpiringSoonDate(exemption.expiryDate)).length;
    if (expired) {
      warnings.add(`${expired} expired exemption${expired === 1 ? '' : 's'}`);
    }
    if (expiringSoon) {
      warnings.add(`${expiringSoon} exemption${expiringSoon === 1 ? '' : 's'} close to expiry`);
    }
    if (this.activeExemptionSetDslReferences.length) {
      warnings.add(`${this.activeExemptionSetDslReferences.length} downstream DSL reference${this.activeExemptionSetDslReferences.length === 1 ? '' : 's'} may be affected`);
    }
    return [...warnings];
  }

  get canPublishActiveExemptionSet(): boolean {
    return Boolean(this.activeExemptionSet?.versionNote.trim());
  }

  get canArchiveActiveExemptionSet(): boolean {
    if (!this.activeExemptionSet) {
      return false;
    }
    return this.activeExemptionSet.dslReferenceCount === 0 || this.exemptionArchiveReason.trim().length >= 8;
  }

  get exemptionApplicabilityCandidates(): ExemptionApplicability[] {
    const query = this.normalizeQuery(this.exemptionApplicabilityQuery);
    const existingKeys = new Set(this.activeExemptionDraft.applicability.map((record) => `${record.kind}-${record.id}`));
    const substanceCandidates = this.substances
      .filter((substance) => !existingKeys.has(`Substance-${substance.id}`))
      .filter((substance) => !query || [
        substance.id,
        substance.name,
        substance.cas,
        substance.ec,
        substance.authority,
        substance.aliasNames
      ].join(' ').toLowerCase().includes(query))
      .slice(0, 5)
      .map((substance) => ({
        kind: 'Substance' as const,
        id: substance.id,
        name: substance.name,
        detail: `CAS ${substance.cas} · EC ${substance.ec}`
      }));
    const groupCandidates = this.groups
      .filter((group) => !existingKeys.has(`Group-${group.id}`))
      .filter((group) => !query || [
        group.id,
        group.name,
        group.description,
        group.owner,
        group.version
      ].join(' ').toLowerCase().includes(query))
      .slice(0, 5)
      .map((group) => ({
        kind: 'Group' as const,
        id: group.id,
        name: group.name,
        detail: `${group.members} substances · ${group.version}`
      }));
    return [...substanceCandidates, ...groupCandidates];
  }

	  get visibleDslLists(): DslList[] {
	    const query = this.normalizeQuery(this.dslListQuery);
	    const matches = this.dslLists.filter((list) => {
      const matchesQuery = !query || [
        list.id,
        list.name,
        list.description,
        list.authority,
        list.version,
        list.versionNote,
        list.status,
        list.owner,
        list.scope
      ].join(' ').toLowerCase().includes(query);
      return matchesQuery;
    });
	    return this.filterDslLists(matches, this.dslListFilter);
	  }

	  get visibleModules(): ModuleRecord[] {
	    const query = this.normalizeQuery(this.moduleQuery);
	    const matches = this.modules.filter((module) => {
	      const matchesQuery = !query || [
	        module.id,
	        module.name,
	        module.description,
	        module.list,
	        module.listId,
	        module.version,
	        module.versionNote,
	        module.owner,
	        module.status,
	        module.impact,
	        ...module.resources.flatMap((resource) => [resource.name, resource.type, resource.status, resource.detail])
	      ].join(' ').toLowerCase().includes(query);
	      return matchesQuery;
	    });
	    return this.filterModules(matches, this.moduleFilter);
	  }

	  get moduleListSummary(): string {
	    const filterLabel = this.moduleFilter === 'all' ? '' : `${this.activeModuleFilterLabel.toLowerCase()} `;
	    return `${this.visibleModules.length} ${filterLabel}module${this.visibleModules.length === 1 ? '' : 's'} shown`;
	  }

	  get activeModuleFilterLabel(): string {
	    if (this.moduleFilter === 'drafts') {
	      return 'Draft';
	    }
	    if (this.moduleFilter === 'ready') {
	      return 'Ready';
	    }
	    if (this.moduleFilter === 'blocked') {
	      return 'Blocked';
	    }
	    return 'All';
	  }

	  get moduleDraftCount(): number {
	    return this.modules.filter((module) => module.status === 'Draft').length;
	  }

	  get moduleReadyCount(): number {
	    return this.modules.filter((module) => module.status === 'Ready').length;
	  }

	  get moduleBlockedCount(): number {
	    return this.modules.filter((module) => module.status === 'Blocked').length;
	  }

	  get moduleListCandidates(): DslList[] {
	    return this.dslLists;
	  }

	  get filteredModuleListCandidates(): DslList[] {
	    const query = this.normalizeQuery(this.moduleListQuery);
	    if (!query) {
	      return this.moduleListCandidates;
	    }
	    return this.moduleListCandidates.filter((list) => [
	      list.id,
	      list.name,
	      list.description,
	      list.authority,
	      list.status,
	      list.version,
	      list.owner
	    ].join(' ').toLowerCase().includes(query));
	  }

	  get moduleListCandidateSummary(): string {
	    const total = this.moduleListCandidates.length;
	    const shown = this.filteredModuleListCandidates.length;
	    if (shown === total) {
	      return `${shown} DSL list${shown === 1 ? '' : 's'} available. Select one primary list for this module.`;
	    }
	    return `${shown} of ${total} DSL list${total === 1 ? '' : 's'} match. Select one primary list for this module.`;
	  }

  get activeExportSource(): ExportSource {
    return this.selectedExportSource || this.exportSources[0];
  }

  get exportEntrySources(): ExportSource[] {
    return [
      this.exportSources.find((source) => source.sourceId === 'EXP-SRC-001'),
      this.exportSources.find((source) => source.sourceId === 'EXP-SRC-003'),
      this.exportSources.find((source) => source.sourceId === 'EXP-SRC-005')
    ].filter((source): source is ExportSource => Boolean(source));
  }

  get exportSourceTree(): TreeNode<ExportSource>[] {
    const dslSources = this.exportSources.filter((source) => source.sourceType === 'DSL');
    return dslSources.map((dsl) => ({
      data: dsl,
      expanded: dsl.sourceId === this.activeExportSource.sourceId || dsl.sourceName === this.activeExportSource.parentDSL,
      children: this.exportSources
        .filter((source) => source.sourceType === 'Group' && source.parentDSL === dsl.sourceName)
        .map((group) => ({
          data: group,
          expanded: group.sourceId === this.activeExportSource.sourceId || group.sourceName === this.activeExportSource.parentGroup,
          children: this.exportSources
            .filter((source) => source.sourceType === 'Subgroup' && source.parentGroup === group.sourceName)
            .map((subgroup) => ({ data: subgroup }))
        }))
    }));
  }

  get exportContentRows(): ExportSubstance[] {
    const source = this.activeExportSource;
    const sourceRows = this.exportSubstances.filter((row) => row.sourceId === source.sourceId);
    const query = this.normalizeQuery(this.exportContentQuery);
    return sourceRows.filter((row) => {
      if (this.exportStatusFilter !== 'All statuses' && row.status !== this.exportStatusFilter) {
        return false;
      }
      if (this.exportGroupFilter !== 'All groups' && row.group !== this.exportGroupFilter) {
        return false;
      }
      if (this.exportSubgroupFilter !== 'All subgroups' && row.subgroup !== this.exportSubgroupFilter) {
        return false;
      }
      if (!query) {
        return true;
      }
      return [
        row.substanceId,
        row.substanceName,
        row.CAS,
        row.EC,
        row.group,
        row.subgroup,
        row.status,
        row.lastUpdated
      ].join(' ').toLowerCase().includes(query);
    });
  }

  get exportSourceSubstances(): ExportSubstance[] {
    return this.exportSubstances.filter((row) => row.sourceId === this.activeExportSource.sourceId);
  }

  get exportSubstanceStatusOptions(): string[] {
    return ['All statuses', 'Active', 'Archived', 'Draft'];
  }

  get exportGroupOptions(): string[] {
    const groups = Array.from(new Set(this.exportSourceSubstances.map((row) => row.group).filter(Boolean)));
    return ['All groups', ...groups];
  }

  get exportSubgroupOptions(): string[] {
    const subgroups = Array.from(new Set(this.exportSourceSubstances.map((row) => row.subgroup).filter(Boolean)));
    return ['All subgroups', ...subgroups];
  }

  get activeExportEstimate(): ExportEstimate {
    return this.estimateExportSize(this.activeExportSource.sourceId, this.exportConfig);
  }

  get activeExportLastRequest(): ExportRequest | undefined {
    return this.exportRequests
      .filter((request) => request.sourceId === this.activeExportSource.sourceId)
      .sort((a, b) => b.requestedDate.localeCompare(a.requestedDate))[0];
  }

  get activeExportLastExportLabel(): string {
    const request = this.activeExportLastRequest;
    if (!request) {
      return 'Never';
    }
    return `${request.status} ${request.requestedDate}`;
  }

  get exportCtaLabel(): string {
    if (this.activeExportSource.sourceType === 'DSL') {
      return 'Export full DSL';
    }
    if (this.activeExportSource.sourceType === 'Group') {
      return 'Export selected group';
    }
    return 'Export selected subgroup';
  }

  get exportHistoryRows(): ExportRequest[] {
    return this.exportRequests.filter((request) => {
      if (this.exportHistorySourceTypeFilter !== 'All types' && request.sourceType !== this.exportHistorySourceTypeFilter) {
        return false;
      }
      if (this.exportHistoryStatusFilter !== 'All statuses' && request.status !== this.exportHistoryStatusFilter) {
        return false;
      }
      if (this.exportHistoryRequestedByFilter !== 'All users' && request.requestedBy !== this.exportHistoryRequestedByFilter) {
        return false;
      }
      if (this.exportHistoryFormatFilter !== 'All formats' && request.exportFormat !== this.exportHistoryFormatFilter) {
        return false;
      }
      if (this.exportHistoryDateRangeFilter === 'Last 7 days') {
        return request.requestedDate >= '2026-06-24';
      }
      if (this.exportHistoryDateRangeFilter === 'Last 30 days') {
        return request.requestedDate >= '2026-06-01';
      }
      return true;
    });
  }

  get exportHistorySourceTypeOptions(): string[] {
    return ['All types', 'DSL', 'Group', 'Subgroup'];
  }

  get exportHistoryStatusOptions(): string[] {
    return ['All statuses', 'Requested', 'Generating', 'Ready', 'Downloaded', 'Failed', 'Retrying', 'Expired'];
  }

  get exportHistoryRequestedByOptions(): string[] {
    return ['All users', ...Array.from(new Set(this.exportRequests.map((request) => request.requestedBy)))];
  }

  get exportHistoryDateRangeOptions(): string[] {
    return ['All dates', 'Last 7 days', 'Last 30 days'];
  }

  get exportHistoryFormatOptions(): string[] {
    return ['All formats', 'CSV', 'Excel'];
  }

  get selectedExportFile(): ExportFile | undefined {
    if (!this.selectedExportRequest) {
      return undefined;
    }
    return this.exportFiles.find((file) => file.exportRequestId === this.selectedExportRequest?.exportRequestId);
  }

  get selectedExportAuditEvents(): ExportAuditEvent[] {
    if (!this.selectedExportRequest) {
      return [];
    }
    return this.exportAuditEvents.filter((event) => event.exportRequestId === this.selectedExportRequest?.exportRequestId);
  }

  get dslListSummary(): string {
    const filterLabel = this.dslListFilter === 'all' ? '' : `${this.activeDslListFilterLabel.toLowerCase()} `;
    return `${this.visibleDslLists.length} ${filterLabel}DSL list${this.visibleDslLists.length === 1 ? '' : 's'} shown`;
  }

  get activeDslListFilterLabel(): string {
    if (this.dslListFilter === 'drafts') {
      return 'Draft';
    }
    if (this.dslListFilter === 'large') {
      return 'Large';
    }
    if (this.dslListFilter === 'custom') {
      return 'Custom';
    }
    return 'All';
  }

  get dslDraftCount(): number {
    return this.dslLists.filter((list) => list.status === 'Draft').length;
  }

  get dslLargeCount(): number {
    return this.dslLists.filter((list) => list.substances + list.groups >= 2500).length;
  }

  get dslCustomCount(): number {
    return this.dslLists.filter((list) => list.scope === 'Custom').length;
  }

  get activeDslContents(): DslContentItem[] {
    return this.dslContentItems.filter((item) => item.status !== 'Draft remove');
  }

  get visibleDslContents(): DslContentItem[] {
    const query = this.normalizeQuery(this.dslContentQuery);
    if (!query) {
      return this.activeDslContents;
    }
    return this.activeDslContents.filter((item) => [
      item.id,
      item.name,
      item.kind,
      item.authority,
      item.version || '',
      item.cas || '',
      item.ec || '',
      item.effective,
      item.inclusion,
      item.internalNote,
      item.externalNote,
      ...(item.children || []).flatMap((child) => [child.id, child.name, child.cas || '', child.ec || '', child.kind])
    ].join(' ').toLowerCase().includes(query));
  }

  get pagedVisibleDslContents(): DslContentItem[] {
    const rows = this.visibleDslContents;
    const first = Math.min(this.dslContentPageFirst, this.lastDslContentPageFirst(rows.length));
    return rows.slice(first, first + this.dslContentRows);
  }

  get dslContentPageStart(): number {
    if (!this.visibleDslContents.length) {
      return 0;
    }
    return Math.min(this.dslContentPageFirst, this.lastDslContentPageFirst(this.visibleDslContents.length)) + 1;
  }

  get dslContentPageEnd(): number {
    if (!this.visibleDslContents.length) {
      return 0;
    }
    return Math.min(this.dslContentPageStart + this.dslContentRows - 1, this.visibleDslContents.length);
  }

  get activeDslDirectSubstanceCount(): number {
    return this.activeDslContents.filter((item) => item.kind === 'Substance').length;
  }

  get activeDslGroupCount(): number {
    return this.activeDslContents.filter((item) => item.kind === 'Group').length;
  }

  get activeDslExemptionReferences(): DslExemptionReference[] {
    return this.dslExemptionReferences;
  }

  get activeDslReviewLock(): ExportJob | undefined {
    if (!this.activeDslList) {
      return undefined;
    }
    return this.downloadJobs.find((job) =>
      job.surface === 'lists' &&
      job.parentId === this.activeDslList?.id &&
      job.lockState === 'Locked'
    );
  }

  get isActiveDslLockedForReview(): boolean {
    return Boolean(this.activeDslReviewLock);
  }

  get activeDslDraftAddCount(): number {
    const contentAdds = this.dslContentItems.filter((item) => item.status === 'Draft add').length;
    const exemptionAdds = this.dslExemptionReferences.filter((reference) => reference.status === 'Draft add').length;
    return contentAdds + exemptionAdds;
  }

  get activeDslDraftRemoveCount(): number {
    const contentRemovals = this.dslContentItems.filter((item) => item.status === 'Draft remove').length;
    const exemptionRemovals = this.dslExemptionReferences.filter((reference) => reference.status === 'Draft remove').length;
    return contentRemovals + exemptionRemovals;
  }

  get archiveCandidateGroupOptions(): string[] {
    return [...new Set(this.archiveCandidateSubstances.flatMap((substance) => [substance.groupName, substance.subgroupName]).filter(Boolean))].sort();
  }

  get visibleArchiveCandidates(): ArchiveCandidateSubstance[] {
    const query = this.normalizeQuery(this.archiveSearchQuery);
    return this.archiveCandidateSubstances.filter((substance) => {
      const assessment = this.impactAssessmentForSubstance(substance.substanceId);
      const matchesContext = this.archiveParentFilter === 'All' || substance.parentType === this.archiveParentFilter;
      const matchesStatus = !this.archiveStatusFilter.length || this.archiveStatusFilter.includes(substance.status);
      const matchesGroup = !this.archiveGroupFilter.length || [substance.groupName, substance.subgroupName].some((value) => this.archiveGroupFilter.includes(value));
      const matchesImpact = !this.archiveImpactFilter.length || Boolean(assessment && this.archiveImpactFilter.includes(assessment.overallImpactSeverity));
      const matchesQuery = !query || [
        substance.substanceId,
        substance.substanceName,
        substance.CAS,
        substance.EC,
        substance.aliases.join(' '),
        substance.parentType,
        substance.parentName,
        substance.groupName,
        substance.subgroupName,
        substance.status,
        assessment?.overallImpactSeverity || '',
        assessment?.matchContext || ''
      ].join(' ').toLowerCase().includes(query);
      return matchesContext && matchesStatus && matchesGroup && matchesImpact && matchesQuery;
    });
  }

  get archiveContextBreadcrumb(): string {
    if (this.archiveParentFilter === 'DSL') {
      return 'DSL > Substance';
    }
    if (this.archiveParentFilter === 'Group') {
      return 'DSL > Group > Substance';
    }
    if (this.archiveParentFilter === 'Subgroup') {
      return 'DSL > Group > Subgroup > Substance';
    }
    return 'DSL > Group > Subgroup';
  }

  get archiveContextTitle(): string {
    if (this.archiveParentFilter === 'All') {
      return 'Archive impact candidates';
    }
    return `${this.archiveParentFilter} substance archive candidates`;
  }

  get archiveTotalSubstances(): number {
    return this.visibleArchiveCandidates.length;
  }

  get archiveActiveSubstanceCount(): number {
    return this.visibleArchiveCandidates.filter((substance) => substance.status !== 'Archived').length;
  }

  get archiveArchivedSubstanceCount(): number {
    return this.visibleArchiveCandidates.filter((substance) => substance.status === 'Archived').length;
  }

  get archivePendingReviewCount(): number {
    return this.visibleArchiveCandidates.filter((substance) =>
      ['Archive Requested', 'Impact Assessment Generating', 'Impact Assessment Generated', 'Pending Investigation'].includes(substance.status)
    ).length;
  }

  get archiveHighImpactWarningCount(): number {
    return this.visibleArchiveCandidates.filter((substance) => this.impactAssessmentForSubstance(substance.substanceId)?.overallImpactSeverity === 'High').length;
  }

  get selectedSupplierImpacts(): SupplierImpact[] {
    if (!this.selectedImpactAssessment) {
      return [];
    }
    return this.supplierImpacts.filter((impact) => impact.assessmentId === this.selectedImpactAssessment?.assessmentId);
  }

  get selectedCustomerImpacts(): CustomerImpact[] {
    if (!this.selectedImpactAssessment) {
      return [];
    }
    return this.customerImpacts.filter((impact) => impact.assessmentId === this.selectedImpactAssessment?.assessmentId);
  }

  get selectedMatchContext(): ArchiveMatchContext | undefined {
    if (!this.selectedImpactAssessment) {
      return undefined;
    }
    return this.matchContexts.find((context) => context.assessmentId === this.selectedImpactAssessment?.assessmentId);
  }

  get selectedArchiveDecision(): ArchiveDecision | undefined {
    if (!this.selectedImpactAssessment) {
      return undefined;
    }
    return this.archiveDecisionForAssessment(this.selectedImpactAssessment.assessmentId);
  }

  get selectedAuditEvents(): ArchiveAuditEvent[] {
    const objectName = this.selectedArchiveSubstance?.substanceName;
    if (!objectName) {
      return [];
    }
    return this.archiveAuditEvents.filter((event) => event.object === objectName);
  }

  get filteredArchiveHistory(): ImpactAssessment[] {
    const userQuery = this.normalizeQuery(this.archiveHistoryUserFilter);
    const dateQuery = this.normalizeQuery(this.archiveHistoryDateFilter);
    return this.impactAssessments.filter((assessment) => {
      const candidate = this.archiveCandidateForAssessment(assessment);
      const decision = this.archiveDecisionForAssessment(assessment.assessmentId);
      const matchesSeverity = this.archiveHistorySeverityFilter === 'All' || assessment.overallImpactSeverity === this.archiveHistorySeverityFilter;
      const matchesDecision = this.archiveHistoryDecisionFilter === 'All' || decision?.decision === this.archiveHistoryDecisionFilter;
      const matchesParent = this.archiveHistoryParentFilter === 'All' || candidate?.parentType === this.archiveHistoryParentFilter;
      const matchesUser = !userQuery || [assessment.generatedBy, decision?.decidedBy || ''].join(' ').toLowerCase().includes(userQuery);
      const matchesDate = !dateQuery || [assessment.generatedDate, decision?.decidedDate || ''].join(' ').toLowerCase().includes(dateQuery);
      return matchesSeverity && matchesDecision && matchesParent && matchesUser && matchesDate;
    });
  }

  get highestSupplierSeverity(): ImpactSeverity {
    return this.highestImpactSeverity(this.selectedSupplierImpacts.map((impact) => impact.impactSeverity));
  }

  get highestCustomerSeverity(): ImpactSeverity {
    return this.highestImpactSeverity(this.selectedCustomerImpacts.map((impact) => impact.impactSeverity));
  }

  get canProceedHighImpact(): boolean {
    return this.archiveDecisionRationale.trim().length >= 8;
  }

  get canProceedMissingData(): boolean {
    return this.archiveDecisionRationale.trim().length >= 8;
  }

  get canSubmitPendingInvestigation(): boolean {
    const hasReason = Boolean(this.archiveInvestigationReason);
    const hasOtherNotes = this.archiveInvestigationReason !== 'Other' || this.archiveInvestigationNotes.trim().length >= 8;
    return hasReason && hasOtherNotes;
  }

  get canConfirmFinalArchiveDecision(): boolean {
    if (!this.selectedImpactAssessment) {
      return false;
    }
    if (this.finalArchiveDecision === 'Cancel') {
      return true;
    }
    const requiresRationale = this.finalArchiveDecision !== 'Proceed with Archive' ||
      ['Medium', 'High', 'Unknown'].includes(this.selectedImpactAssessment.overallImpactSeverity);
    return !requiresRationale || this.archiveDecisionRationale.trim().length >= 8;
  }

  get dslSubstanceCandidates(): Substance[] {
    const query = this.normalizeQuery(this.dslSubstanceQuery);
    const existingIds = new Set(this.activeDslContents.map((item) => item.id));
    return this.substances
      .filter((substance) => !existingIds.has(substance.id))
      .filter((substance) => {
        if (!query) {
          return true;
        }
        return [
          substance.id,
          substance.name,
          substance.cas,
          substance.ec,
          substance.authority,
          substance.aliasNames
        ].join(' ').toLowerCase().includes(query);
      })
      .slice(0, 7);
  }

  get selectedDslSubstances(): Substance[] {
    const selectedIds = new Set(this.selectedDslSubstanceIds);
    return this.substances.filter((substance) => selectedIds.has(substance.id));
  }

  get filteredDslGroupCandidates(): DslGroupCandidate[] {
    const query = this.normalizeQuery(this.dslGroupQuery);
    return this.dslGroupCandidates.filter((candidate) => {
      if (!query) {
        return true;
      }
      return [
        candidate.id,
        candidate.name,
        candidate.owner,
        candidate.version,
        candidate.reason
      ].join(' ').toLowerCase().includes(query);
    });
  }

  get selectedDslGroupCandidates(): DslGroupCandidate[] {
    const selectedIds = new Set(this.selectedDslGroupIds);
    return this.dslGroupCandidates.filter((candidate) => selectedIds.has(candidate.id));
  }

  get selectedSafeDslGroupCandidates(): DslGroupCandidate[] {
    return this.selectedDslGroupCandidates.filter((candidate) => candidate.safe);
  }

  get filteredDslExemptionCandidates(): ExemptionSet[] {
    const query = this.normalizeQuery(this.dslExemptionQuery);
    const existingCodes = new Set(this.activeDslExemptionReferences.map((reference) => reference.code));
    return this.exemptionSets
      .filter((set) => !existingCodes.has(set.code))
      .filter((set) => {
        if (!query) {
          return true;
        }
        return [
          set.code,
          set.name,
          set.description,
          set.authority,
          set.scope,
          set.status,
          set.owner
        ].join(' ').toLowerCase().includes(query);
      });
  }

  get selectedDslExemptionCandidates(): ExemptionSet[] {
    const selectedCodes = new Set(this.selectedDslExemptionCodes);
    return this.exemptionSets.filter((set) => selectedCodes.has(set.code));
  }

  get shouldShowGroupCardSkeletons(): boolean {
    return this.isGroupLoading && this.groupViewMode === 'cards';
  }

  get isAnyWorkspaceLoading(): boolean {
    return this.isWorkspaceLoading || this.isSubstanceLoading || this.isGroupLoading;
  }

  get workspaceLoadingLabel(): string {
    if (this.isSubstanceLoading) {
      return this.substanceLoadMode === 'server-search'
        ? 'Searching the substance service'
        : 'Loading substance records';
    }
    if (this.isGroupLoading) {
      if (this.groupLoadMode === 'search') {
        return 'Searching groups';
      }
      if (this.groupLoadMode === 'view') {
        return 'Changing group view';
      }
      return 'Filtering groups';
    }
    return this.workspaceLoadMode === 'subpage' ? 'Loading details' : 'Loading page';
  }

  get activeGroupFilterLabel(): string {
    return this.groupQuickFilters.find((filter) => filter.key === this.groupFilter)?.label || 'All';
  }

  get groupListSummary(): string {
    const filterLabel = this.groupFilterSummaryPrefix;
    return `${this.visibleGroups.length} ${filterLabel}group${this.visibleGroups.length === 1 ? '' : 's'} shown`;
  }

  get groupFilterSummaryPrefix(): string {
    if (this.groupFilter === 'drafts') {
      return 'draft ';
    }
    if (this.groupFilter === 'active') {
      return 'active ';
    }
    if (this.groupFilter === 'most-used') {
      return 'most-used ';
    }
    if (this.groupFilter === 'largest') {
      return 'largest ';
    }
    return '';
  }

  get groupDraftCount(): number {
    return this.groups.filter((group) => group.status === 'Draft').length;
  }

  get activeGroupMembers(): GroupMember[] {
    return this.currentGroupMemberList();
  }

  get activeGroupVisibleMembers(): GroupMember[] {
    return this.activeGroupMembers.filter((member) => member.status !== 'Draft remove');
  }

  get activeGroupSubgroupCount(): number {
    return this.activeGroupVisibleMembers.filter((member) => member.kind === 'Subgroup').length;
  }

  get groupSubstanceCandidates(): Substance[] {
    const query = this.normalizeQuery(this.groupSubstanceQuery);
    const existingIds = new Set(this.activeGroupMembers.map((member) => member.id));
    return this.substances
      .filter((substance) => !existingIds.has(substance.id))
      .filter((substance) => {
        if (!query) {
          return true;
        }
        return [
          substance.name,
          substance.id,
          substance.cas,
          substance.ec,
          substance.authority,
          substance.aliasNames
        ].join(' ').toLowerCase().includes(query);
      })
      .slice(0, 6);
  }

  get selectedGroupSubstances(): Substance[] {
    const selectedIds = new Set(this.selectedGroupSubstanceIds);
    return this.substances.filter((substance) => selectedIds.has(substance.id));
  }

  get filteredSubgroupCandidates(): SubgroupCandidate[] {
    const query = this.normalizeQuery(this.subgroupQuery);
    return this.availableSubgroups.filter((candidate) => {
      if (!query) {
        return true;
      }
      return [
        candidate.id,
        candidate.name,
        candidate.owner,
        candidate.version,
        candidate.reason
      ].join(' ').toLowerCase().includes(query);
    });
  }

  get selectedSubgroupCandidates(): SubgroupCandidate[] {
    const selectedIds = new Set(this.selectedSubgroupIds);
    return this.availableSubgroups.filter((candidate) => selectedIds.has(candidate.id));
  }

  get selectedSafeSubgroupCandidates(): SubgroupCandidate[] {
    return this.selectedSubgroupCandidates.filter((candidate) => candidate.safe);
  }

  get selectedBlockedSubgroupCount(): number {
    return this.selectedSubgroupCandidates.filter((candidate) => !candidate.safe).length;
  }

  get activeGroupDraftAddCount(): number {
    return this.activeGroupMembers.filter((member) => member.status === 'Draft add').length;
  }

  get groupDslReferencesReceivingUpdate(): GroupDslReference[] {
    return this.activeGroupDslReferences.filter((reference) => reference.decision === 'Receives draft version');
  }

  get groupDslReferencesHeldCount(): number {
    return Math.max((this.activeGroup?.dslCount || 0) - this.groupDslReferencesReceivingUpdate.length, 0);
  }

  get activeGroupDslReferences(): GroupDslReference[] {
    if (this.activeGroup?.dslCount === 0) {
      return [];
    }
    return this.groupDslReferences;
  }

  get remainingGroupDslReferenceCount(): number {
    const activeCount = this.activeGroup?.dslCount || this.activeGroupDslReferences.length;
    return Math.max(activeCount - this.activeGroupDslReferences.length, 0);
  }

  get stagingMetricNew(): number {
    return this.stagedSubstances.filter((record) => record.stagingStatus === 'New').length;
  }

  get stagingMetricPotentialMatches(): number {
    return this.stagedSubstances.filter((record) => record.matchStatus === 'Potential Match' || record.matchStatus === 'Duplicate Risk').length;
  }

  get stagingMetricNoMatch(): number {
    return this.stagedSubstances.filter((record) => record.matchStatus === 'No Match').length;
  }

  get stagingMetricPendingInvestigation(): number {
    return this.stagedSubstances.filter((record) => record.stagingStatus === 'Pending Investigation').length;
  }

  get stagingMetricSupplierSourced(): number {
    return this.stagedSubstances.filter((record) => record.sourceType === 'Supplier input').length;
  }

  get activeStagedSubstance(): StagedSubstance | undefined {
    return this.stagedSubstances.find((record) => record.stagedSubstanceId === this.activeStagedSubstanceId);
  }

  get activeMatchCandidates(): SubstanceLibraryCandidate[] {
    if (!this.activeStagedSubstance) {
      return [];
    }
    return this.matchCandidates
      .filter((candidate) => candidate.stagedSubstanceId === this.activeStagedSubstance?.stagedSubstanceId)
      .sort((left, right) => right.matchScore - left.matchScore);
  }

  get bestSuggestedCandidate(): SubstanceLibraryCandidate | undefined {
    return this.activeMatchCandidates[0];
  }

  get selectedMatchCandidate(): SubstanceLibraryCandidate | undefined {
    return this.activeMatchCandidates.find((candidate) => candidate.masterSubstanceId === this.activeCandidateId) || this.bestSuggestedCandidate;
  }

  get activeStagingAuditEvents(): StagingAuditEvent[] {
    if (!this.activeStagedSubstance) {
      return [];
    }
    return this.auditEvents.filter((event) => event.stagedSubstanceId === this.activeStagedSubstance?.stagedSubstanceId);
  }

  get visibleStagedSubstances(): StagedSubstance[] {
    const query = this.normalizeQuery(this.stagingFilters.query);
    const filtered = this.stagedSubstances.filter((record) => {
      const searchable = this.normalizeQuery([
        record.stagedSubstanceId,
        record.substanceName,
        record.CAS,
        record.EC,
        record.aliases.join(' '),
        record.source,
        record.sourceType,
        record.assignedReviewer,
        record.supplierContext?.supplierName || ''
      ].join(' '));

      if (query && !searchable.includes(query)) {
        return false;
      }
      if (this.stagingFilters.sourceTypes.length && !this.stagingFilters.sourceTypes.includes(record.sourceType)) {
        return false;
      }
      if (this.stagingFilters.statuses.length && !this.stagingFilters.statuses.includes(record.stagingStatus)) {
        return false;
      }
      if (this.stagingFilters.matchStatuses.length && !this.stagingFilters.matchStatuses.includes(record.matchStatus)) {
        return false;
      }
      if (this.stagingFilters.confidences.length && !this.stagingFilters.confidences.includes(record.dataConfidence)) {
        return false;
      }
      if (this.stagingFilters.reviewer !== 'All reviewers' && record.assignedReviewer !== this.stagingFilters.reviewer) {
        return false;
      }
      return true;
    });

    return this.sortStagedSubstances(filtered);
  }

  get stagingTableSummary(): string {
    if (this.isStagingLoading) {
      return 'Refreshing staged records and match candidates';
    }
    if (!this.matchingServiceAvailable) {
      return 'Matching service is unavailable; existing staged decisions remain visible';
    }
    return `${this.visibleStagedSubstances.length} of ${this.stagedSubstances.length} staged records shown`;
  }

  get activeSourceMetadataRows(): Array<{ label: string; value: string | number }> {
    const record = this.activeStagedSubstance;
    if (!record) {
      return [];
    }
    return [
      { label: 'Source type', value: record.sourceType },
      { label: 'Source system', value: record.sourceMetadata.sourceSystem },
      { label: 'Received date', value: record.dateReceived },
      { label: 'Submitted by', value: record.sourceMetadata.submittedBy },
      { label: 'Original submitted name', value: record.sourceMetadata.originalSubmittedName },
      { label: 'Original CAS', value: record.sourceMetadata.originalCAS || 'Not provided' },
      { label: 'Original EC', value: record.sourceMetadata.originalEC || 'Not provided' },
      { label: 'Confidence rating', value: record.sourceMetadata.confidenceRating },
      { label: 'Completeness score', value: `${record.sourceMetadata.completenessScore}%` },
      { label: 'External reference', value: record.sourceMetadata.externalReference }
    ];
  }

  get createExistenceCheckRows(): ExistenceCheckRow[] {
    const record = this.activeStagedSubstance;
    return record ? this.runExistenceCheck(record) : [];
  }

  get approvalAliasMessage(): string {
    const record = this.activeStagedSubstance;
    const candidate = this.selectedMatchCandidate;
    if (!record || !candidate) {
      return 'No alias changes identified.';
    }
    const newAliases = this.aliasesToAddFor(record, candidate);
    if (!newAliases.length) {
      return 'No new aliases need to be added to the selected record.';
    }
    return `New aliases to add: ${newAliases.join(', ')}`;
  }

  get approvalNewAliases(): string[] {
    const record = this.activeStagedSubstance;
    const candidate = this.selectedMatchCandidate;
    return record && candidate ? this.aliasesToAddFor(record, candidate) : [];
  }

  get createSubstanceValidationMessages(): string[] {
    const messages: string[] = [];
    if (!this.createSubstanceDraft.substanceName.trim()) {
      messages.push('Substance Name is required.');
    }
    if (!this.createSubstanceDraft.source.trim()) {
      messages.push('Source is required.');
    }
    if (!this.createSubstanceDraft.authority.trim()) {
      messages.push('Authority is required when creating a governed record.');
    }
    if (this.createSubstanceDraft.CAS && !this.validateCas(this.createSubstanceDraft.CAS)) {
      messages.push('CAS check digit does not pass validation.');
    }
    if (this.createSubstanceDraft.EC && !this.validateEc(this.createSubstanceDraft.EC)) {
      messages.push('EC number must use the 000-000-0 format.');
    }
    return messages;
  }

  get createSubstanceBlockedByDuplicate(): boolean {
    return this.createExistenceCheckRows.some((row) => row.label !== 'Alias/name similarity' && row.state === 'Found');
  }

  get canCreateNewSubstanceFromStaged(): boolean {
    return !this.createSubstanceValidationMessages.length && !this.createSubstanceBlockedByDuplicate;
  }

  get rejectFormInvalid(): boolean {
    return !this.rejectionReason || (this.rejectionReason === 'Other' && !this.rejectionNotes.trim());
  }

  get investigationFormInvalid(): boolean {
    return !this.investigationReason;
  }

  get substanceReviewCount(): number {
    return this.substanceReviewFilterCount('needs-review');
  }

  get activeSubstanceReviewFilterLabel(): string {
    return this.substanceReviewFilters.find((filter) => filter.key === this.substanceReviewFilter)?.label || 'All';
  }

  get substanceTableSummary(): string {
    if (this.isSubstanceLoading) {
      return this.substanceLoadMode === 'server-search'
        ? 'Searching the full substance service'
        : 'Loading indexed records from the substance service';
    }

    if (this.substanceReviewFilter !== 'all') {
      return `${this.filteredSubstances.length} ${this.activeSubstanceReviewFilterLabel.toLowerCase()} record${this.filteredSubstances.length === 1 ? '' : 's'} shown`;
    }

    if (this.substanceQuery.trim() && this.substanceServiceQuery === this.normalizeQuery(this.substanceQuery)) {
      return `${this.filteredSubstances.length} server result${this.filteredSubstances.length === 1 ? '' : 's'} shown`;
    }

    return `${this.filteredSubstances.length} indexed records shown`;
  }

  get substanceTableRows(): SubstanceTableRow[] {
    return this.isSubstanceLoading ? this.substanceSkeletonRows : this.filteredSubstances;
  }

  get filteredSubstances(): Substance[] {
    const query = this.normalizeQuery(this.substanceQuery);
    let matches: Substance[] = [];

    if (!query) {
      matches = this.substances;
    } else {
      const indexedMatches = this.findIndexedSubstanceMatches(query);
      if (indexedMatches.length) {
        matches = indexedMatches;
      } else if (this.substanceServiceQuery === query) {
        matches = this.substanceServerResults;
      }
    }

    return this.sortSubstancesForReview(this.filterSubstancesByReview(matches, this.substanceReviewFilter));
  }

  get statusColumnOptions(): Substance['status'][] {
    return ['Active', 'Staged', 'Archived'];
  }

  get apiStatusOptions(): SubstanceApiStatus[] {
    return ['Available', 'Pending validation', 'Blocked'];
  }

  get authorityColumnOptions(): string[] {
    return Array.from(new Set([...this.substances, ...this.substanceServerResults].map((substance) => substance.authority)));
  }

  get selectedSubstanceCount(): number {
    return this.selectedSubstances.length;
  }

  get drawerTitle(): string {
    return this.editorMode === 'create' ? 'New substance' : this.activeSubstance.name;
  }

  get activeImpactLevel(): 'Low' | 'Medium' | 'High' {
    return this.impactLevel(this.activeSubstance);
  }

  get editorImpactLevel(): 'Low' | 'Medium' | 'High' {
    return this.impactLevel(this.editorDraft);
  }

  get activeSubstanceActivityLog(): SubstanceActivityRecord[] {
    const record = this.editorDraft.id ? this.editorDraft : this.activeSubstance;
    const contextRows: SubstanceActivityRecord[] = this.drawerContext
      ? [
          {
            id: `${record.id || 'draft'}-context`,
            date: 'Current view',
            status: 'Context',
            type: 'Group drilldown',
            summary: `Opened from ${this.drawerContext.groupName}.`,
            rationale: `${record.name || 'This substance'} is being reviewed from the group where its threshold, status, and effective date matter.`,
            source: `${this.drawerContext.groupId} member reference`,
            impact: `${this.drawerContext.threshold} threshold, ${this.drawerContext.memberStatus.toLowerCase()} status, effective ${this.drawerContext.effective}.`,
            user: 'Current session'
          }
        ]
      : [];

    const savedRows = this.substanceActivityHistory[record.id] || this.defaultSubstanceHistory(record);
    return [...contextRows, ...savedRows];
  }

  get filteredSubstanceActivityLog(): SubstanceActivityRecord[] {
    const query = this.normalizeQuery(this.activityQuery);
    return this.activeSubstanceActivityLog.filter((item) => {
      const matchesStatus = this.activityStatus === 'All' || item.status === this.activityStatus;
      const matchesQuery = !query || [
        item.id,
        item.date,
        item.status,
        item.type,
        item.summary,
        item.rationale,
        item.source,
        item.impact,
        item.user
      ].join(' ').toLowerCase().includes(query);
      return matchesStatus && matchesQuery;
    });
  }

  get activeGroupActivityLog(): SubstanceActivityRecord[] {
    if (!this.activeGroup) {
      return [];
    }

    return this.groupActivityHistory[this.activeGroup.id] || this.defaultGroupHistory(this.activeGroup);
  }

  get filteredGroupActivityLog(): SubstanceActivityRecord[] {
    const query = this.normalizeQuery(this.activityQuery);
    return this.activeGroupActivityLog.filter((item) => {
      const matchesStatus = this.activityStatus === 'All' || item.status === this.activityStatus;
      const matchesQuery = !query || [
        item.id,
        item.date,
        item.status,
        item.type,
        item.summary,
        item.rationale,
        item.source,
        item.impact,
        item.user
      ].join(' ').toLowerCase().includes(query);
      return matchesStatus && matchesQuery;
    });
  }

  get activeExemptionSetActivityLog(): SubstanceActivityRecord[] {
    if (!this.activeExemptionSet) {
      return [];
    }

    return this.exemptionActivityHistory[this.activeExemptionSet.code] || this.defaultExemptionSetHistory(this.activeExemptionSet);
  }

  get filteredExemptionSetActivityLog(): SubstanceActivityRecord[] {
    const query = this.normalizeQuery(this.activityQuery);
    return this.activeExemptionSetActivityLog.filter((item) => {
      const matchesStatus = this.activityStatus === 'All' || item.status === this.activityStatus;
      const matchesQuery = !query || [
        item.id,
        item.date,
        item.status,
        item.type,
        item.summary,
        item.rationale,
        item.source,
        item.impact,
        item.user
      ].join(' ').toLowerCase().includes(query);
      return matchesStatus && matchesQuery;
    });
  }

  get activeDslActivityLog(): SubstanceActivityRecord[] {
    if (!this.activeDslList) {
      return [];
    }

    return this.defaultDslHistory(this.activeDslList);
  }

	  get filteredDslActivityLog(): SubstanceActivityRecord[] {
	    const query = this.normalizeQuery(this.activityQuery);
	    return this.activeDslActivityLog.filter((item) => {
      const matchesStatus = this.activityStatus === 'All' || item.status === this.activityStatus;
      const matchesQuery = !query || [
        item.id,
        item.date,
        item.status,
        item.type,
        item.summary,
        item.rationale,
        item.source,
        item.impact,
        item.user
      ].join(' ').toLowerCase().includes(query);
	      return matchesStatus && matchesQuery;
	    });
	  }

	  get activeModuleReadinessChecks(): ModuleReadinessCheck[] {
	    if (!this.activeModule) {
	      return [];
	    }
	    return this.moduleReadinessChecks(this.activeModule);
	  }

	  get activeModuleReadyToFinalize(): boolean {
	    return this.activeModuleReadinessChecks.every((check) => check.status === 'Ready');
	  }

	  get activeModuleResourceCount(): number {
	    return this.activeModule?.resources.length || 0;
	  }

	  get activeModuleReadyResourceCount(): number {
	    return this.activeModule?.resources.filter((resource) => resource.status === 'Ready').length || 0;
	  }

	  get activeModuleActivityLog(): SubstanceActivityRecord[] {
	    if (!this.activeModule) {
	      return [];
	    }
	    return this.defaultModuleHistory(this.activeModule);
	  }

	  get filteredModuleActivityLog(): SubstanceActivityRecord[] {
	    const query = this.normalizeQuery(this.activityQuery);
	    return this.activeModuleActivityLog.filter((item) => {
	      const matchesStatus = this.activityStatus === 'All' || item.status === this.activityStatus;
	      const matchesQuery = !query || [
	        item.id,
	        item.date,
	        item.status,
	        item.type,
	        item.summary,
	        item.rationale,
	        item.source,
	        item.impact,
	        item.user
	      ].join(' ').toLowerCase().includes(query);
	      return matchesStatus && matchesQuery;
	    });
	  }

  get selectedBulkTemplate(): BulkTemplate | undefined {
    return this.bulkTemplates.find((template) => template.id === this.selectedBulkTemplateId);
  }

  get bulkSummaryTemplate(): string {
    return this.selectedBulkTemplate?.label || 'None selected';
  }

  get bulkSummaryFile(): string {
    return this.bulkUploadFileName || 'No file uploaded yet';
  }

  get bulkSummaryDetectedContent(): string {
    return this.bulkDetectedType || 'Not analyzed yet';
  }

  get bulkSummaryOutcome(): string {
    if (this.bulkReviewCommitted) {
      return 'Valid rows staged for review';
    }
    if (this.bulkValidationReady) {
      return 'Validation ready for review';
    }
    if (this.bulkUploadFileName) {
      return 'File selected; analysis pending';
    }
    if (this.selectedBulkTemplate) {
      return 'Template selected; no file uploaded yet';
    }
    return 'Choose a template or upload an existing file';
  }

  get bulkReviewFilterLabel(): string {
    if (this.activeBulkReviewFilter === 'all') {
      return 'All rows';
    }
    return this.bulkValidationChecks.find((check) => check.id === this.activeBulkReviewFilter)?.label || 'Selected issue';
  }

  get filteredBulkReviewRows(): BulkReviewRow[] {
    if (this.activeBulkReviewFilter === 'all') {
      return this.bulkReviewRows;
    }
    return this.bulkReviewRows.filter((row) => row.issue === this.activeBulkReviewFilter);
  }

  get activeBulkReviewRow(): BulkReviewRow | undefined {
    return this.filteredBulkReviewRows.find((row) => row.row === this.activeBulkReviewRowId) || this.filteredBulkReviewRows[0];
  }

  get readyBulkReviewRows(): number {
    return this.filteredBulkReviewRows.filter((row) => row.severity === 'success').length;
  }

  get unresolvedBulkReviewRows(): number {
    return this.filteredBulkReviewRows.filter((row) => row.status === 'Needs review' || row.status === 'Conflict').length;
  }

  get deferredBulkReviewRows(): number {
    return this.filteredBulkReviewRows.filter((row) => row.status === 'Deferred').length;
  }

  get filteredBulkReviewSummary(): string {
    const count = this.filteredBulkReviewRows.length;
    return `${count} row${count === 1 ? '' : 's'} shown for ${this.bulkReviewFilterLabel.toLowerCase()}`;
  }

  get activeBulkStepIndex(): number {
    return Math.max(0, this.bulkSteps.findIndex((step) => step.key === this.bulkStep));
  }

  get bulkWorkflowHeading(): string {
    if (this.bulkStep === 'template') {
      return 'Start with the right template';
    }
    if (this.bulkStep === 'upload') {
      return 'Upload the completed file';
    }
    if (this.bulkStep === 'validate') {
      return 'Review validation results';
    }
    return 'Confirm what gets staged';
  }

  get bulkWorkflowSummary(): string {
    if (this.bulkStep === 'template') {
      return 'Download a governed template if the user has not started yet, or continue with an existing file.';
    }
    if (this.bulkStep === 'upload') {
      return 'The system detects the content type and keeps everything staged until validation is reviewed.';
    }
    if (this.bulkStep === 'validate') {
      return 'Rows are checked for schema, identifiers, duplicate risk, matching decisions, and effective dates.';
    }
    return 'Open each row, decide what happens next, and stage only the rows that are ready.';
  }

	  setPage(page: PageKey): void {
	    const pageChanged = this.activePage !== page || Boolean(this.activeGroup) || Boolean(this.activeDslList) || Boolean(this.activeModule);
	    this.activePage = page;
	    if (page !== 'groups') {
	      this.activeGroup = undefined;
	    }
    if (page !== 'exemptions') {
      this.activeExemptionSet = undefined;
    }
	    if (page !== 'lists') {
	      this.activeDslList = undefined;
	    }
	    if (page !== 'modules') {
	      this.activeModule = undefined;
	    }
    if (page !== 'staging') {
      this.reviewDrawerOpen = false;
      this.comparisonDrawerOpen = false;
      this.rejectDialogOpen = false;
      this.investigationDialogOpen = false;
      this.createSubstanceDrawerOpen = false;
      this.approveMatchDialogOpen = false;
      this.stagingDialogOpenedFromReview = false;
    }
    if (pageChanged) {
      this.simulateWorkspaceLoad('page', 180);
    }
    if (page === 'substances') {
      this.ensureSubstanceIndexLoaded();
    }
	    if (page === 'groups' && !this.activeGroup) {
	      this.simulateGroupLoad('filter');
	    }
	  }

  selectExportSource(source: ExportSource): void {
    this.selectedExportSource = source;
    this.clearExportContentFilters();
    this.isExportContentLoading = true;
    window.setTimeout(() => {
      this.isExportContentLoading = false;
    }, 220);
  }

  clearExportContentFilters(): void {
    this.exportContentQuery = '';
    this.exportStatusFilter = 'All statuses';
    this.exportGroupFilter = 'All groups';
    this.exportSubgroupFilter = 'All subgroups';
  }

  openExportConfig(sourceId: string, sourceType?: ExportSourceType): void {
    const source = this.exportSources.find((item) => item.sourceId === sourceId && (!sourceType || item.sourceType === sourceType));
    if (!source) {
      this.messages.add({
        severity: 'warn',
        summary: 'Export source missing',
        detail: 'Choose a DSL, group, or subgroup before configuring the export.'
      });
      return;
    }
    this.selectedExportSource = source;
    this.selectedExportRequest = undefined;
    this.exportConfig = this.defaultExportConfig();
    this.exportConfigDialogOpen = true;
  }

  openExportForActiveDslList(list: DslList): void {
    const source = this.exportSources.find((item) =>
      item.sourceType === 'DSL' &&
      (this.normalizeQuery(item.sourceName).includes(this.normalizeQuery(list.name.split(' ')[0])) ||
        this.normalizeQuery(list.name).includes(this.normalizeQuery(item.sourceName.split(' ')[0])))
    ) || this.exportSources.find((item) => item.sourceType === 'DSL');
    if (source) {
      this.openExportConfig(source.sourceId, 'DSL');
    }
  }

  openExportForActiveGroup(group: SubstanceGroup): void {
    const normalizedGroupName = this.normalizeQuery(group.name);
    const source = this.exportSources.find((item) =>
      item.sourceType === 'Group' &&
      (this.normalizeQuery(item.sourceName).includes(normalizedGroupName) ||
        normalizedGroupName.includes(this.normalizeQuery(item.sourceName.replace(' Group', ''))))
    ) || this.exportSources.find((item) => item.sourceType === 'Group');
    if (source) {
      this.openExportConfig(source.sourceId, 'Group');
    }
  }

  openExportHistory(): void {
    this.exportHistoryOpen = true;
  }

  openExportDetails(exportRequestId: string): void {
    const request = this.exportRequests.find((item) => item.exportRequestId === exportRequestId);
    if (!request) {
      return;
    }
    this.selectedExportRequest = request;
    this.exportDetailsDrawerOpen = true;
  }

  estimateExportSize(sourceId: string, config = this.exportConfig): ExportEstimate {
    const source = this.exportSources.find((item) => item.sourceId === sourceId);
    if (!source) {
      return { rows: 0, fileSize: '0 KB', isLarge: false, isEmpty: true };
    }
    const rows = source.substanceCount + (config.includeArchived ? source.archivedSubstanceCount : 0);
    const metadataMultiplier = config.includeMetadata ? 1.2 : 1;
    const hierarchyMultiplier = config.includeHierarchyColumns ? 1.12 : 1;
    const formatMultiplier = config.exportFormat === 'Excel' ? 0.0042 : 0.0028;
    const megabytes = rows * formatMultiplier * metadataMultiplier * hierarchyMultiplier;
    const fileSize = rows === 0 ? '0 KB' : megabytes < 1 ? `${Math.max(80, Math.round(megabytes * 1024))} KB` : `${megabytes.toFixed(1)} MB`;
    return {
      rows,
      fileSize,
      isLarge: rows > 5000 || megabytes > 25,
      isEmpty: rows === 0
    };
  }

  generateExport(sourceId: string, config = this.exportConfig): void {
    const source = this.exportSources.find((item) => item.sourceId === sourceId);
    if (!source) {
      this.messages.add({ severity: 'warn', summary: 'Source required', detail: 'Choose an export source first.' });
      return;
    }
    const estimate = this.estimateExportSize(sourceId, config);
    if (estimate.isEmpty && !config.confirmEmptyExport) {
      this.messages.add({
        severity: 'warn',
        summary: 'No exportable substances',
        detail: 'No substances are available for export from this source.'
      });
      return;
    }
    if (estimate.isLarge) {
      this.exportConfigDialogOpen = false;
      this.largeExportDialogOpen = true;
      return;
    }
    const request = this.createExportRequest(source, config, estimate, 'Ready');
    request.generatedDate = this.formattedWorkflowTimestamp();
    this.exportRequests.unshift(request);
    this.createExportFile(request);
    this.addExportAuditEvent({ exportRequestId: request.exportRequestId, user: request.requestedBy, dateTime: request.requestedDate, action: 'Export requested', source: request.sourceName, fileName: request.fileName, status: 'Requested' });
    this.addExportAuditEvent({ exportRequestId: request.exportRequestId, user: 'System', dateTime: request.generatedDate, action: 'Export generated', source: request.sourceName, fileName: request.fileName, status: 'Ready' });
    this.selectedExportRequest = request;
    this.exportConfigDialogOpen = false;
    this.exportReadyOpen = true;
    this.messages.add({ severity: 'success', summary: 'Export ready', detail: `${request.fileName} is ready to download.` });
  }

  generateLargeExportInBackground(sourceId = this.activeExportSource.sourceId, config = this.exportConfig): void {
    const source = this.exportSources.find((item) => item.sourceId === sourceId);
    if (!source) {
      return;
    }
    const estimate = this.estimateExportSize(sourceId, config);
    const request = this.createExportRequest(source, config, estimate, 'Generating');
    this.exportRequests.unshift(request);
    this.addExportAuditEvent({ exportRequestId: request.exportRequestId, user: request.requestedBy, dateTime: request.requestedDate, action: 'Export requested', source: request.sourceName, fileName: request.fileName, status: 'Generating' });
    this.selectedExportRequest = request;
    this.exportConfigDialogOpen = false;
    this.largeExportDialogOpen = false;
    this.exportGeneratingOpen = true;
    this.messages.add({
      severity: 'info',
      summary: 'Export generating',
      detail: 'The export is running in the background. You can continue working.'
    });
  }

  markExportReady(exportRequestId: string): void {
    const request = this.exportRequests.find((item) => item.exportRequestId === exportRequestId);
    if (!request) {
      return;
    }
    request.status = 'Ready';
    request.generatedDate = this.formattedWorkflowTimestamp();
    this.createExportFile(request);
    this.addExportAuditEvent({ exportRequestId: request.exportRequestId, user: 'System', dateTime: request.generatedDate, action: 'Export generated', source: request.sourceName, fileName: request.fileName, status: 'Ready' });
    this.selectedExportRequest = request;
    this.exportGeneratingOpen = false;
    this.exportReadyOpen = true;
    this.messages.add({ severity: 'success', summary: 'Export ready', detail: `${request.fileName} finished generating.` });
  }

  downloadExport(exportRequestId: string): void {
    const request = this.exportRequests.find((item) => item.exportRequestId === exportRequestId);
    if (!request || (request.status !== 'Ready' && request.status !== 'Downloaded')) {
      return;
    }
    const downloadedDate = this.formattedWorkflowTimestamp();
    request.status = 'Downloaded';
    request.downloadedDate = downloadedDate;
    const file = this.exportFiles.find((item) => item.exportRequestId === exportRequestId);
    if (file) {
      file.status = 'Downloaded';
    }
    this.addExportAuditEvent({ exportRequestId: request.exportRequestId, user: 'You', dateTime: downloadedDate, action: 'Export downloaded', source: request.sourceName, fileName: request.fileName, status: 'Downloaded' });
    this.messages.add({ severity: 'success', summary: 'Download started', detail: `${request.fileName} was marked as downloaded.` });
  }

  retryExport(exportRequestId: string): void {
    const request = this.exportRequests.find((item) => item.exportRequestId === exportRequestId);
    if (!request) {
      return;
    }
    request.status = 'Retrying';
    request.failureMessage = undefined;
    this.addExportAuditEvent({ exportRequestId: request.exportRequestId, user: 'You', dateTime: this.formattedWorkflowTimestamp(), action: 'Export retried', source: request.sourceName, fileName: request.fileName, status: 'Retrying' });
    this.selectedExportRequest = request;
    this.exportFailedOpen = false;
    this.exportGeneratingOpen = true;
    this.messages.add({ severity: 'info', summary: 'Retry started', detail: `${request.fileName} is retrying in the background.` });
  }

  openExportFailure(exportRequestId: string): void {
    const request = this.exportRequests.find((item) => item.exportRequestId === exportRequestId);
    if (!request) {
      return;
    }
    this.selectedExportRequest = request;
    this.exportFailedOpen = true;
    this.messages.add({ severity: 'error', summary: 'Export failed', detail: request.failureMessage || 'The export failed during generation.' });
  }

  viewExportSubstance(row: ExportSubstance): void {
    this.messages.add({
      severity: 'info',
      summary: row.substanceName,
      detail: `${row.substanceId} is shown in the export preview with CAS ${row.CAS || '-'} and EC ${row.EC || '-'}.`
    });
  }

  getExportStatusTag(status: ExportStatus | string): Severity {
    if (status === 'Ready' || status === 'Downloaded') {
      return 'success';
    }
    if (status === 'Failed' || status === 'Expired') {
      return 'danger';
    }
    if (status === 'Requested' || status === 'Generating' || status === 'Retrying') {
      return 'warn';
    }
    return 'info';
  }

  exportSourceSeverity(sourceType: ExportSourceType | string): Severity {
    if (sourceType === 'DSL') {
      return 'info';
    }
    if (sourceType === 'Group') {
      return 'success';
    }
    return 'warn';
  }

  exportSourceIcon(sourceType: ExportSourceType | string): string {
    if (sourceType === 'DSL') {
      return 'pi pi-list-check';
    }
    if (sourceType === 'Group') {
      return 'pi pi-th-large';
    }
    return 'pi pi-sitemap';
  }

  addExportAuditEvent(event: Omit<ExportAuditEvent, 'id'>): void {
    this.exportAuditEvents.unshift({
      id: `EXAUD-${String(this.exportAuditEvents.length + 1).padStart(3, '0')}`,
      ...event
    });
  }

  // ASP-17327 stakeholder demo checklist:
  // - Queue works
  // - Filters work
  // - Review drawer works
  // - Candidate comparison works
  // - Approve works
  // - Create new works
  // - Reject works
  // - Pending investigation works
  // - Source metadata works
  // - Audit works
  // - Supplier notification awareness works
  // - Regulatory sign-off awareness works
  onStagingSearchChange(query: string): void {
    this.stagingFilters.query = query || '';
    this.completeStagingSearch({ query });
  }

  completeStagingSearch(event: { query?: string }): void {
    const query = this.normalizeQuery(event.query || '');
    const values = new Set<string>();
    this.stagedSubstances.forEach((record) => {
      [record.stagedSubstanceId, record.substanceName, record.CAS, record.EC, record.source, record.sourceType, record.assignedReviewer, ...record.aliases]
        .filter(Boolean)
        .forEach((value) => values.add(value));
    });
    this.stagingSearchSuggestions = [...values]
      .filter((value) => !query || this.normalizeQuery(value).includes(query))
      .slice(0, 8);
  }

  clearStagingFilters(): void {
    this.stagingFilters = {
      query: '',
      sourceTypes: [],
      statuses: [],
      matchStatuses: [],
      confidences: [],
      reviewer: 'All reviewers',
      sort: 'Newest first'
    };
  }

  refreshStagingMatching(): void {
    if (!this.matchingServiceAvailable) {
      this.addAuditEvent({
        user: 'Matching service',
        action: 'Matching attempted',
        stagedSubstanceId: this.activeStagedSubstance?.stagedSubstanceId || 'STAGING-QUEUE',
        stagedSubstanceName: this.activeStagedSubstance?.substanceName || 'Staging queue',
        decision: 'Re-run matching',
        reason: 'Reviewer attempted to refresh candidates while the matching service was unavailable.',
        beforeAfter: 'Before: service unavailable | After: service unavailable',
        notes: 'No CAS, EC, name, or alias scoring was refreshed.'
      });
      this.messages.add({
        severity: 'warn',
        summary: 'Matching service unavailable',
        detail: 'Existing staged decisions remain visible, but matching cannot be refreshed right now.'
      });
      return;
    }
    this.isStagingLoading = true;
    window.setTimeout(() => {
      this.isStagingLoading = false;
      this.addAuditEvent({
        user: 'Matching service',
        action: 'Matching attempted',
        stagedSubstanceId: this.activeStagedSubstance?.stagedSubstanceId || 'STAGING-QUEUE',
        stagedSubstanceName: this.activeStagedSubstance?.substanceName || 'Staging queue',
        decision: 'Re-run matching',
        reason: 'Reviewer refreshed match candidates from the staging queue.',
        beforeAfter: 'Before: existing match states | After: refreshed candidate scoring',
        notes: 'Mock service completed successfully.'
      });
      this.messages.add({
        severity: 'success',
        summary: 'Matching refreshed',
        detail: 'Staged substances were checked by CAS, EC, name, and alias.'
      });
    }, 650);
  }

  simulateMatchingServiceUnavailable(): void {
    this.matchingServiceAvailable = false;
    this.addAuditEvent({
      user: 'Demo control',
      action: 'Matching service unavailable',
      stagedSubstanceId: 'STAGING-QUEUE',
      stagedSubstanceName: 'Staging queue',
      decision: 'Simulate service unavailable',
      reason: 'Stakeholder demo toggle was enabled.',
      beforeAfter: 'Before: service available | After: service unavailable',
      notes: 'Warning state is visible and re-run matching will warn until restored.'
    });
    this.messages.add({
      severity: 'warn',
      summary: 'Matching service unavailable',
      detail: 'Demo mode is showing the unavailable matching-service state.'
    });
  }

  restoreMatchingService(): void {
    this.matchingServiceAvailable = true;
    this.addAuditEvent({
      user: 'Demo control',
      action: 'Matching service restored',
      stagedSubstanceId: 'STAGING-QUEUE',
      stagedSubstanceName: 'Staging queue',
      decision: 'Restore matching service',
      reason: 'Stakeholder demo toggle was restored.',
      beforeAfter: 'Before: service unavailable | After: service available',
      notes: 'Re-run matching is available again for the staging queue.'
    });
    this.messages.add({
      severity: 'success',
      summary: 'Matching service restored',
      detail: 'Re-run matching is available again.'
    });
  }

  openStagedReview(stagedSubstanceId: string): void {
    const record = this.stagedSubstances.find((item) => item.stagedSubstanceId === stagedSubstanceId);
    if (!record) {
      return;
    }
    const beforeStatus = record.stagingStatus;
    this.activeStagedSubstanceId = record.stagedSubstanceId;
    this.activeCandidateId = this.matchCandidates
      .filter((candidate) => candidate.stagedSubstanceId === record.stagedSubstanceId)
      .sort((left, right) => right.matchScore - left.matchScore)[0]?.masterSubstanceId || '';
    this.stagingDetailTab = 'details';
    this.reviewDrawerOpen = true;
    this.comparisonDrawerOpen = false;
    if (record.stagingStatus === 'New' || record.stagingStatus === 'Ready for Review') {
      record.stagingStatus = 'In Review';
    }
    this.addAuditEvent({
      user: 'You',
      action: 'Reviewer opened record',
      stagedSubstanceId: record.stagedSubstanceId,
      stagedSubstanceName: record.substanceName,
      decision: 'Review details before approval',
      reason: 'Reviewer inspected staged source data and suggested matches.',
      beforeAfter: `Before: ${beforeStatus} | After: ${record.stagingStatus}`,
      notes: 'Review drawer opened with substance details, candidates, source metadata, and audit history.'
    });
  }

  closeStagedReview(): void {
    this.reviewDrawerOpen = false;
  }

  setStagingDetailTab(tab: StagingDetailTab): void {
    this.stagingDetailTab = tab;
  }

  openCandidateComparison(stagedSubstanceId: string): void {
    this.activeStagedSubstanceId = stagedSubstanceId;
    this.activeCandidateId = this.bestSuggestedCandidate?.masterSubstanceId || this.activeCandidateId;
    this.comparisonDrawerOpen = true;
    this.reviewDrawerOpen = false;
    const record = this.activeStagedSubstance;
    if (record) {
      this.addAuditEvent({
        user: 'You',
        action: 'Candidate comparison opened',
        stagedSubstanceId: record.stagedSubstanceId,
        stagedSubstanceName: record.substanceName,
        decision: 'Manual candidate comparison',
        reason: 'Reviewer opened the reconciliation comparison for potential or ambiguous matches.',
        beforeAfter: 'Before: review detail | After: candidate comparison',
        notes: `${this.activeMatchCandidates.length} candidate match${this.activeMatchCandidates.length === 1 ? '' : 'es'} available.`
      });
    }
  }

  backToStagedReview(): void {
    this.comparisonDrawerOpen = false;
    this.reviewDrawerOpen = true;
    this.stagingDetailTab = 'candidates';
  }

  selectMatchCandidate(candidate: SubstanceLibraryCandidate): void {
    this.activeCandidateId = candidate.masterSubstanceId;
    const record = this.activeStagedSubstance;
    if (!record) {
      return;
    }
    this.addAuditEvent({
      user: 'You',
      action: 'Candidate selected',
      stagedSubstanceId: record.stagedSubstanceId,
      stagedSubstanceName: record.substanceName,
      decision: 'Approve existing match',
      reason: `${candidate.masterSubstanceId} selected for review at ${candidate.matchScore}% match score.`,
      beforeAfter: 'Before: no candidate selected | After: candidate selected',
      notes: candidate.matchReason
    });
  }

  openApproveMatchConfirmation(candidateId = this.selectedMatchCandidate?.masterSubstanceId || ''): void {
    if (!this.activeStagedSubstance) {
      return;
    }
    this.activeCandidateId = candidateId;
    this.approvalAuditNote = '';
    this.approveMatchDialogOpen = true;
  }

  confirmApproveExistingMatch(): void {
    if (!this.activeStagedSubstance || !this.selectedMatchCandidate) {
      return;
    }
    this.approveExistingMatch(this.activeStagedSubstance.stagedSubstanceId, this.selectedMatchCandidate.masterSubstanceId);
  }

  approveExistingMatch(stagedSubstanceId: string, candidateId: string): void {
    const record = this.stagedSubstances.find((item) => item.stagedSubstanceId === stagedSubstanceId);
    const candidate = this.matchCandidates.find((item) => item.masterSubstanceId === candidateId && item.stagedSubstanceId === stagedSubstanceId);
    if (!record || !candidate) {
      return;
    }
    const beforeStatus = record.stagingStatus;
    const newAliases = this.aliasesToAddFor(record, candidate);
    if (newAliases.length) {
      candidate.aliases = [...candidate.aliases, ...newAliases];
    }
    record.stagingStatus = 'Approved';
    record.matchStatus = 'Match Found';
    record.decision = 'Approve existing match';
    record.currentLibraryStatus = candidate.currentLibraryStatus;
    if (record.sourceType === 'Supplier input' && record.notificationStatus === 'Required') {
      record.notificationStatus = 'Queued';
      record.supplierContext = record.supplierContext ? { ...record.supplierContext, notificationStatus: 'Queued' } : undefined;
    }
    const aliasAuditNote = newAliases.length
      ? `Alias added to existing substance record: ${newAliases.join(', ')}.`
      : 'No new aliases were added to the selected existing substance record.';
    const sourceAuditNote = `Source attribution retained from ${record.source} (${record.sourceMetadata.externalReference}).`;
    this.addAuditEvent({
      user: 'You',
      action: 'Approved existing match',
      stagedSubstanceId: record.stagedSubstanceId,
      stagedSubstanceName: record.substanceName,
      decision: `Linked to ${candidate.masterSubstanceId}`,
      reason: candidate.matchReason,
      beforeAfter: `Before: ${beforeStatus} | After: Approved`,
      notes: [this.approvalAuditNote, aliasAuditNote, sourceAuditNote].filter(Boolean).join(' ')
    });
    if (record.sourceType === 'Supplier input' && record.notificationStatus === 'Queued') {
      this.addAuditEvent({
        user: 'You',
        action: 'Supplier notification queued',
        stagedSubstanceId: record.stagedSubstanceId,
        stagedSubstanceName: record.substanceName,
        decision: 'Supplier notification queued',
        reason: 'Supplier-originated record approved.',
        beforeAfter: 'Before: Required | After: Queued',
        notes: 'Notification awareness captured; communication workflow remains outside this module.'
      });
    }
    this.approveMatchDialogOpen = false;
    this.reviewDrawerOpen = false;
    this.comparisonDrawerOpen = false;
    this.messages.add({
      severity: 'success',
      summary: 'Existing match approved',
      detail: `${record.substanceName} is linked to ${candidate.masterSubstanceId}. Alias and source attribution are retained.`
    });
  }

  openCreateNewSubstance(stagedSubstanceId: string): void {
    const record = this.stagedSubstances.find((item) => item.stagedSubstanceId === stagedSubstanceId);
    if (!record) {
      return;
    }
    this.activeStagedSubstanceId = record.stagedSubstanceId;
    this.createSubstanceDraft = {
      substanceName: record.substanceName,
      CAS: record.CAS,
      EC: record.EC,
      aliases: record.aliases.join(', '),
      authority: record.sourceType === 'CAS' ? 'CAS' : record.sourceType === 'PubChem' ? 'PubChem reviewed by Assent' : 'Assent',
      source: record.source,
      sourceMetadata: `${record.sourceMetadata.sourceSystem} | ${record.sourceMetadata.externalReference} | ${record.sourceMetadata.ingestionBatch}`,
      notes: record.sourceType === 'Supplier input'
        ? 'Supplier-originated staged record. Confirm source evidence before authoritative promotion.'
        : 'Created from staged source record with source attribution retained.'
    };
    this.createSubstanceDrawerOpen = true;
    this.reviewDrawerOpen = false;
  }

  createNewSubstanceFromStaged(stagedSubstanceId: string): void {
    const record = this.stagedSubstances.find((item) => item.stagedSubstanceId === stagedSubstanceId);
    if (!record) {
      return;
    }
    const validationMessages = this.createSubstanceValidationMessages;
    if (validationMessages.length || this.createSubstanceBlockedByDuplicate) {
      this.messages.add({
        severity: 'warn',
        summary: 'Resolve validation first',
        detail: validationMessages[0] || 'An exact CAS or EC match already exists in the library.'
      });
      return;
    }
    const newSubstance: Substance = {
      id: this.nextSubstanceId(),
      name: this.createSubstanceDraft.substanceName.trim(),
      cas: this.createSubstanceDraft.CAS.trim(),
      ec: this.createSubstanceDraft.EC.trim(),
      authority: this.createSubstanceDraft.authority.trim(),
      aliases: this.createSubstanceDraft.aliases.split(',').map((alias) => alias.trim()).filter(Boolean).length,
      aliasNames: this.createSubstanceDraft.aliases,
      alternativeIds: record.sourceMetadata.externalReference,
      source: this.createSubstanceDraft.source.trim(),
      created: 'Today',
      status: 'Active',
      apiStatus: 'Available',
      modified: 'Just now',
      references: { lists: 0, groups: 0, materials: 0 }
    };
    this.substances.unshift(newSubstance);
    const beforeStatus = record.stagingStatus;
    record.stagingStatus = 'Approved';
    record.matchStatus = 'No Match';
    record.decision = 'Create new substance';
    record.currentLibraryStatus = `Created as ${newSubstance.id}`;
    if (record.signoffStatus === 'Required') {
      const beforeSignoff = record.signoffStatus;
      record.signoffStatus = 'Requested';
      this.addAuditEvent({
        user: 'You',
        action: 'Regulatory sign-off requested',
        stagedSubstanceId: record.stagedSubstanceId,
        stagedSubstanceName: record.substanceName,
        decision: 'Create new substance',
        reason: 'No-match create-new path requires regulatory sign-off awareness.',
        beforeAfter: `Before: ${beforeSignoff} | After: ${record.signoffStatus}`,
        notes: 'Regulatory sign-off required before promotion if configured.'
      });
    }
    this.addAuditEvent({
      user: 'You',
      action: 'New substance created',
      stagedSubstanceId: record.stagedSubstanceId,
      stagedSubstanceName: record.substanceName,
      decision: `Create new substance | Created ${newSubstance.id}`,
      reason: 'No acceptable match found after duplicate checks.',
      beforeAfter: `Before: ${beforeStatus} | After: Approved`,
      notes: 'Created new authoritative substance from staged record. Source attribution retained on the new authoritative Substance Library record.'
    });
    this.createSubstanceDrawerOpen = false;
    this.reviewDrawerOpen = false;
    this.messages.add({
      severity: 'success',
      summary: 'Substance created',
      detail: `Created new authoritative substance from staged record. ${newSubstance.id} was created from ${record.stagedSubstanceId}.`
    });
  }

  openRejectDialog(stagedSubstanceId: string): void {
    this.activeStagedSubstanceId = stagedSubstanceId;
    this.rejectionReason = '';
    this.rejectionNotes = '';
    this.rejectionNotifySupplier = this.activeStagedSubstance?.sourceType === 'Supplier input';
    this.rejectionInternalOnly = false;
    this.stagingDialogOpenedFromReview = this.reviewDrawerOpen;
    if (this.stagingDialogOpenedFromReview) {
      this.reviewDrawerOpen = false;
    }
    this.rejectDialogOpen = true;
  }

  cancelRejectDialog(): void {
    this.rejectDialogOpen = false;
    this.restoreReviewAfterStagingDialogCancel();
  }

  confirmRejectStagedSubstance(): void {
    if (!this.activeStagedSubstance || this.rejectFormInvalid) {
      return;
    }
    this.rejectStagedSubstance(this.activeStagedSubstance.stagedSubstanceId, this.rejectionReason, this.rejectionNotes);
  }

  rejectStagedSubstance(stagedSubstanceId: string, reason: string, notes: string): void {
    const record = this.stagedSubstances.find((item) => item.stagedSubstanceId === stagedSubstanceId);
    if (!record) {
      return;
    }
    const beforeStatus = record.stagingStatus;
    record.stagingStatus = 'Rejected';
    record.decision = 'Reject substance';
    if (record.sourceType === 'Supplier input' && this.rejectionNotifySupplier) {
      record.notificationStatus = 'Queued';
      record.supplierContext = record.supplierContext ? { ...record.supplierContext, notificationStatus: 'Queued' } : undefined;
    }
    this.addAuditEvent({
      user: 'You',
      action: 'Rejected',
      stagedSubstanceId: record.stagedSubstanceId,
      stagedSubstanceName: record.substanceName,
      decision: 'Reject substance',
      reason,
      beforeAfter: `Before: ${beforeStatus} | After: Rejected`,
      notes: notes || (this.rejectionInternalOnly ? 'Internal-only note retained.' : 'Rejected without additional notes.')
    });
    if (record.sourceType === 'Supplier input' && this.rejectionNotifySupplier) {
      this.addAuditEvent({
        user: 'You',
        action: 'Supplier notification queued',
        stagedSubstanceId: record.stagedSubstanceId,
        stagedSubstanceName: record.substanceName,
        decision: 'Supplier notification queued',
        reason: 'Supplier-originated record rejected.',
        beforeAfter: 'Before: Required | After: Queued',
        notes: 'Notification awareness captured; communication workflow remains outside this module.'
      });
    }
    this.rejectDialogOpen = false;
    this.stagingDialogOpenedFromReview = false;
    this.reviewDrawerOpen = false;
    this.messages.add({
      severity: 'success',
      summary: 'Staged substance rejected',
      detail: `${record.substanceName} was rejected and audit history was updated.`
    });
  }

  openInvestigationDialog(stagedSubstanceId: string): void {
    this.activeStagedSubstanceId = stagedSubstanceId;
    this.investigationReason = '';
    this.investigationNotes = '';
    this.investigationReviewer = this.activeStagedSubstance?.assignedReviewer || '';
    this.investigationFollowUpDate = '';
    this.stagingDialogOpenedFromReview = this.reviewDrawerOpen;
    if (this.stagingDialogOpenedFromReview) {
      this.reviewDrawerOpen = false;
    }
    this.investigationDialogOpen = true;
  }

  cancelInvestigationDialog(): void {
    this.investigationDialogOpen = false;
    this.restoreReviewAfterStagingDialogCancel();
  }

  confirmPendingInvestigation(): void {
    if (!this.activeStagedSubstance || this.investigationFormInvalid) {
      return;
    }
    if (this.investigationReviewer) {
      this.assignReviewer(this.activeStagedSubstance.stagedSubstanceId, this.investigationReviewer);
    }
    this.markPendingInvestigation(this.activeStagedSubstance.stagedSubstanceId, this.investigationReason, this.investigationNotes);
  }

  markPendingInvestigation(stagedSubstanceId: string, reason: string, notes: string): void {
    const record = this.stagedSubstances.find((item) => item.stagedSubstanceId === stagedSubstanceId);
    if (!record) {
      return;
    }
    const beforeStatus = record.stagingStatus;
    const beforeSignoff = record.signoffStatus;
    record.stagingStatus = 'Pending Investigation';
    record.decision = 'Mark pending investigation';
    if (record.signoffStatus === 'Not required' && (record.matchStatus === 'No Match' || record.matchStatus === 'Potential Match')) {
      record.signoffStatus = 'Required';
    }
    if (record.signoffStatus === 'Required' && (record.matchStatus === 'No Match' || record.matchStatus === 'Potential Match')) {
      record.signoffStatus = 'Requested';
    }
    this.addAuditEvent({
      user: 'You',
      action: 'Marked pending investigation',
      stagedSubstanceId: record.stagedSubstanceId,
      stagedSubstanceName: record.substanceName,
      decision: 'Mark pending investigation',
      reason,
      beforeAfter: `Before: ${beforeStatus} | After: Pending Investigation`,
      notes: notes || (this.investigationFollowUpDate ? `Follow-up date: ${this.investigationFollowUpDate}` : 'No follow-up date set.')
    });
    if (beforeSignoff !== record.signoffStatus && record.signoffStatus === 'Requested') {
      this.addAuditEvent({
        user: 'You',
        action: 'Regulatory sign-off requested',
        stagedSubstanceId: record.stagedSubstanceId,
        stagedSubstanceName: record.substanceName,
        decision: 'Mark pending investigation',
        reason: 'Ambiguous or no-match scenario was paused for manual resolution.',
        beforeAfter: `Before: ${beforeSignoff} | After: ${record.signoffStatus}`,
        notes: 'Regulatory sign-off awareness captured without creating a full approval workflow.'
      });
    }
    this.investigationDialogOpen = false;
    this.createSubstanceDrawerOpen = false;
    this.stagingDialogOpenedFromReview = false;
    this.reviewDrawerOpen = false;
    this.messages.add({
      severity: 'success',
      summary: 'Pending investigation',
      detail: `${record.substanceName} is paused for investigation.`
    });
  }

  assignReviewer(stagedSubstanceId: string, reviewer: string): void {
    const record = this.stagedSubstances.find((item) => item.stagedSubstanceId === stagedSubstanceId);
    if (!record || !reviewer) {
      return;
    }
    const beforeReviewer = record.assignedReviewer;
    record.assignedReviewer = reviewer;
    this.addAuditEvent({
      user: 'You',
      action: 'Reviewer changed',
      stagedSubstanceId: record.stagedSubstanceId,
      stagedSubstanceName: record.substanceName,
      decision: `Assigned to ${reviewer}`,
      reason: 'Reviewer assignment changed from the staging queue.',
      beforeAfter: `Before: ${beforeReviewer} | After: ${reviewer}`,
      notes: 'Assignment is retained with staged substance audit history.'
    });
    this.messages.add({
      severity: 'success',
      summary: 'Reviewer assigned',
      detail: `${record.substanceName} is assigned to ${reviewer}.`
    });
  }

  addAuditEvent(event: Omit<StagingAuditEvent, 'id' | 'dateTime'> & Partial<Pick<StagingAuditEvent, 'id' | 'dateTime'>>): void {
    this.auditEvents.unshift({
      id: event.id || `AUD-${String(this.auditEvents.length + 1).padStart(4, '0')}`,
      dateTime: event.dateTime || this.formattedAuditTimestamp(),
      user: event.user,
      action: event.action,
      stagedSubstanceId: event.stagedSubstanceId,
      stagedSubstanceName: event.stagedSubstanceName,
      decision: event.decision,
      reason: event.reason,
      beforeAfter: event.beforeAfter,
      notes: event.notes
    });
  }

  private aliasesToAddFor(record: StagedSubstance, candidate: SubstanceLibraryCandidate): string[] {
    const existingAliases = new Set(
      [candidate.substanceName, ...candidate.aliases]
        .map((value) => this.normalizeQuery(value))
        .filter(Boolean)
    );
    return record.aliases
      .map((alias) => alias.trim())
      .filter((alias) => alias && !existingAliases.has(this.normalizeQuery(alias)))
      .filter((alias, index, aliases) => aliases.findIndex((value) => this.normalizeQuery(value) === this.normalizeQuery(alias)) === index);
  }

  private restoreReviewAfterStagingDialogCancel(): void {
    if (this.stagingDialogOpenedFromReview && this.activeStagedSubstance) {
      this.reviewDrawerOpen = true;
    }
    this.stagingDialogOpenedFromReview = false;
  }

  isNavActive(item: NavItem): boolean {
    return item.key === this.activePage;
  }

  setGroupViewMode(viewMode: GroupViewMode): void {
    if (this.groupViewMode === viewMode) {
      return;
    }
    this.groupViewMode = viewMode;
    this.simulateGroupLoad('view', 260);
  }

  setGroupFilter(filter: GroupQuickFilter): void {
    this.groupFilter = filter;
    this.activeGroup = undefined;
    this.simulateGroupLoad('filter');
  }

  showDraftGroups(): void {
    this.groupQuery = '';
    this.setGroupFilter('drafts');
  }

  clearGroupFilters(): void {
    this.groupQuery = '';
    this.groupFilter = 'all';
    this.simulateGroupLoad('filter');
  }

  setGroupDetailTab(tab: GroupDetailTab): void {
    if (this.groupDetailTab === tab) {
      return;
    }
    this.groupDetailTab = tab;
    this.simulateWorkspaceLoad('subpage', 150);
  }

  onGroupQueryChange(): void {
    this.simulateGroupLoad('search', 300);
  }

  setExemptionSetViewMode(viewMode: ExemptionSetViewMode): void {
    if (this.exemptionSetViewMode === viewMode) {
      return;
    }
    this.exemptionSetViewMode = viewMode;
    this.simulateWorkspaceLoad('subpage', 140);
  }

  setExemptionSetFilter(filter: ExemptionSetFilter): void {
    this.exemptionSetFilter = filter;
    this.activeExemptionSet = undefined;
    this.simulateWorkspaceLoad('subpage', 140);
  }

  clearExemptionSetFilters(): void {
    this.exemptionSetQuery = '';
    this.exemptionSetFilter = 'all';
    this.simulateWorkspaceLoad('subpage', 140);
  }

  showDraftExemptionSets(): void {
    this.exemptionSetQuery = '';
    this.setExemptionSetFilter('drafts');
  }

  showExpiryRiskExemptionSets(): void {
    this.exemptionSetQuery = '';
    this.setExemptionSetFilter('expiry-risk');
  }

  filterMatchesActiveExemptionSet(filter: ExemptionSetFilter): boolean {
    return this.exemptionSetFilter === filter;
  }

  exemptionSetQuickFilterCount(filter: ExemptionSetFilter): number {
    return this.filterExemptionSets(this.exemptionSets, filter).length;
  }

  openExemptionSetDetail(set: ExemptionSet): void {
    this.activeExemptionSet = set;
    this.exemptionSetDetailTab = 'exemptions';
    this.activityQuery = '';
    this.activityStatus = 'All';
    this.simulateWorkspaceLoad('subpage', 170);
  }

  closeExemptionSetDetail(): void {
    this.activeExemptionSet = undefined;
    this.simulateWorkspaceLoad('subpage', 150);
  }

  setExemptionSetDetailTab(tab: ExemptionSetDetailTab): void {
    if (this.exemptionSetDetailTab === tab) {
      return;
    }
    this.exemptionSetDetailTab = tab;
    this.simulateWorkspaceLoad('subpage', 150);
  }

  openNewExemptionSetDialog(): void {
    this.exemptionSetEditorMode = 'create';
    const nextNumber = String(this.exemptionSets.length + 58).padStart(5, '0');
    this.exemptionSetDraft = {
      code: `EXS-${nextNumber}`,
      name: 'New exemption set',
      description: 'Define the regulatory source, scope, lifecycle, and reusable exemption records before publish.',
      authority: 'Authority pending',
      scope: 'Scope pending',
      version: 'Draft v1.0',
      lastPublishedVersion: 'Not published yet',
      draftVersion: 'v1.0',
      exemptions: 0,
      expiryWatchCount: 0,
      status: 'Draft',
      owner: 'Regulatory',
      created: 'Today',
      modified: 'Just now',
      lastPublished: 'Not published yet',
      publishedBy: 'Not published yet',
      dslReferenceCount: 0,
      versionNote: 'New exemption set draft. Add a clear version note before publish.',
      warnings: ['missing-applicability', 'missing-expiry']
    };
    this.exemptionSetDialogVisible = true;
  }

  openEditExemptionSetDialog(set = this.activeExemptionSet): void {
    if (!set) {
      return;
    }
    this.exemptionSetEditorMode = 'edit';
    this.exemptionSetDraft = {
      ...set,
      warnings: [...set.warnings]
    };
    this.exemptionSetDialogVisible = true;
  }

  saveExemptionSetDraft(): void {
    const draft = {
      ...this.exemptionSetDraft,
      code: this.exemptionSetDraft.code.trim() || `EXS-${String(this.exemptionSets.length + 58).padStart(5, '0')}`,
      name: this.exemptionSetDraft.name.trim() || 'New exemption set',
      description: this.exemptionSetDraft.description.trim() || 'Description required before publish.',
      authority: this.exemptionSetDraft.authority.trim() || 'Authority pending',
      scope: this.exemptionSetDraft.scope.trim() || 'Scope pending',
      owner: this.exemptionSetDraft.owner.trim() || 'Regulatory',
      modified: 'Just now',
      status: 'Draft' as ExemptionLifecycleStatus,
      warnings: [...this.exemptionSetDraft.warnings]
    };

    if (this.exemptionSetEditorMode === 'create') {
      this.exemptionSets.unshift(draft);
      this.activeExemptionSet = draft;
      this.exemptionSetDetailTab = 'details';
      this.addConnectedChange(
        'Exemption set created',
        `${draft.name} was opened as a draft exemption set with metadata, lifecycle, and publish review required.`,
        'info',
        'pi pi-plus'
      );
    } else if (this.activeExemptionSet) {
      Object.assign(this.activeExemptionSet, draft);
      this.addConnectedChange(
        'Exemption set metadata edited',
        `${draft.name} metadata was saved to draft. Published DSL consumers remain on the last published version.`,
        'info',
        'pi pi-save'
      );
    }

    this.exemptionSetDialogVisible = false;
    this.messages.add({
      severity: 'success',
      summary: 'Exemption set draft saved',
      detail: 'Metadata changes stay in draft until the publish impact review is completed.'
    });
  }

  openExemptionDrawer(mode: EditorMode, exemption?: ExemptionRecord): void {
    if (!this.activeExemptionSet) {
      return;
    }
    this.exemptionEditorMode = mode;
    this.exemptionApplicabilityQuery = '';
    this.activeExemptionDraft = exemption
      ? {
          ...exemption,
          applicability: exemption.applicability.map((record) => ({ ...record })),
          warningKeys: [...exemption.warningKeys]
        }
      : {
          id: `EXM-${this.activeExemptionSet.code.replace('EXS-', '')}-${String(this.exemptionRecords.length + 1).padStart(2, '0')}`,
          setCode: this.activeExemptionSet.code,
          code: '',
          description: '',
          thresholdMin: '',
          thresholdMax: '',
          applicability: [],
          expiryDate: '',
          effectiveDate: '2026-06-25',
          status: 'Draft add',
          notes: '',
          warningKeys: ['missing-threshold', 'missing-applicability', 'missing-expiry']
        };
    this.exemptionDialogVisible = true;
  }

  toggleExemptionApplicability(record: ExemptionApplicability): void {
    const key = `${record.kind}-${record.id}`;
    const currentKeys = new Set(this.activeExemptionDraft.applicability.map((item) => `${item.kind}-${item.id}`));
    this.activeExemptionDraft.applicability = currentKeys.has(key)
      ? this.activeExemptionDraft.applicability.filter((item) => `${item.kind}-${item.id}` !== key)
      : [...this.activeExemptionDraft.applicability, record];
  }

  removeExemptionApplicability(record: ExemptionApplicability): void {
    this.activeExemptionDraft.applicability = this.activeExemptionDraft.applicability.filter((item) => item !== record);
  }

  saveExemptionDraft(): void {
    if (!this.activeExemptionSet) {
      return;
    }
    if (this.isThresholdRangeInvalid(this.activeExemptionDraft)) {
      this.messages.add({
        severity: 'warn',
        summary: 'Threshold range invalid',
        detail: 'Threshold min cannot exceed threshold max.'
      });
      return;
    }

    const warningKeys = this.collectExemptionWarningKeys(this.activeExemptionDraft);
    const draft = {
      ...this.activeExemptionDraft,
      code: this.activeExemptionDraft.code.trim() || 'Code required',
      description: this.activeExemptionDraft.description.trim() || 'Description required before publish.',
      status: (this.exemptionEditorMode === 'create' ? 'Draft add' : 'Draft edit') as ExemptionLifecycleStatus,
      applicability: this.activeExemptionDraft.applicability.map((record) => ({ ...record })),
      warningKeys
    };
    const existingIndex = this.exemptionRecords.findIndex((exemption) => exemption.id === draft.id);
    if (existingIndex >= 0) {
      this.exemptionRecords[existingIndex] = draft;
    } else {
      this.exemptionRecords.unshift(draft);
    }
    this.syncActiveExemptionSetDraftState();
    this.exemptionDialogVisible = false;
    this.addConnectedChange(
      this.exemptionEditorMode === 'create' ? 'Exemption added' : 'Exemption edited',
      `${draft.code} was saved to ${this.activeExemptionSet.name} with threshold ${this.exemptionThresholdRange(draft)} and ${this.exemptionApplicabilitySummary(draft)} applicability.`,
      warningKeys.length ? 'warn' : 'success',
      'pi pi-shield'
    );
    this.messages.add({
      severity: warningKeys.length ? 'warn' : 'success',
      summary: warningKeys.length ? 'Draft saved with warnings' : 'Exemption draft saved',
      detail: warningKeys.length
        ? `${warningKeys.length} warning${warningKeys.length === 1 ? '' : 's'} must be reviewed before publish.`
        : 'The exemption remains in draft until the set is published.'
    });
  }

  archiveExemption(exemption: ExemptionRecord): void {
    exemption.status = 'Archived';
    exemption.warningKeys = [];
    this.syncActiveExemptionSetDraftState();
    this.addConnectedChange(
      'Exemption archived',
      `${exemption.code} was archived in the draft. Published versions remain available for audit.`,
      'warn',
      'pi pi-archive'
    );
    this.messages.add({
      severity: 'warn',
      summary: 'Exemption archived',
      detail: 'The archive state is part of the draft until the exemption set is published.'
    });
  }

  openExemptionPublishDialog(): void {
    if (!this.activeExemptionSet) {
      return;
    }
    this.exemptionPublishDialogVisible = true;
  }

  publishExemptionSet(): void {
    if (!this.activeExemptionSet) {
      return;
    }
    if (!this.canPublishActiveExemptionSet) {
      this.messages.add({
        severity: 'warn',
        summary: 'Version note required',
        detail: 'Add a version note before publishing this exemption set.'
      });
      return;
    }

    const set = this.activeExemptionSet;
    const publishedVersion = set.draftVersion || set.version.replace('Draft ', '');
    this.exemptionRecords
      .filter((exemption) => exemption.setCode === set.code)
      .forEach((exemption) => {
        if (exemption.status === 'Draft add' || exemption.status === 'Draft edit') {
          exemption.status = this.isExpiredDate(exemption.expiryDate)
            ? 'Expired'
            : this.isExpiringSoonDate(exemption.expiryDate)
              ? 'Expiring soon'
              : 'Published';
        }
      });
    set.version = publishedVersion;
    set.lastPublishedVersion = publishedVersion;
    set.status = 'Published';
    set.lastPublished = 'Today';
    set.publishedBy = 'Krupa Vasave';
    set.modified = 'Just now';
    this.exemptionSetVersions.unshift({
      setCode: set.code,
      version: publishedVersion,
      status: 'Published',
      note: set.versionNote,
      publishedBy: set.publishedBy,
      publishedDate: set.lastPublished,
      changeSummary: `${this.activeExemptionSetExemptions.length} exemption${this.activeExemptionSetExemptions.length === 1 ? '' : 's'} included; ${this.activeExemptionPublishWarnings.length} warning${this.activeExemptionPublishWarnings.length === 1 ? '' : 's'} visible at publish.`
    });
    this.exemptionPublishDialogVisible = false;
    this.addConnectedChange(
      'Draft published',
      `${set.name} ${publishedVersion} was published. ${set.dslReferenceCount} DSL reference${set.dslReferenceCount === 1 ? '' : 's'} can now consume the authoritative version.`,
      this.activeExemptionPublishWarnings.length ? 'warn' : 'success',
      'pi pi-send'
    );
    this.messages.add({
      severity: this.activeExemptionPublishWarnings.length ? 'warn' : 'success',
      summary: this.activeExemptionPublishWarnings.length ? 'Published with warnings visible' : 'Exemption set published',
      detail: `${set.name} ${publishedVersion} is now the latest published version.`
    });
  }

  openExemptionArchiveDialog(): void {
    this.exemptionArchiveReason = '';
    this.exemptionArchiveDialogVisible = true;
  }

  archiveActiveExemptionSet(): void {
    if (!this.activeExemptionSet || !this.canArchiveActiveExemptionSet) {
      this.messages.add({
        severity: 'warn',
        summary: 'Archive reason required',
        detail: 'Add a reason before archiving an exemption set that is referenced by DSLs.'
      });
      return;
    }
    const set = this.activeExemptionSet;
    set.status = 'Archived';
    set.modified = 'Just now';
    this.exemptionArchiveDialogVisible = false;
    this.addConnectedChange(
      'Exemption set archived',
      `${set.name} was archived. Active DSL references were shown before archival and should not assign archived sets going forward.`,
      'danger',
      'pi pi-archive'
    );
    this.messages.add({
      severity: 'warn',
      summary: 'Exemption set archived',
      detail: 'Archived exemption sets stay visible for audit and should not be assigned to new DSLs.'
    });
  }

  setDslListFilter(filter: DslListFilter): void {
    this.dslListFilter = filter;
    this.activeDslList = undefined;
    this.simulateWorkspaceLoad('subpage', 140);
  }

  clearDslListFilters(): void {
    this.dslListQuery = '';
    this.dslListFilter = 'all';
    this.simulateWorkspaceLoad('subpage', 140);
  }

  showDraftDslLists(): void {
    this.dslListQuery = '';
    this.setDslListFilter('drafts');
  }

	  setDslListViewMode(viewMode: DslListViewMode): void {
	    if (this.dslListViewMode === viewMode) {
	      return;
	    }
	    this.dslListViewMode = viewMode;
	    this.simulateWorkspaceLoad('subpage', 140);
	  }

	  setModuleFilter(filter: ModuleFilter): void {
	    this.moduleFilter = filter;
	    this.activeModule = undefined;
	    this.simulateWorkspaceLoad('subpage', 140);
	  }

	  clearModuleFilters(): void {
	    this.moduleQuery = '';
	    this.moduleFilter = 'all';
	    this.simulateWorkspaceLoad('subpage', 140);
	  }

	  setModuleViewMode(viewMode: ModuleViewMode): void {
	    if (this.moduleViewMode === viewMode) {
	      return;
	    }
	    this.moduleViewMode = viewMode;
	    this.simulateWorkspaceLoad('subpage', 140);
	  }

	  openModuleDetail(module: ModuleRecord): void {
	    this.activeModule = module;
	    this.moduleDetailTab = 'components';
	    this.activityQuery = '';
	    this.activityStatus = 'All';
	    this.simulateWorkspaceLoad('subpage', 170);
	  }

	  closeModuleDetail(): void {
	    this.activeModule = undefined;
	    this.simulateWorkspaceLoad('subpage', 150);
	  }

	  setModuleDetailTab(tab: ModuleDetailTab): void {
	    if (this.moduleDetailTab === tab) {
	      return;
	    }
	    this.moduleDetailTab = tab;
	    this.simulateWorkspaceLoad('subpage', 150);
	  }

  openDslListDetail(list: DslList): void {
    this.activeDslList = list;
    this.dslDetailTab = 'contents';
    this.dslContentQuery = '';
    this.dslContentPageFirst = 0;
    this.archiveParentFilter = 'DSL';
    this.activityQuery = '';
    this.activityStatus = 'All';
    this.simulateWorkspaceLoad('subpage', 170);
  }

  closeDslListDetail(): void {
    this.activeDslList = undefined;
    this.simulateWorkspaceLoad('subpage', 150);
  }

  setDslDetailTab(tab: DslDetailTab): void {
    if (this.dslDetailTab === tab) {
      return;
    }
    this.dslDetailTab = tab;
    this.simulateWorkspaceLoad('subpage', 150);
  }

  setDslContentQuery(query: string): void {
    this.dslContentQuery = query;
    this.dslContentPageFirst = 0;
  }

  onDslContentPageChange(event: PaginatorState): void {
    this.dslContentPageFirst = event.first ?? 0;
    this.dslContentRows = event.rows ?? this.dslContentRows;
  }

  isDslContentExpanded(item: DslContentItem): boolean {
    return this.expandedDslContentIds.includes(item.id);
  }

  toggleDslContentExpansion(item: DslContentItem, event?: Event): void {
    event?.stopPropagation();
    if (!item.children?.length) {
      return;
    }
    this.expandedDslContentIds = this.toggleId(this.expandedDslContentIds, item.id);
  }

  setArchiveParentFilter(filter: ArchiveParentFilter): void {
    this.archiveParentFilter = filter;
  }

  clearArchiveImpactFilters(): void {
    this.archiveSearchQuery = '';
    this.archiveStatusFilter = [];
    this.archiveGroupFilter = [];
    this.archiveImpactFilter = [];
  }

  clearArchiveHistoryFilters(): void {
    this.archiveHistorySeverityFilter = 'All';
    this.archiveHistoryDecisionFilter = 'All';
    this.archiveHistoryUserFilter = '';
    this.archiveHistoryDateFilter = '';
    this.archiveHistoryParentFilter = 'All';
  }

  openArchiveRequest(substanceId: string, parentContext: ParentContext): void {
    const candidate = this.archiveCandidateSubstances.find((substance) => substance.substanceId === substanceId);
    if (!candidate) {
      this.messages.add({
        severity: 'warn',
        summary: 'Archive candidate unavailable',
        detail: 'The selected substance would be loaded from the archive impact service in the full app.'
      });
      return;
    }

    this.selectedArchiveSubstance = candidate;
    this.selectedImpactAssessment = this.impactAssessmentForSubstance(substanceId);
    this.archiveRequestTimestamp = this.archiveNowLabel();
    this.archiveDecisionRationale = '';
    this.archiveDecisionNotes = '';
    this.finalArchiveDecision = 'Proceed with Archive';
    this.archiveRequestDialogOpen = true;
    this.assessmentSummaryOpen = false;
    this.assessmentDetailOpen = false;
    this.archiveParentFilter = parentContext.type;
  }

  generateImpactAssessment(substanceId: string): void {
    const candidate = this.archiveCandidateSubstances.find((substance) => substance.substanceId === substanceId);
    if (!candidate) {
      return;
    }

    let assessment = this.impactAssessmentForSubstance(substanceId);
    if (!assessment) {
      assessment = this.createDefaultImpactAssessment(candidate);
      this.impactAssessments.unshift(assessment);
      this.matchContexts.unshift(this.createDefaultMatchContext(assessment, candidate));
    }

    const beforeStatus = candidate.status;
    candidate.status = 'Impact Assessment Generating';
    assessment.status = 'Impact Assessment Generating';
    assessment.generatedBy = 'Maya Chen';
    assessment.generatedDate = this.archiveNowLabel();
    this.selectedArchiveSubstance = candidate;
    this.selectedImpactAssessment = assessment;
    this.archiveRequestDialogOpen = false;
    this.assessmentGenerating = true;
    this.assessmentGenerationFailed = false;
    this.assessmentProgress = 8;
    this.addArchiveAuditEvent({
      user: assessment.generatedBy,
      dateTime: assessment.generatedDate,
      action: 'Impact assessment requested',
      object: candidate.substanceName,
      impactSeverity: assessment.overallImpactSeverity,
      decision: 'None',
      rationale: 'Archive action was paused until supplier, customer, match, and data completeness impact could be generated.',
      beforeStatus,
      afterStatus: 'Archive Requested'
    });
    this.clearAssessmentGenerationTimer();
    this.assessmentGenerationTimer = setInterval(() => {
      this.assessmentProgress = Math.min(this.assessmentProgress + 18, 100);
      if (this.assessmentProgress >= 100) {
        this.completeImpactAssessmentGeneration(assessment, candidate);
      }
    }, 260);
  }

  retryImpactAssessmentGeneration(): void {
    if (!this.selectedArchiveSubstance) {
      return;
    }
    this.generateImpactAssessment(this.selectedArchiveSubstance.substanceId);
  }

  cancelImpactAssessmentGeneration(): void {
    this.clearAssessmentGenerationTimer();
    this.assessmentGenerating = false;
    this.assessmentGenerationFailed = false;
    if (this.selectedArchiveSubstance) {
      const beforeStatus = this.selectedArchiveSubstance.status;
      this.selectedArchiveSubstance.status = 'Archive Cancelled';
      if (this.selectedImpactAssessment) {
        this.selectedImpactAssessment.status = 'Archive Cancelled';
      }
      this.addArchiveAuditEvent({
        user: 'Maya Chen',
        dateTime: this.archiveNowLabel(),
        action: 'Impact assessment cancelled',
        object: this.selectedArchiveSubstance.substanceName,
        impactSeverity: this.selectedImpactAssessment?.overallImpactSeverity || 'Unknown',
        decision: 'Cancel',
        rationale: 'Archive impact generation was cancelled before decision.',
        beforeStatus,
        afterStatus: 'Archive Cancelled'
      });
    }
  }

  openImpactAssessment(assessmentId: string): void {
    const assessment = this.impactAssessments.find((item) => item.assessmentId === assessmentId);
    if (!assessment) {
      return;
    }
    this.selectedImpactAssessment = assessment;
    this.selectedArchiveSubstance = this.archiveCandidateForAssessment(assessment);
    this.archiveDetailTab = 'suppliers';
    this.assessmentDetailOpen = true;
  }

  viewArchiveCandidate(substanceId: string): void {
    const candidate = this.archiveCandidateSubstances.find((substance) => substance.substanceId === substanceId);
    if (!candidate) {
      return;
    }
    this.selectedArchiveSubstance = candidate;
    const assessment = this.impactAssessmentForSubstance(substanceId);
    if (assessment) {
      this.openImpactAssessment(assessment.assessmentId);
      return;
    }
    this.openArchiveRequest(substanceId, this.archiveParentContextFor(candidate));
  }

  viewArchiveAudit(assessmentId: string): void {
    this.openImpactAssessment(assessmentId);
    this.archiveDetailTab = 'audit';
  }

  proceedToArchive(assessmentId: string): void {
    const assessment = this.impactAssessments.find((item) => item.assessmentId === assessmentId);
    if (!assessment) {
      return;
    }
    this.selectedImpactAssessment = assessment;
    this.selectedArchiveSubstance = this.archiveCandidateForAssessment(assessment);
    this.archiveDecisionRationale = '';
    this.archiveDecisionNotes = '';

    if (assessment.dataCompleteness === 'Partial' || assessment.dataCompleteness === 'Unknown' || assessment.overallImpactSeverity === 'Unknown') {
      this.missingDataDialogOpen = true;
      return;
    }

    if (assessment.overallImpactSeverity === 'High') {
      this.highImpactDialogOpen = true;
      return;
    }

    if (assessment.overallImpactSeverity === 'Low') {
      this.lowImpactDialogOpen = true;
      return;
    }

    this.finalArchiveDecision = 'Proceed with Archive';
    this.finalDecisionDialogOpen = true;
  }

  openPendingInvestigationDialog(mode: 'Delay Archive' | 'Mark Pending Investigation'): void {
    this.pendingInvestigationMode = mode;
    this.archiveInvestigationReason = mode === 'Delay Archive' ? 'High supplier impact' : '';
    this.archiveInvestigationNotes = '';
    this.archiveInvestigationReviewer = 'Regulatory Ops';
    this.archiveInvestigationFollowUpDate = '2026-07-08';
    this.pendingInvestigationDialogOpen = true;
  }

  submitPendingInvestigation(): void {
    if (!this.selectedImpactAssessment || !this.canSubmitPendingInvestigation) {
      this.messages.add({
        severity: 'warn',
        summary: 'Investigation reason required',
        detail: 'Choose a reason and add notes when Other is selected.'
      });
      return;
    }

    const notes = [
      this.archiveInvestigationNotes.trim(),
      `Assigned reviewer: ${this.archiveInvestigationReviewer || 'Unassigned'}`,
      `Follow-up date: ${this.archiveInvestigationFollowUpDate || 'Not set'}`
    ].filter(Boolean).join(' ');

    if (this.pendingInvestigationMode === 'Delay Archive') {
      this.delayArchive(this.selectedImpactAssessment.assessmentId, this.archiveInvestigationReason, notes);
    } else {
      this.markArchivePendingInvestigation(this.selectedImpactAssessment.assessmentId, this.archiveInvestigationReason, notes);
    }
  }

  delayArchive(assessmentId: string, reason: string, notes: string): void {
    this.archiveDecisionNotes = notes;
    this.confirmArchiveDecision(assessmentId, 'Delay Archive', reason);
  }

  markArchivePendingInvestigation(assessmentId: string, reason: string, notes: string): void {
    this.archiveDecisionNotes = notes;
    this.confirmArchiveDecision(assessmentId, 'Mark Pending Investigation', reason);
  }

  confirmArchiveDecision(assessmentId: string, decision: ArchiveDecisionValue, rationale: string): void {
    const assessment = this.impactAssessments.find((item) => item.assessmentId === assessmentId);
    const candidate = assessment ? this.archiveCandidateForAssessment(assessment) : undefined;
    if (!assessment || !candidate) {
      return;
    }

    const trimmedRationale = rationale.trim();
    const rationaleRequired = decision !== 'Cancel' && (
      decision !== 'Proceed with Archive' ||
      ['Medium', 'High', 'Unknown'].includes(assessment.overallImpactSeverity)
    );
    if (rationaleRequired && trimmedRationale.length < 8) {
      this.messages.add({
        severity: 'warn',
        summary: 'Rationale required',
        detail: 'Add a defensible archive rationale before confirming this decision.'
      });
      return;
    }

    const beforeStatus = candidate.status;
    let afterStatus: ArchiveLifecycleState = 'Archive Cancelled';
    let action = 'Archive cancelled';
    if (decision === 'Proceed with Archive') {
      afterStatus = 'Archived';
      action = assessment.overallImpactSeverity === 'High' ? 'High impact archive approved' : 'Archive completed';
    } else if (decision === 'Delay Archive') {
      afterStatus = 'Pending Investigation';
      action = 'Archive delayed';
    } else if (decision === 'Mark Pending Investigation') {
      afterStatus = 'Pending Investigation';
      action = 'Pending investigation marked';
    }

    candidate.status = afterStatus;
    assessment.status = afterStatus;
    const decisionRecord: ArchiveDecision = {
      decisionId: `ADEC-17320-${String(this.archiveDecisions.length + 1).padStart(3, '0')}`,
      assessmentId,
      decision,
      rationale: trimmedRationale || 'No rationale required for this cancellation.',
      notes: this.archiveDecisionNotes.trim(),
      decidedBy: 'Maya Chen',
      decidedDate: this.archiveNowLabel()
    };
    this.archiveDecisions.unshift(decisionRecord);
    this.addArchiveAuditEvent({
      user: decisionRecord.decidedBy,
      dateTime: decisionRecord.decidedDate,
      action,
      object: candidate.substanceName,
      impactSeverity: assessment.overallImpactSeverity,
      decision,
      rationale: decisionRecord.rationale,
      beforeStatus,
      afterStatus
    });

    this.highImpactDialogOpen = false;
    this.lowImpactDialogOpen = false;
    this.missingDataDialogOpen = false;
    this.pendingInvestigationDialogOpen = false;
    this.finalDecisionDialogOpen = false;
    this.assessmentSummaryOpen = decision !== 'Proceed with Archive';
    this.selectedImpactAssessment = assessment;
    this.selectedArchiveSubstance = candidate;

    if (decision === 'Proceed with Archive') {
      this.archiveCompleteDialogOpen = true;
    }

    this.messages.add({
      severity: decision === 'Proceed with Archive' ? 'success' : decision === 'Cancel' ? 'info' : 'warn',
      summary: decision === 'Proceed with Archive' ? 'Archive completed' : decision,
      detail: `${candidate.substanceName} is now ${afterStatus.toLowerCase()}.`
    });
  }

  addArchiveAuditEvent(event: ArchiveAuditEvent): void {
    this.archiveAuditEvents.unshift(event);
  }

  getImpactSeverityTag(severity: ImpactSeverity): Severity {
    if (severity === 'High') {
      return 'danger';
    }
    if (severity === 'Medium') {
      return 'warn';
    }
    if (severity === 'Low') {
      return 'success';
    }
    return 'secondary';
  }

  getDataCompletenessMessage(assessment: ImpactAssessment): string {
    if (assessment.dataCompleteness === 'Complete') {
      return 'Complete impact data was available for supplier declarations, customer disclosures, and match context.';
    }
    if (assessment.dataCompleteness === 'Partial') {
      return `Partial assessment: ${assessment.assessmentLimitations.join(', ') || 'some downstream impact sources are incomplete'}.`;
    }
    return `Unknown completeness: ${assessment.assessmentLimitations.join(', ') || 'impact data is missing or ambiguous'}.`;
  }

  archiveParentContextFor(candidate: ArchiveCandidateSubstance): ParentContext {
    return {
      type: candidate.parentType,
      name: candidate.parentName,
      version: candidate.parentVersion,
      status: candidate.parentStatus,
      substanceCount: candidate.parentSubstanceCount
    };
  }

  impactAssessmentForSubstance(substanceId: string): ImpactAssessment | undefined {
    return this.impactAssessments.find((assessment) => assessment.substanceId === substanceId);
  }

  archiveCandidateForAssessment(assessment: ImpactAssessment): ArchiveCandidateSubstance | undefined {
    return this.archiveCandidateSubstances.find((candidate) => candidate.substanceId === assessment.substanceId);
  }

  archiveDecisionForAssessment(assessmentId: string): ArchiveDecision | undefined {
    return this.archiveDecisions.find((decision) => decision.assessmentId === assessmentId);
  }

  archiveAssessmentSupplierDisplay(assessment: ImpactAssessment): string {
    if (assessment.overallImpactSeverity === 'Unknown' && assessment.declarationCount === 0) {
      return 'Unknown';
    }
    return `${assessment.declarationCount}`;
  }

  archiveAssessmentCustomerDisplay(assessment: ImpactAssessment): string {
    if (assessment.overallImpactSeverity === 'Unknown' && assessment.disclosureCount === 0) {
      return 'Unknown';
    }
    return `${assessment.disclosureCount}`;
  }

  archiveDataCompletenessSeverity(completeness: DataCompleteness): 'success' | 'warn' | 'secondary' {
    if (completeness === 'Complete') {
      return 'success';
    }
    if (completeness === 'Partial') {
      return 'warn';
    }
    return 'secondary';
  }

  archiveDecisionSeverity(decision: ArchiveDecisionValue | 'Pending'): Severity {
    if (decision === 'Proceed with Archive') {
      return 'success';
    }
    if (decision === 'Delay Archive' || decision === 'Mark Pending Investigation' || decision === 'Pending') {
      return 'warn';
    }
    return 'secondary';
  }

  viewArchiveAuditFromComplete(): void {
    this.archiveCompleteDialogOpen = false;
    this.assessmentDetailOpen = true;
    this.archiveDetailTab = 'audit';
  }

  archiveAnotherSubstance(): void {
    this.archiveCompleteDialogOpen = false;
    this.assessmentSummaryOpen = false;
    this.assessmentDetailOpen = false;
    this.selectedArchiveSubstance = undefined;
    this.selectedImpactAssessment = undefined;
  }

  openNewDslList(): void {
    const draftList: DslList = {
      id: `DSL-DRAFT-${String(this.dslLists.length + 1).padStart(3, '0')}`,
      name: 'New DSL list',
      description: 'Add authority, version note, and referenced contents before activation.',
      authority: 'Authority pending',
      created: 'Today',
      version: 'Draft v1.0',
      versionNote: 'New list draft. Add source note before activation.',
      substances: 0,
      groups: 0,
      exemptionSets: 0,
      modules: 0,
      status: 'Draft',
      effective: '2026-06-23',
      owner: 'Regulatory',
      scope: 'Custom',
      modified: 'Just now'
    };
    this.dslLists.unshift(draftList);
    this.openDslListDetail(draftList);
    this.dslDetailTab = 'details';
    this.addConnectedChange(
      'DSL list draft created',
      'A new DSL list draft workspace was opened so details, contents, exemption sets, and version notes can be filled in before activation.',
      'info',
      'pi pi-plus'
    );
    this.messages.add({
      severity: 'info',
      summary: 'Draft workspace opened',
      detail: 'Add list details, referenced contents, and exemption sets before activation.'
    });
  }

  saveDslListDetails(): void {
    if (!this.activeDslList) {
      return;
    }
    if (this.guardActiveDslReviewLock('edit list details online')) {
      return;
    }
    this.activeDslList.name = this.activeDslList.name.trim() || 'New DSL list';
    this.activeDslList.description = this.activeDslList.description.trim() || 'Description required before activation.';
    this.activeDslList.authority = this.activeDslList.authority.trim() || 'Authority pending';
    this.activeDslList.versionNote = this.activeDslList.versionNote.trim() || 'Version note required before activation.';
    this.activeDslList.status = 'Draft';
    this.activeDslList.modified = 'Just now';
    this.addConnectedChange(
      'DSL list details saved',
      `${this.activeDslList.name} details and version note were saved as a draft. Active modules remain unchanged until list activation.`,
      'info',
      'pi pi-save'
    );
    this.messages.add({
      severity: 'success',
      summary: 'Draft details saved',
      detail: 'The list remains draft-only until activation review.'
    });
  }

  openDslAddSubstanceDialog(): void {
    if (this.guardActiveDslReviewLock('add substances online')) {
      return;
    }
    this.dslSubstanceQuery = '';
    this.selectedDslSubstanceIds = [];
    this.resetDslEntryFields();
    this.dslAddSubstanceDialogVisible = true;
  }

  openDslAddGroupDialog(): void {
    if (this.guardActiveDslReviewLock('add groups online')) {
      return;
    }
    this.dslGroupQuery = '';
    this.selectedDslGroupIds = [];
    this.resetDslEntryFields();
    this.dslAddGroupDialogVisible = true;
  }

  openDslAddExemptionDialog(): void {
    if (this.guardActiveDslReviewLock('add exemption sets online')) {
      return;
    }
    this.dslExemptionQuery = '';
    this.selectedDslExemptionCodes = [];
    this.dslEntryEffectiveDate = this.activeDslList?.effective || '2026-06-23';
    this.dslAddExemptionDialogVisible = true;
  }

  toggleDslSubstance(substance: Substance): void {
    this.selectedDslSubstanceIds = this.toggleId(this.selectedDslSubstanceIds, substance.id);
  }

  toggleDslGroup(candidate: DslGroupCandidate): void {
    if (!candidate.safe) {
      this.messages.add({
        severity: 'warn',
        summary: 'Reference blocked',
        detail: candidate.reason
      });
      return;
    }
    this.selectedDslGroupIds = this.toggleId(this.selectedDslGroupIds, candidate.id);
  }

  toggleDslExemption(set: ExemptionSet): void {
    this.selectedDslExemptionCodes = this.toggleId(this.selectedDslExemptionCodes, set.code);
  }

  addSubstancesToDslDraft(): void {
    const selected = this.selectedDslSubstances;
    if (!selected.length || !this.activeDslList) {
      this.messages.add({
        severity: 'warn',
        summary: 'Choose substances',
        detail: 'Select one or more substance records before adding them to the list draft.'
      });
      return;
    }
    if (this.guardActiveDslReviewLock('add substances online')) {
      return;
    }
    const existingIds = new Set(this.dslContentItems.filter((item) => item.status !== 'Draft remove').map((item) => item.id));
    const addable = selected.filter((substance) => !existingIds.has(substance.id));
    if (!addable.length) {
      this.messages.add({
        severity: 'warn',
        summary: 'Already referenced',
        detail: 'The selected substances are already referenced by this DSL.'
      });
      return;
    }
    for (const substance of [...addable].reverse()) {
      this.dslContentItems.unshift({
        id: substance.id,
        name: substance.name,
        kind: 'Substance',
        authority: substance.authority,
        cas: substance.cas,
        ec: substance.ec,
        effective: this.dslEntryEffectiveDate,
        inclusion: this.dslEntryInclusion,
        internalNote: this.dslEntryInternalNote,
        externalNote: this.dslEntryExternalNote,
        status: 'Draft add'
      });
    }
    this.syncActiveDslDraftState();
    this.dslAddSubstanceDialogVisible = false;
    this.selectedDslSubstanceIds = [];
    this.addConnectedChange(
      'DSL substances staged',
      `${addable.length} substance${addable.length === 1 ? '' : 's'} added by reference to ${this.activeDslList.name} draft with effective date ${this.dslEntryEffectiveDate}.`,
      'warn',
      'pi pi-plus'
    );
    this.messages.add({
      severity: 'warn',
      summary: `${addable.length} substance${addable.length === 1 ? '' : 's'} added to draft`,
      detail: 'Active list contents stay unchanged until the draft is activated.'
    });
  }

  addGroupsToDslDraft(): void {
    const selected = this.selectedSafeDslGroupCandidates;
    if (!selected.length || !this.activeDslList) {
      this.messages.add({
        severity: 'warn',
        summary: 'Choose groups',
        detail: 'Select one or more safe groups before adding them to the list draft.'
      });
      return;
    }
    if (this.guardActiveDslReviewLock('add groups online')) {
      return;
    }
    const existingIds = new Set(this.dslContentItems.filter((item) => item.status !== 'Draft remove').map((item) => item.id));
    const addable = selected.filter((candidate) => !existingIds.has(candidate.id));
    if (!addable.length) {
      this.messages.add({
        severity: 'warn',
        summary: 'Already referenced',
        detail: 'The selected groups are already referenced by this DSL.'
      });
      return;
    }
    for (const candidate of addable) {
      this.dslContentItems.push({
        id: candidate.id,
        name: candidate.name,
        kind: 'Group',
        authority: candidate.owner,
        version: candidate.version,
        substances: candidate.members,
        groups: 0,
        effective: this.dslEntryEffectiveDate,
        inclusion: this.dslEntryInclusion,
        internalNote: this.dslEntryInternalNote,
        externalNote: this.dslEntryExternalNote,
        status: 'Draft add',
        children: [
          { kind: 'Substance', id: 'MS-0042819', name: 'Representative member', cas: '7440-43-9', ec: '231-152-8' },
          { kind: 'Subgroup', id: 'GRP-EXAMPLE', name: 'Nested subgroup summary' }
        ]
      });
    }
    this.syncActiveDslDraftState();
    this.dslAddGroupDialogVisible = false;
    this.selectedDslGroupIds = [];
    this.addConnectedChange(
      'DSL groups staged',
      `${addable.length} group${addable.length === 1 ? '' : 's'} added by reference to ${this.activeDslList.name} draft after circular-reference checks.`,
      'warn',
      'pi pi-sitemap'
    );
    this.messages.add({
      severity: 'success',
      summary: `${addable.length} group${addable.length === 1 ? '' : 's'} added to draft`,
      detail: 'Expandable group contents stay referenced and auditable.'
    });
  }

  addExemptionsToDslDraft(): void {
    const selected = this.selectedDslExemptionCandidates;
    if (!selected.length || !this.activeDslList) {
      this.messages.add({
        severity: 'warn',
        summary: 'Choose exemption sets',
        detail: 'Select one or more exemption sets before adding them to the list draft.'
      });
      return;
    }
    if (this.guardActiveDslReviewLock('add exemption sets online')) {
      return;
    }
    const existingCodes = new Set(this.dslExemptionReferences.map((reference) => reference.code));
    const addable = selected.filter((set) => !existingCodes.has(set.code));
    if (!addable.length) {
      this.messages.add({
        severity: 'warn',
        summary: 'Already referenced',
        detail: 'The selected exemption sets are already attached to this DSL.'
      });
      return;
    }
    for (const set of addable) {
      this.dslExemptionReferences.push({
        code: set.code,
        name: set.name,
        exemptions: set.exemptions,
        authority: set.authority,
        effective: this.dslEntryEffectiveDate,
        status: 'Draft add'
      });
    }
    this.syncActiveDslDraftState();
    this.dslAddExemptionDialogVisible = false;
    this.selectedDslExemptionCodes = [];
    this.addConnectedChange(
      'DSL exemption sets staged',
      `${addable.length} exemption set${addable.length === 1 ? '' : 's'} attached to ${this.activeDslList.name} draft with effective date ${this.dslEntryEffectiveDate}.`,
      'warn',
      'pi pi-shield'
    );
    this.messages.add({
      severity: 'success',
      summary: `${addable.length} exemption set${addable.length === 1 ? '' : 's'} added`,
      detail: 'The effective date is saved with the list reference.'
    });
  }

  removeDslContent(item: DslContentItem): void {
    if (this.guardActiveDslReviewLock('remove contents online')) {
      return;
    }
    if (item.status === 'Draft add') {
      const index = this.dslContentItems.indexOf(item);
      if (index >= 0) {
        this.dslContentItems.splice(index, 1);
      }
    } else {
      item.status = 'Draft remove';
    }
    this.syncActiveDslDraftState();
    this.messages.add({
      severity: 'warn',
      summary: 'Removal staged',
      detail: 'The active DSL remains unchanged until this draft is activated.'
    });
  }

  removeDslExemption(reference: DslExemptionReference): void {
    if (this.guardActiveDslReviewLock('remove exemption sets online')) {
      return;
    }
    if (reference.status === 'Draft add') {
      const index = this.dslExemptionReferences.indexOf(reference);
      if (index >= 0) {
        this.dslExemptionReferences.splice(index, 1);
      }
    } else {
      reference.status = 'Draft remove';
    }
    this.syncActiveDslDraftState();
    this.messages.add({
      severity: 'warn',
      summary: 'Exemption update staged',
      detail: 'The exemption set change stays in draft until activation.'
    });
  }

  openDslActivationDialog(): void {
    if (!this.activeDslList) {
      return;
    }
    if (this.guardActiveDslReviewLock('activate this list')) {
      return;
    }
    this.dslActivationDialogVisible = true;
  }

  activateDslListDraft(): void {
    if (!this.activeDslList) {
      return;
    }
    if (this.guardActiveDslReviewLock('activate this list')) {
      return;
    }
    const list = this.activeDslList;
    const activatedVersion = this.dslActivationVersionLabel(list);
    for (let index = this.dslContentItems.length - 1; index >= 0; index -= 1) {
      const item = this.dslContentItems[index];
      if (item.status === 'Draft remove') {
        this.dslContentItems.splice(index, 1);
      } else if (item.status === 'Draft add') {
        item.status = 'Active';
      }
    }
    for (let index = this.dslExemptionReferences.length - 1; index >= 0; index -= 1) {
      const reference = this.dslExemptionReferences[index];
      if (reference.status === 'Draft remove') {
        this.dslExemptionReferences.splice(index, 1);
      } else if (reference.status === 'Draft add') {
        reference.status = 'Active';
      }
    }
    list.version = activatedVersion;
    list.status = 'Active';
    list.modified = 'Just now';
    list.substances = this.activeDslContents.filter((item) => item.kind === 'Substance').length;
    list.groups = this.activeDslContents.filter((item) => item.kind === 'Group').length;
    list.exemptionSets = this.activeDslExemptionReferences.length;
    this.dslActivationDialogVisible = false;
    this.addConnectedChange(
      'DSL list activated',
      `${list.name} ${activatedVersion} is now Active and can be selected by DSL modules. Module deployment remains a separate module workflow.`,
      'success',
      'pi pi-check-circle'
    );
    this.messages.add({
      severity: 'success',
      summary: 'DSL list activated',
      detail: `${list.name} is Active. Modules can now use this list version.`
    });
  }

  dslActivationVersionLabel(list = this.activeDslList): string {
    if (!list) {
      return 'v1.0';
    }
    return list.version.startsWith('Draft ') ? list.version.replace('Draft ', '') : list.version;
  }

  setBulkStep(step: BulkStep): void {
    this.bulkStep = step;
  }

  selectBulkTemplate(templateId: string): void {
    this.selectedBulkTemplateId = templateId;
  }

  toggleBulkValidationCheck(checkId: BulkValidationId): void {
    this.expandedBulkValidationId = this.expandedBulkValidationId === checkId ? undefined : checkId;
  }

  isBulkValidationExpanded(checkId: BulkValidationId): boolean {
    return this.expandedBulkValidationId === checkId;
  }

  validationReviewCount(checkId: BulkValidationId): number {
    return this.bulkReviewRows.filter((row) => row.issue === checkId).length;
  }

  validationLabel(checkId: BulkValidationId): string {
    return this.bulkValidationChecks.find((check) => check.id === checkId)?.label || 'Validation';
  }

  reviewBulkIssue(checkId: BulkValidationId): void {
    this.activeBulkReviewFilter = checkId;
    this.activeBulkReviewRowId = this.filteredBulkReviewRows[0]?.row || '';
    this.bulkStep = 'review';
  }

  selectBulkReviewRow(row: BulkReviewRow): void {
    this.activeBulkReviewRowId = row.row;
  }

  openBulkReviewDrawer(row: BulkReviewRow): void {
    this.selectBulkReviewRow(row);
    this.bulkDecisionDrawerVisible = true;
  }

  bulkReviewRowState(row: BulkReviewRow): 'ready' | 'review' | 'danger' | 'deferred' {
    if (row.status === 'Deferred') {
      return 'deferred';
    }
    if (row.severity === 'danger' || row.status === 'Rejected') {
      return 'danger';
    }
    if (row.severity === 'success') {
      return 'ready';
    }
    return 'review';
  }

  bulkReviewActionOptions(row: BulkReviewRow | undefined): BulkReviewActionOption[] {
    if (!row) {
      return [];
    }
    if (row.issue === 'dates') {
      return [
        { key: 'stage', label: 'Confirm date', icon: 'pi pi-check', severity: 'success' },
        { key: 'editDate', label: 'Edit date', icon: 'pi pi-pencil', severity: 'secondary', outlined: true },
        { key: 'defer', label: 'Defer row', icon: 'pi pi-clock', severity: 'secondary', outlined: true }
      ];
    }
    if (row.issue === 'duplicates') {
      return [
        { key: 'link', label: 'Link existing', icon: 'pi pi-link', severity: 'success' },
        { key: 'alias', label: 'Add as alias', icon: 'pi pi-tags', severity: 'secondary', outlined: true },
        { key: 'create', label: 'Create staged record', icon: 'pi pi-plus', severity: 'secondary', outlined: true },
        { key: 'defer', label: 'Defer row', icon: 'pi pi-clock', severity: 'secondary', outlined: true },
        { key: 'reject', label: 'Reject row', icon: 'pi pi-times', severity: 'danger', outlined: true }
      ];
    }
    if (row.issue === 'matching') {
      return [
        { key: 'alias', label: 'Add alias', icon: 'pi pi-tags', severity: 'success' },
        { key: 'link', label: 'Link existing', icon: 'pi pi-link', severity: 'secondary', outlined: true },
        { key: 'defer', label: 'Defer row', icon: 'pi pi-clock', severity: 'secondary', outlined: true }
      ];
    }
    return [
      { key: 'stage', label: 'Stage row', icon: 'pi pi-inbox', severity: 'success' },
      { key: 'defer', label: 'Defer row', icon: 'pi pi-clock', severity: 'secondary', outlined: true }
    ];
  }

  applyBulkReviewDecision(row: BulkReviewRow | undefined, action: BulkReviewActionKey): void {
    if (!row) {
      return;
    }

    const outcomes: Record<BulkReviewActionKey, Pick<BulkReviewRow, 'status' | 'decision' | 'severity'>> = {
      stage: { status: 'Ready', decision: row.issue === 'dates' ? 'Future date confirmed for staging' : 'Stage this row in draft', severity: 'success' },
      link: { status: 'Ready', decision: 'Link to existing authoritative record', severity: 'success' },
      alias: { status: 'Ready', decision: 'Add uploaded value as alias', severity: 'success' },
      create: { status: 'Ready', decision: 'Create new staged record', severity: 'success' },
      editDate: { status: 'Needs review', decision: 'Open date correction before staging', severity: 'warn' },
      defer: { status: 'Deferred', decision: 'Keep in staging queue for later', severity: 'secondary' },
      reject: { status: 'Rejected', decision: 'Exclude this row from this upload', severity: 'danger' }
    };

    Object.assign(row, outcomes[action]);
    this.messages.add({
      severity: action === 'reject' ? 'warn' : 'success',
      summary: 'Decision saved',
      detail: `Row ${row.row} now says: ${row.decision}.`
    });
  }

  downloadBulkTemplate(): void {
    const template = this.selectedBulkTemplate;
    if (!template) {
      this.messages.add({
        severity: 'warn',
        summary: 'Choose a template first',
        detail: 'Pick the content type so the download has the right columns.'
      });
      return;
    }
    this.downloadJobs.unshift({
      name: `${template.label} bulk template`,
      scope: template.columns,
      format: 'XLSX',
      status: 'Ready',
      surface: 'bulk',
      fileId: this.createExportFileId('bulk'),
      downloadedAt: this.formattedDownloadTimestamp(),
      parentName: template.label,
      includedFields: template.columns,
      lockState: 'Unlocked'
    });
    this.messages.add({
      severity: 'success',
      summary: 'Template ready',
      detail: `${template.label} template is ready with the required columns.`
    });
    this.bulkStep = 'upload';
  }

  useExistingBulkFile(): void {
    this.bulkStep = 'upload';
  }

  handleBulkFileSelect(event: { files?: File[]; currentFiles?: File[] }): void {
    const file = event.files?.[0] || event.currentFiles?.[0];
    this.bulkUploadFileName = file?.name || `${this.selectedBulkTemplate?.label || 'Bulk'} upload.xlsx`;
    this.bulkDetectedType = this.detectBulkContentType(this.bulkUploadFileName);
    this.bulkValidationReady = true;
    this.bulkReviewCommitted = false;
    this.bulkStep = 'validate';
  }

  analyzeBulkUpload(): void {
    if (!this.bulkUploadFileName) {
      this.bulkUploadFileName = `${this.selectedBulkTemplate?.label || 'Bulk'} completed template.xlsx`;
    }
    this.bulkDetectedType = this.detectBulkContentType(this.bulkUploadFileName);
    this.bulkValidationReady = true;
    this.bulkReviewCommitted = false;
    this.bulkStep = 'validate';
    this.messages.add({
      severity: 'info',
      summary: 'File analyzed',
      detail: `${this.bulkDetectedType} content is ready for validation review.`
    });
  }

  reviewBulkUpload(): void {
    if (!this.bulkValidationReady) {
      this.analyzeBulkUpload();
      return;
    }
    this.activeBulkReviewFilter = 'all';
    this.activeBulkReviewRowId = this.filteredBulkReviewRows[0]?.row || '';
    this.bulkStep = 'review';
  }

  commitBulkUpload(): void {
    const readyRows = this.filteredBulkReviewRows.filter((row) => row.severity === 'success').length;
    const reviewRows = this.filteredBulkReviewRows.length - readyRows;
    this.bulkReviewCommitted = true;
    const stagedSubstanceId = `STG-${String(this.stagedSubstances.length + 1).padStart(4, '0')}`;
    this.stagedSubstances.unshift({
      stagedSubstanceId,
      substanceName: 'Dibutyl phthalate',
      CAS: '84-74-2',
      EC: '201-557-4',
      aliases: ['DBP', 'Di-n-butyl phthalate'],
      source: 'Bulk upload',
      sourceType: 'Bulk upload',
      dateReceived: '2026-06-30',
      dataConfidence: 'High',
      completenessScore: 94,
      stagingStatus: 'Ready for Review',
      matchStatus: 'Potential Match',
      assignedReviewer: 'Unassigned',
      notificationStatus: 'Not required',
      signoffStatus: 'Required',
      decision: 'Leave unassigned / no action',
      currentLibraryStatus: 'Candidate review',
      sourceMetadata: {
        sourceSystem: 'Bulk upload',
        submittedBy: 'You',
        originalSubmittedName: 'Dibutyl phthalate',
        originalCAS: '84-74-2',
        originalEC: '201-557-4',
        externalReference: this.bulkUploadFileName || 'Bulk upload sample',
        ingestionBatch: 'BULK-20260630-01',
        confidenceRating: 'High',
        completenessScore: 94
      }
    });
    this.addAuditEvent({
      user: 'You',
      action: 'Staged record created',
      stagedSubstanceId,
      stagedSubstanceName: 'Dibutyl phthalate',
      decision: 'Leave unassigned / no action',
      reason: 'Clean bulk-upload row committed to staging for substance review.',
      beforeAfter: 'Before: upload row | After: Ready for Review',
      notes: 'Production Substance Library remains unchanged until staging approval.'
    });
    this.addConnectedChange(
      'Bulk upload staged for review',
      `${readyRows} clean rows were staged; ${reviewRows} rows remain in conflict review before activation.`,
      'warn',
      'pi pi-upload'
    );
    this.messages.add({
      severity: 'success',
      summary: 'Rows staged',
      detail: 'Clean rows moved into staging. Conflicts stayed visible for Regulatory review.'
    });
  }

  resetBulkWorkflow(): void {
    this.bulkStep = 'template';
    this.bulkUploadFileName = '';
    this.bulkDetectedType = '';
    this.bulkValidationReady = false;
    this.bulkReviewCommitted = false;
    this.selectedBulkTemplateId = '';
    this.expandedBulkValidationId = undefined;
    this.activeBulkReviewFilter = 'all';
    this.activeBulkReviewRowId = '12';
    this.bulkDecisionDrawerVisible = false;
  }

  bulkStepState(step: BulkStep): 'active' | 'complete' | 'upcoming' {
    const index = this.bulkSteps.findIndex((candidate) => candidate.key === step);
    if (index < this.activeBulkStepIndex) {
      return 'complete';
    }
    return index === this.activeBulkStepIndex ? 'active' : 'upcoming';
  }

  openGroupDetail(group: SubstanceGroup): void {
    this.activeGroup = group;
    this.groupDetailTab = 'details';
    this.archiveParentFilter = 'Group';
    this.simulateWorkspaceLoad('subpage', 170);
    this.activityQuery = '';
    this.activityStatus = 'All';
    this.versionNote = group.signal
      ? 'Adding DBP per ECHA bulletin 2026-05-12. Lifecycle impact requires review before activation.'
      : `${group.name} reviewed with no draft changes yet.`;
    this.groupSourceNote = group.owner === 'Solutions Delivery'
      ? 'Customer list maintenance review'
      : 'Regulatory source review';
  }

  closeGroupDetail(): void {
    this.activeGroup = undefined;
    this.simulateGroupLoad('filter', 260);
    this.simulateWorkspaceLoad('subpage', 160);
  }

  openGroupPublishDialog(): void {
    this.groupPublishDialogVisible = true;
  }

  publishGroupUpdate(): void {
    const groupName = this.activeGroup?.name || 'This group';
    const activatedVersion = this.publishGroupVersionLabel(this.activeGroup);
    const hasAssociatedDsls = this.activeGroupDslReferences.length > 0;
    this.groupPublishDialogVisible = false;
    if (this.activeGroup) {
      this.activeGroup.version = activatedVersion;
      this.activeGroup.status = 'Active';
      this.activeGroup.signal = undefined;
      this.activeGroup.lastActivated = 'Jun 22, 2026';
      this.activeGroup.modified = 'Just now';
    }
    this.addConnectedChange(
      'Group activation review queued',
      hasAssociatedDsls
        ? `${groupName} ${activatedVersion} will activate for ${this.groupDslReferencesReceivingUpdate.length} selected DSLs after validation.`
        : `${groupName} ${activatedVersion} will become active as a governed group version without changing DSL lists.`,
      'warn',
      'pi pi-send'
    );
    this.messages.add({
      severity: 'warn',
      summary: 'Activation review queued',
      detail: hasAssociatedDsls
        ? `${groupName} stays in draft until selected DSL updates are approved.`
        : `${groupName} is queued as a group-only activation; DSL lists can reference it later.`
    });
  }

  publishGroupVersionLabel(group = this.activeGroup): string {
    if (!group) {
      return 'v4.3';
    }
    return group.version.startsWith('Draft') ? group.version.replace('Draft ', '') : 'v4.3';
  }

  openNewGroupDialog(): void {
    const draftGroup: SubstanceGroup = {
      id: `GRP-DRAFT-${String(this.groups.length + 1).padStart(3, '0')}`,
      name: 'New substance group',
      description: 'Add a plain-language description, then add substances or nested subgroups by reference.',
      members: 0,
      dslCount: 0,
      version: 'Draft v1.0',
      status: 'Draft',
      owner: 'Regulatory',
      modified: 'Just now',
      created: 'Jun 22, 2026',
      lastActivated: 'Not active yet',
      color: '#dfecea',
      signal: 'New draft'
    };
    this.groupDraftMembers.splice(0);
    this.groups.unshift(draftGroup);
    this.activeGroup = draftGroup;
    this.groupDetailTab = 'details';
    this.versionNote = 'New group draft. Add version note before activation.';
    this.groupSourceNote = 'Draft source evidence required before activation.';
    this.addConnectedChange(
      'Group draft created',
      'A new group draft workspace was opened so details, parameters, substances, and subgroups can be filled in before activation.',
      'info',
      'pi pi-plus'
    );
    this.messages.add({
      severity: 'info',
      summary: 'Draft workspace opened',
      detail: 'Fill in the group details, add members, then review activation impact.'
    });
  }

  saveGroupDetails(): void {
    if (!this.activeGroup) {
      return;
    }
    this.activeGroup.name = this.activeGroup.name.trim() || 'New substance group';
    this.activeGroup.description = this.activeGroup.description.trim() || 'Description required before activation.';
    this.activeGroup.owner = this.activeGroup.owner.trim() || 'Regulatory';
    this.activeGroup.modified = 'Just now';
    this.activeGroup.status = 'Draft';
    this.activeGroup.signal = this.activeGroup.signal || 'Draft details saved';
    this.addConnectedChange(
      'Group draft details saved',
      `${this.activeGroup.name} draft details, source note, and default parameters were saved without changing active DSLs.`,
      'info',
      'pi pi-save'
    );
    this.messages.add({
      severity: 'success',
      summary: 'Draft details saved',
      detail: 'The group remains draft-only until activation impact is reviewed.'
    });
  }

  showGroupFilters(): void {
    this.messages.add({
      severity: 'info',
      summary: 'Filters ready',
      detail: 'Use search, filter chips, cards, and table view to narrow reusable group work.'
    });
  }

  showMostUsedGroups(): void {
    this.groupQuery = '';
    this.groupFilter = 'most-used';
    this.messages.add({
      severity: 'info',
      summary: 'Most used groups shown',
      detail: 'The prototype keeps high-use groups visible with DSL counts on every row.'
    });
  }

  openGroupAddSubstanceDialog(): void {
    this.groupSubstanceQuery = '';
    this.selectedGroupSubstanceIds = [];
    this.groupMemberThreshold = this.groupDefaultThreshold;
    this.groupMemberEffectiveDate = this.groupDefaultEffectiveDate;
    this.groupAddSubstanceDialogVisible = true;
  }

  toggleGroupSubstance(substance: Substance): void {
    this.selectedGroupSubstanceIds = this.toggleId(this.selectedGroupSubstanceIds, substance.id);
  }

  stageGroupSubstances(): void {
    const selectedSubstances = this.selectedGroupSubstances;
    if (!selectedSubstances.length || !this.activeGroup) {
      this.messages.add({
        severity: 'warn',
        summary: 'Choose substances',
        detail: 'Search the substance library and select one or more records before adding them to the group draft.'
      });
      return;
    }

    const groupName = this.activeGroup.name;
    const targetMembers = this.currentGroupMemberList();
    const existingIds = new Set(targetMembers.filter((member) => member.status !== 'Draft remove').map((member) => member.id));
    const addableSubstances = selectedSubstances.filter((substance) => !existingIds.has(substance.id));

    if (!addableSubstances.length) {
      this.messages.add({
        severity: 'warn',
        summary: 'Already in group',
        detail: 'The selected substances are already referenced by this group.'
      });
      return;
    }

    for (const substance of [...addableSubstances].reverse()) {
      targetMembers.unshift({
        name: substance.name,
        id: substance.id,
        cas: substance.cas,
        ec: substance.ec,
        threshold: this.groupMemberThreshold,
        effective: this.groupMemberEffectiveDate,
        status: 'Draft add',
        kind: 'Substance'
      });
    }
    this.syncActiveGroupDraftState();
    this.groupAddSubstanceDialogVisible = false;
    this.selectedGroupSubstanceIds = [];
    this.addConnectedChange(
      'Group draft members staged',
      `${addableSubstances.length} substance${addableSubstances.length === 1 ? '' : 's'} staged in ${groupName}. Active DSLs stay on the current version until activation impact is reviewed.`,
      'warn',
      'pi pi-plus'
    );
    this.messages.add({
      severity: 'warn',
      summary: `${addableSubstances.length} substance${addableSubstances.length === 1 ? '' : 's'} added to draft`,
      detail: 'Nothing changes in active DSLs until the draft version is approved.'
    });
  }

  openSubgroupCheckDialog(): void {
    this.subgroupQuery = '';
    this.selectedSubgroupIds = [];
    this.subgroupCheckDialogVisible = true;
  }

  toggleSubgroupCandidate(candidate: SubgroupCandidate): void {
    if (!candidate.safe) {
      this.messages.add({
        severity: 'warn',
        summary: 'Circular reference blocked',
        detail: candidate.reason
      });
      return;
    }
    this.selectedSubgroupIds = this.toggleId(this.selectedSubgroupIds, candidate.id);
  }

  addSubgroupToDraft(): void {
    const selectedCandidates = this.selectedSafeSubgroupCandidates;
    if (!selectedCandidates.length || !this.activeGroup) {
      this.messages.add({
        severity: 'warn',
        summary: 'Choose subgroups',
        detail: 'Select one or more safe subgroups before adding them to the group draft.'
      });
      return;
    }
    const targetMembers = this.currentGroupMemberList();
    const existingIds = new Set(targetMembers.filter((member) => member.status !== 'Draft remove').map((member) => member.id));
    const addableCandidates = selectedCandidates.filter((candidate) => !existingIds.has(candidate.id));

    if (!addableCandidates.length) {
      this.messages.add({
        severity: 'warn',
        summary: 'Already nested',
        detail: 'The selected subgroups are already referenced by this group.'
      });
      return;
    }

    for (const candidate of addableCandidates) {
      targetMembers.push({
        name: candidate.name,
        id: candidate.id,
        effective: this.groupDefaultEffectiveDate,
        status: 'Draft add',
        kind: 'Subgroup',
        children: [
          { name: 'Candidate member 1', cas: '117-84-0', ec: '204-214-7' },
          { name: 'Candidate member 2', cas: '28553-12-0', ec: '249-079-5' }
        ]
      });
    }
    this.syncActiveGroupDraftState();
    this.subgroupCheckDialogVisible = false;
    this.selectedSubgroupIds = [];
    this.addConnectedChange(
      'Subgroups staged in draft',
      `${addableCandidates.length} subgroup${addableCandidates.length === 1 ? '' : 's'} nested by reference after circular-reference checks passed.`,
      'warn',
      'pi pi-sitemap'
    );
    this.messages.add({
      severity: 'success',
      summary: `${addableCandidates.length} subgroup${addableCandidates.length === 1 ? '' : 's'} added to draft`,
      detail: 'Subgroups remain draft-only until the group version is activated.'
    });
  }

  removeGroupMember(member: GroupMember, event?: Event): void {
    event?.stopPropagation();
    const targetMembers = this.currentGroupMemberList();
    const index = targetMembers.indexOf(member);
    if (index < 0) {
      return;
    }
    if (member.status === 'Draft add') {
      targetMembers.splice(index, 1);
    } else {
      member.status = 'Draft remove';
    }
    this.syncActiveGroupDraftState();
    this.addConnectedChange(
      'Group member removal staged',
      `${member.name} removal is staged as a draft change. Active DSLs remain unchanged until activation impact is reviewed.`,
      'warn',
      'pi pi-trash'
    );
    this.messages.add({
      severity: 'warn',
      summary: 'Removal staged',
      detail: 'This removal is draft-only until the group update is activated.'
    });
  }

  toggleGroupDslReference(reference: GroupDslReference): void {
    reference.decision = reference.decision === 'Receives draft version'
      ? 'Keeps current version'
      : 'Receives draft version';
  }

  discardGroupDraft(): void {
    const groupName = this.activeGroup?.name || 'This group';
    this.currentGroupMemberList()
      .filter((member) => member.status === 'Draft remove')
      .forEach((member) => {
        member.status = 'Active';
      });
    if (this.activeGroup?.id.startsWith('GRP-DRAFT')) {
      const index = this.groups.indexOf(this.activeGroup);
      if (index >= 0) {
        this.groups.splice(index, 1);
      }
      this.activeGroup = undefined;
    } else if (this.activeGroup) {
      this.activeGroup.status = 'Active';
      this.activeGroup.signal = undefined;
      this.activeGroup.modified = 'Just now';
    }
    this.addConnectedChange(
      'Group draft discarded',
      `${groupName} draft changes were discarded in the prototype. Active group history is unchanged.`,
      'info',
      'pi pi-trash'
    );
    this.messages.add({
      severity: 'info',
      summary: 'Draft discarded',
      detail: 'The active group version remains unchanged.'
    });
  }

  createContextualExport(page: PageKey, label = 'Review export'): void {
    if (page === 'lists' && this.activeDslList) {
      this.createDslReviewExport(label);
      return;
    }
    const copy = this.pageCopy[page];
    this.downloadJobs.unshift({
      name: `${copy.title} ${label}`,
      scope: 'Complete contents, references, source notes, and action-log context',
      format: page === 'modules' ? 'HTML + XLSX' : 'XLSX',
      status: 'Ready',
      surface: page,
      fileId: this.createExportFileId(page),
      downloadedAt: this.formattedDownloadTimestamp(),
      parentName: copy.title,
      includedFields: this.defaultExportFields(page),
      lockState: 'Unlocked'
    });
    this.addConnectedChange(
      `${copy.title} export prepared`,
      `${copy.title} export is ready from the ${copy.title.toLowerCase()} page with full review context.`,
      'success',
      'pi pi-download'
    );
    this.messages.add({
      severity: 'success',
      summary: 'Export ready',
      detail: `${copy.title} export was prepared here, without leaving the workflow.`
    });
  }

  createDslReviewExport(label = 'download for review'): void {
    if (!this.activeDslList) {
      this.createContextualExport('lists', label);
      return;
    }
    const existingLock = this.activeDslReviewLock;
    if (existingLock) {
      this.messages.add({
        severity: 'warn',
        summary: 'Review lock active',
        detail: `${existingLock.fileId} must be committed or released before another review download is created.`
      });
      return;
    }
    const list = this.activeDslList;
    const fileId = this.createExportFileId('lists');
    const job: ExportJob = {
      name: `${list.name} ${label}`,
      scope: `${list.substances.toLocaleString()} substances, ${list.groups} groups/subgroups, ${list.exemptionSets} exemption set${list.exemptionSets === 1 ? '' : 's'}`,
      format: 'XLSX',
      status: 'Locked',
      surface: 'lists',
      fileId,
      downloadedAt: this.formattedDownloadTimestamp(),
      parentId: list.id,
      parentName: list.name,
      recordCount: this.dslReviewExportRecordCount(list),
      includedFields: this.defaultExportFields('lists'),
      lockState: 'Locked',
      lockOwner: 'You'
    };
    this.downloadJobs.unshift(job);
    this.addConnectedChange(
      'DSL review download locked',
      `${fileId} includes ${job.recordCount}. Online edits to ${list.name} are locked until the reviewed file is committed or released.`,
      'warn',
      'pi pi-lock'
    );
    this.messages.add({
      severity: 'success',
      summary: 'Review download ready',
      detail: `${list.name} is locked for online edits until ${fileId} is committed or released.`
    });
  }

  commitActiveDslReviewFile(): void {
    const lock = this.activeDslReviewLock;
    if (!lock || !this.activeDslList) {
      return;
    }
    lock.status = 'Committed';
    lock.lockState = 'Committed';
    this.activeDslList.modified = 'Just now';
    this.addConnectedChange(
      'Reviewed file committed',
      `${lock.fileId} was committed back to ${this.activeDslList.name}. Online edits are unlocked and the file ID remains in the activity trail.`,
      'success',
      'pi pi-check-circle'
    );
    this.messages.add({
      severity: 'success',
      summary: 'Review file committed',
      detail: `${this.activeDslList.name} is unlocked for online changes.`
    });
  }

  releaseActiveDslReviewLock(): void {
    const lock = this.activeDslReviewLock;
    if (!lock || !this.activeDslList) {
      return;
    }
    lock.status = 'Released';
    lock.lockState = 'Released';
    this.addConnectedChange(
      'Review lock released',
      `${lock.fileId} was released without committing reviewed-file changes. ${this.activeDslList.name} can be edited online again.`,
      'info',
      'pi pi-unlock'
    );
    this.messages.add({
      severity: 'info',
      summary: 'Review lock released',
      detail: `${this.activeDslList.name} can be edited online again.`
    });
  }

  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  openArchiveDialog(substance = this.activeSubstance): void {
    this.activeSubstance = substance;
    this.archiveDialogVisible = true;
  }

  openPublishDialog(): void {
    this.publishDialogVisible = true;
  }

  openBulkDialog(): void {
    this.setPage('bulk');
  }

  openEditor(substance = this.activeSubstance): void {
    this.activeSubstance = substance;
    this.editorMode = 'edit';
    this.drawerTab = 'parameters';
    this.drawerContext = undefined;
    this.editorDraft = this.cloneSubstance(substance);
    this.editorRationale = '';
    this.editDrawerVisible = true;
  }

  openCreateSubstance(): void {
    this.editorMode = 'create';
    this.drawerTab = 'parameters';
    this.drawerContext = undefined;
    this.editorDraft = {
      id: this.nextSubstanceId(),
      name: '',
      cas: '',
      ec: '',
      authority: 'ECHA',
      aliases: 0,
      aliasNames: '',
      alternativeIds: '',
      source: 'Assent',
      created: 'Draft',
      status: 'Active',
      apiStatus: 'Pending validation',
      modified: 'Draft',
      references: { lists: 0, groups: 0, materials: 0 }
    };
    this.editorRationale = '';
    this.editDrawerVisible = true;
  }

  focusSubstance(substance: Substance): void {
    this.activeSubstance = substance;
  }

  openSubstanceDrawer(substance: Substance, tab: DrawerTab = 'overview', context?: DrawerContext): void {
    if (this.isSubstanceLoading) {
      return;
    }

    this.activeSubstance = substance;
    this.editorMode = 'edit';
    this.drawerTab = tab;
    this.drawerContext = context;
    this.activityQuery = '';
    this.activityStatus = 'All';
    this.editorDraft = this.cloneSubstance(substance);
    this.editorRationale = '';
    this.editDrawerVisible = true;
  }

  openGroupMemberDrawer(member: GroupMember): void {
    if (member.kind !== 'Substance') {
      return;
    }

    const substance = this.substances.find((item) => item.id === member.id || item.cas === member.cas);
    if (!substance) {
      this.messages.add({
        severity: 'warn',
        summary: 'Record not indexed',
        detail: 'This group member would be loaded from the substance service in the full app.'
      });
      return;
    }

    this.openSubstanceDrawer(substance, 'overview', {
      groupName: this.activeGroup?.name || 'Current group',
      groupId: this.activeGroup?.id || '',
      memberStatus: member.status,
      effective: member.effective,
      threshold: member.threshold || 'Inherited'
    });
  }

  clearSubstanceGrid(table: Table): void {
    this.substanceQuery = '';
    this.selectedSubstances = [];
    this.substanceReviewFilter = 'all';
    this.substanceServiceQuery = '';
    this.substanceServerResults = [];
    table.clear();
  }

  openSubstanceReviewQueue(): void {
    this.substanceQuery = '';
    this.substanceServiceQuery = '';
    this.substanceServerResults = [];
    this.setSubstanceReviewFilter('needs-review');
  }

  setSubstanceReviewFilter(filter: SubstanceReviewFilter): void {
    this.substanceReviewFilter = filter;
    this.selectedSubstances = [];
  }

  onSubstanceQueryChange(): void {
    if (this.activePage !== 'substances') {
      return;
    }

    this.selectedSubstances = [];
    const query = this.normalizeQuery(this.substanceQuery);

    if (!this.hasLoadedSubstanceIndex) {
      this.ensureSubstanceIndexLoaded();
      return;
    }

    if (!query || query.length < 3) {
      this.clearSubstanceLoadTimer();
      this.isSubstanceLoading = false;
      this.substanceServiceQuery = '';
      this.substanceServerResults = [];
      return;
    }

    if (this.findIndexedSubstanceMatches(query).length) {
      this.clearSubstanceLoadTimer();
      this.isSubstanceLoading = false;
      this.substanceServiceQuery = '';
      this.substanceServerResults = [];
      return;
    }

    if (this.substanceServiceQuery === query) {
      return;
    }

    this.loadSubstanceServiceSearch(query);
  }

  ensureSubstanceIndexLoaded(): void {
    if (this.hasLoadedSubstanceIndex) {
      return;
    }

    this.simulateSubstanceServerLoad('initial', 640, () => {
      this.hasLoadedSubstanceIndex = true;
    });
  }

  loadSubstanceServiceSearch(query: string): void {
    this.simulateSubstanceServerLoad('server-search', 720, () => {
      this.substanceServiceQuery = query;
      this.substanceServerResults = this.createSubstanceServiceResults(query);
    });
  }

  simulateSubstanceServerLoad(
    mode: 'initial' | 'server-search' = 'initial',
    duration = 520,
    complete?: () => void
  ): void {
    this.clearSubstanceLoadTimer();
    this.substanceLoadMode = mode;
    this.isSubstanceLoading = true;
    this.substanceLoadTimer = setTimeout(() => {
      complete?.();
      this.isSubstanceLoading = false;
      this.substanceLoadTimer = undefined;
    }, duration);
  }

  saveSubstanceDraft(): void {
    const draft = this.cloneSubstance(this.editorDraft);
    draft.name = draft.name.trim();
    draft.cas = draft.cas.trim();
    draft.ec = draft.ec.trim();
    draft.authority = draft.authority.trim() || 'ECHA';
    draft.aliasNames = draft.aliasNames.trim();
    draft.alternativeIds = draft.alternativeIds.trim();
    draft.source = draft.source.trim() || 'Assent';
    draft.created = draft.created.trim() || 'Draft';
    draft.apiStatus = draft.apiStatus || this.defaultApiStatus(draft);
    draft.modified = 'Just now';

    if (!draft.name || !draft.cas) {
      this.messages.add({
        severity: 'warn',
        summary: 'Required fields',
        detail: 'Substance name and CAS number are needed before saving.'
      });
      return;
    }

    if (this.editorMode === 'create') {
      this.substances.unshift(draft);
      this.activeSubstance = draft;
      this.selectedSubstances = [];
      this.addConnectedChange(
        'New substance draft created',
        `${draft.name} was added to the governed library and is ready for dependency assignment.`,
        'info',
        'pi pi-plus-circle'
      );
      this.messages.add({
        severity: 'success',
        summary: 'Substance created',
        detail: `${draft.name} is now in the master library.`
      });
    } else {
      const target = this.substances.find((substance) => substance.id === draft.id);
      if (target) {
        Object.assign(target, draft);
        this.activeSubstance = target;
      }
      this.addConnectedChange(
        'Substance draft updated',
        `${draft.name} now has updated identifiers, authority, and rationale attached.`,
        'info',
        'pi pi-pencil'
      );
      this.messages.add({
        severity: 'success',
        summary: 'Draft saved',
        detail: `${draft.name} changes are tracked for review.`
      });
    }

    this.editDrawerVisible = false;
  }

  applyBulkAction(action: BulkSubstanceAction): void {
    if (!this.selectedSubstanceCount) {
      this.messages.add({
        severity: 'warn',
        summary: 'Nothing selected',
        detail: 'Select one or more substances first.'
      });
      return;
    }

    const selected = [...this.selectedSubstances];
    if (action === 'export') {
      this.downloadJobs.unshift({
        name: 'Selected substance review pack',
        scope: `${selected.length} substances with references and audit context`,
        format: 'XLSX',
        status: 'Ready',
        surface: 'substances',
        fileId: this.createExportFileId('substances'),
        downloadedAt: this.formattedDownloadTimestamp(),
        parentName: 'Substances',
        includedFields: this.defaultExportFields('substances'),
        lockState: 'Unlocked'
      });
      this.addConnectedChange(
        'Review export prepared',
        `${selected.length} selected substances are ready to export with dependency context.`,
        'success',
        'pi pi-download'
      );
      this.messages.add({ severity: 'success', summary: 'Export ready', detail: 'The review pack is attached to Substances.' });
      return;
    }

    if (action === 'stage') {
      selected.forEach((substance) => {
        substance.status = 'Staged';
        substance.modified = 'Just now';
      });
      this.addConnectedChange(
        'Bulk staging updated',
        `${selected.length} substances moved into staged review before activation.`,
        'warn',
        'pi pi-inbox'
      );
      this.messages.add({ severity: 'success', summary: 'Moved to staged review', detail: `${selected.length} substances updated.` });
      return;
    }

    const blocked = selected.filter((substance) => this.downstreamReferenceTotal(substance) > 0);
    const archivable = selected.filter((substance) => this.downstreamReferenceTotal(substance) === 0);
    archivable.forEach((substance) => {
      substance.status = 'Archived';
      substance.modified = 'Just now';
    });

    this.addConnectedChange(
      blocked.length ? 'Bulk archive review created' : 'Bulk archive completed',
      blocked.length
        ? `${blocked.length} selected substances need dependency reassignment; ${archivable.length} were archived.`
        : `${archivable.length} selected substances were archived and logged.`,
      blocked.length ? 'warn' : 'success',
      'pi pi-archive'
    );
    this.selectedSubstances = blocked;
    this.messages.add({
      severity: blocked.length ? 'warn' : 'success',
      summary: blocked.length ? 'Archive review needed' : 'Archived',
      detail: blocked.length ? 'Referenced records stayed selected for review.' : 'Selected records were archived.'
    });
  }

  archiveActiveSubstance(): void {
    if (this.downstreamReferenceTotal(this.activeSubstance) > 0) {
      this.createArchiveTask();
      return;
    }

    this.activeSubstance.status = 'Archived';
    this.activeSubstance.modified = 'Just now';
    this.selectedSubstances = this.selectedSubstances.filter((substance) => substance.id !== this.activeSubstance.id);
    this.archiveDialogVisible = false;
    this.addConnectedChange(
      'Substance archived',
      `${this.activeSubstance.name} was archived with no downstream references remaining.`,
      'success',
      'pi pi-archive'
    );
    this.messages.add({ severity: 'success', summary: 'Archived', detail: `${this.activeSubstance.name} was archived.` });
  }

  createArchiveTask(): void {
    this.archiveDialogVisible = false;
    this.addConnectedChange(
      'Archive cleanup task created',
      `${this.activeSubstance.name} stays active while attached references are cleared or reassigned.`,
      'warn',
      'pi pi-shield'
    );
    this.messages.add({
      severity: 'warn',
      summary: 'Cleanup task created',
      detail: 'The substance stays active until references are cleared.'
    });
  }

  approveStaged(item: StagedSubstance): void {
    this.openStagedReview(item.stagedSubstanceId);
  }

	  publish(): void {
	    this.publishDialogVisible = false;
	    this.messages.add({
	      severity: 'success',
	      summary: 'Deployment queued',
	      detail: 'REACH SVHC Module is moving through UAT with lifecycle impact attached.'
	    });
	    this.activePage = 'publish';
	  }

	  createNewModule(): void {
	    const draftModule: ModuleRecord = {
	      id: `MOD-DRAFT-${String(this.modules.length + 1).padStart(3, '0')}`,
	      name: 'New DSL module',
	      description: 'Select an active DSL list, add required support resources, and finalize the package when it is ready.',
	      list: 'Select a DSL list',
	      listId: 'Not selected',
	      created: 'Today',
	      version: 'Draft v1.0',
	      versionNote: 'New module draft. Add a primary DSL list and support resources before finalization.',
	      owner: 'Regulatory',
	      groups: 0,
	      exemptionSets: 0,
	      resources: [
	        { name: 'Customer preview bundle', type: 'HTML', status: 'Missing', detail: 'Generated after the primary DSL list is selected.' }
	      ],
	      customers: 0,
	      checks: 25,
	      status: 'Draft',
	      impact: 'Primary DSL list required',
	      modified: 'Just now'
	    };
	    this.modules.unshift(draftModule);
	    this.openModuleDetail(draftModule);
	    this.messages.add({
	      severity: 'success',
	      summary: 'Module draft created',
	      detail: 'Select a primary DSL list, attach resources, then finalize when checks pass.'
	    });
	  }

	  saveModuleDetails(): void {
	    if (!this.activeModule) {
	      return;
	    }
	    this.activeModule.name = this.activeModule.name.trim() || 'New DSL module';
	    this.activeModule.description = this.activeModule.description.trim() || 'Description required before finalization.';
	    this.activeModule.owner = this.activeModule.owner.trim() || 'Regulatory';
	    this.activeModule.versionNote = this.activeModule.versionNote.trim() || 'Version note required before finalization.';
	    this.activeModule.status = this.activeModule.status === 'Blocked' ? 'Blocked' : 'Draft';
	    this.activeModule.modified = 'Just now';
	    this.messages.add({
	      severity: 'success',
	      summary: 'Module details saved',
	      detail: `${this.activeModule.name} stayed in draft while readiness checks are reviewed.`
	    });
	  }

	  selectModulePrimaryList(list: DslList): void {
	    if (!this.activeModule) {
	      return;
	    }
	    this.activeModule.list = list.name;
	    this.activeModule.listId = list.id;
	    this.activeModule.groups = list.groups;
	    this.activeModule.exemptionSets = list.exemptionSets;
	    this.activeModule.status = 'Draft';
	    this.activeModule.checks = Math.max(this.activeModule.checks, list.status === 'Active' ? 72 : 58);
	    this.activeModule.impact = list.status === 'Active'
	      ? 'Primary DSL list selected'
	      : 'Draft DSL list selected; activation required first';
	    this.activeModule.modified = 'Just now';
	    this.messages.add({
	      severity: list.status === 'Active' ? 'success' : 'warn',
	      summary: 'Primary DSL list selected',
	      detail: `${list.name} is now the module source list.`
	    });
	  }

	  resolveModuleResource(resource: ModuleResource): void {
	    if (!this.activeModule) {
	      return;
	    }
	    resource.status = 'Ready';
	    resource.detail = 'Resource attached and checked for the module package.';
	    this.activeModule.status = 'Draft';
	    this.activeModule.checks = Math.min(95, this.activeModule.checks + 15);
	    this.activeModule.impact = 'Resources ready for finalization review';
	    this.activeModule.modified = 'Just now';
	    this.messages.add({
	      severity: 'success',
	      summary: 'Resource attached',
	      detail: `${resource.name} is ready for the module package.`
	    });
	  }

	  addModuleResource(): void {
	    if (!this.activeModule) {
	      return;
	    }
	    this.activeModule.resources.push({
	      name: 'Customer support note',
	      type: 'Copy deck',
	      status: 'Ready',
	      detail: 'Support note added to the module package.'
	    });
	    this.activeModule.status = 'Draft';
	    this.activeModule.checks = Math.min(95, this.activeModule.checks + 8);
	    this.activeModule.modified = 'Just now';
	    this.messages.add({
	      severity: 'success',
	      summary: 'Resource added',
	      detail: 'The support note was attached to the module draft.'
	    });
	  }

	  finalizeActiveModule(): void {
	    if (!this.activeModule) {
	      return;
	    }
	    const blockingChecks = this.activeModuleReadinessChecks.filter((check) => check.status !== 'Ready');
	    if (blockingChecks.length) {
	      this.moduleDetailTab = 'readiness';
	      this.messages.add({
	        severity: 'warn',
	        summary: 'Finish readiness checks first',
	        detail: `${blockingChecks.length} item${blockingChecks.length === 1 ? '' : 's'} must be resolved before the module can be Ready.`
	      });
	      return;
	    }
	    this.activeModule.status = 'Ready';
	    this.activeModule.checks = 100;
	    this.activeModule.impact = 'Ready for deployment queue';
	    this.activeModule.modified = 'Just now';
	    this.actionLog.unshift({
	      title: `${this.activeModule.name} finalized`,
	      body: 'Module package is complete, validated, and ready for downstream consumption.',
	      time: 'Just now',
	      icon: 'pi pi-check-circle',
	      severity: 'success'
	    });
	    this.messages.add({
	      severity: 'success',
	      summary: 'Module ready',
	      detail: `${this.activeModule.name} is Ready. Deployment review is now the next step.`
	    });
	  }

	  publishActiveModule(): void {
	    if (!this.activeModule) {
	      return;
	    }
	    if (this.activeModule.status !== 'Ready') {
	      this.moduleDetailTab = 'readiness';
	      this.messages.add({
	        severity: 'warn',
	        summary: 'Finalize first',
	        detail: 'The module must be Ready before it can move to deployment review.'
	      });
	      return;
	    }
	    const moduleName = this.activeModule.name;
	    this.setPage('publish');
	    this.messages.add({
	      severity: 'success',
	      summary: 'Module sent to deployment review',
	      detail: `${moduleName} is ready to publish through the deployment queue.`
	    });
	  }

  downstreamReferenceTotal(substance: Substance): number {
    return substance.references.lists + substance.references.groups + substance.references.materials;
  }

  visibleDependencyExamples(total: number, examples: string[]): string[] {
    return examples.slice(0, Math.min(total, examples.length));
  }

  remainingDependencyCount(total: number, visibleCount: number): number {
    return Math.max(total - visibleCount, 0);
  }

  materialDependencySummary(substance: Substance): { label: string; value: string }[] {
    const materialCount = substance.references.materials;
    const activeCustomerFacing = Math.round(materialCount * 0.43);
    const recentlyUpdated = Math.max(0, Math.round(materialCount * 0.07));
    const consumingModules = Math.max(1, Math.ceil((substance.references.lists + substance.references.groups) / 4));

    return [
      { label: 'Total material references', value: materialCount.toLocaleString() },
      { label: 'Active customer-facing', value: activeCustomerFacing.toLocaleString() },
      { label: 'Recently updated', value: recentlyUpdated.toLocaleString() },
      { label: 'Consuming modules', value: consumingModules.toLocaleString() }
    ];
  }

  dependencyImpactMessage(substance: Substance): string {
    const total = this.downstreamReferenceTotal(substance);
    if (total === 0) {
      return 'No active references are attached. Archive or status changes can move forward after the usual validation checks.';
    }
    if (substance.references.materials >= 300) {
      return 'Large downstream footprint. Review the impact summary before archive, status, API availability, or identifier changes.';
    }
    return 'Review attached lists, groups, and material references before changing status, identifiers, or API availability.';
  }

  impactLevel(substance: Substance): 'Low' | 'Medium' | 'High' {
    const total = this.downstreamReferenceTotal(substance);
    if (total > 500) {
      return 'High';
    }
    if (total > 0) {
      return 'Medium';
    }
    return 'Low';
  }

  impactSeverity(substance: Substance): Severity {
    const level = this.impactLevel(substance);
    if (level === 'High') {
      return 'danger';
    }
    if (level === 'Medium') {
      return 'warn';
    }
    return 'success';
  }

  confidenceValue(record: StagedSubstance): number {
    if (record.dataConfidence === 'High') {
      return Math.max(record.completenessScore, 88);
    }
    if (record.dataConfidence === 'Medium') {
      return Math.min(Math.max(record.completenessScore, 58), 78);
    }
    return Math.min(record.completenessScore, 48);
  }

  confidenceSeverity(confidence: DataConfidence): Severity {
    if (confidence === 'High') {
      return 'success';
    }
    if (confidence === 'Medium') {
      return 'warn';
    }
    return 'danger';
  }

  stagingMatchSeverity(status: MatchStatus): Severity {
    if (status === 'Match Found') {
      return 'success';
    }
    if (status === 'Potential Match' || status === 'Needs Review') {
      return 'warn';
    }
    if (status === 'Duplicate Risk') {
      return 'danger';
    }
    return 'info';
  }

  stagingStatusSeverity(status: StagingStatus): Severity {
    if (status === 'Approved') {
      return 'success';
    }
    if (status === 'Rejected') {
      return 'danger';
    }
    if (status === 'Pending Investigation' || status === 'In Review') {
      return 'warn';
    }
    return 'info';
  }

  sourceTypeSeverity(sourceType: SourceType): Severity {
    if (sourceType === 'Supplier input') {
      return 'warn';
    }
    if (sourceType === 'Third-party integration') {
      return 'secondary';
    }
    return 'info';
  }

  notificationSeverity(status: NotificationStatus): Severity {
    if (status === 'Sent') {
      return 'success';
    }
    if (status === 'Queued' || status === 'Required') {
      return 'warn';
    }
    return 'secondary';
  }

  signoffSeverity(status: SignoffStatus): Severity {
    if (status === 'Approved') {
      return 'success';
    }
    if (status === 'Required' || status === 'Requested') {
      return 'warn';
    }
    return 'secondary';
  }

  validateCas(cas: string): boolean {
    const trimmed = cas.trim();
    if (!trimmed) {
      return true;
    }
    if (!/^\d{2,7}-\d{2}-\d$/.test(trimmed)) {
      return false;
    }
    const [prefix, middle, checkDigit] = trimmed.split('-');
    const digits = `${prefix}${middle}`.split('').reverse().map((digit) => Number(digit));
    const sum = digits.reduce((total, digit, index) => total + digit * (index + 1), 0);
    return sum % 10 === Number(checkDigit);
  }

  validateEc(ec: string): boolean {
    const trimmed = ec.trim();
    return !trimmed || /^\d{3}-\d{3}-\d$/.test(trimmed);
  }

  runExistenceCheck(stagedSubstance: StagedSubstance): ExistenceCheckRow[] {
    const normalizedName = this.normalizeQuery(stagedSubstance.substanceName);
    const normalizedAliases = stagedSubstance.aliases.map((alias) => this.normalizeQuery(alias));
    const candidatePool = this.matchCandidates.filter((candidate) => candidate.stagedSubstanceId === stagedSubstance.stagedSubstanceId);
    const casMatch = Boolean(stagedSubstance.CAS) && (
      this.substances.some((substance) => substance.cas === stagedSubstance.CAS) ||
      candidatePool.some((candidate) => candidate.CAS === stagedSubstance.CAS)
    );
    const ecMatch = Boolean(stagedSubstance.EC) && (
      this.substances.some((substance) => substance.ec === stagedSubstance.EC) ||
      candidatePool.some((candidate) => candidate.EC === stagedSubstance.EC)
    );
    const aliasMatch = this.substances.some((substance) => {
      const names = [substance.name, substance.aliasNames].map((value) => this.normalizeQuery(value));
      return names.some((name) => name && (name.includes(normalizedName) || normalizedAliases.some((alias) => alias && name.includes(alias))));
    }) || candidatePool.some((candidate) => {
      const names = [candidate.substanceName, ...candidate.aliases].map((value) => this.normalizeQuery(value));
      return names.some((name) => name && (name.includes(normalizedName) || normalizedAliases.some((alias) => alias && name.includes(alias))));
    });

    return [
      {
        label: 'Exact CAS match',
        state: casMatch ? 'Found' : stagedSubstance.CAS && !this.validateCas(stagedSubstance.CAS) ? 'Warning' : 'Not found',
        detail: casMatch ? 'A Substance Library record already has this CAS. Link existing or add alias instead of creating a duplicate.' : stagedSubstance.CAS && !this.validateCas(stagedSubstance.CAS) ? 'CAS format/check digit failed.' : 'No exact CAS match was found.',
        severity: casMatch || (stagedSubstance.CAS && !this.validateCas(stagedSubstance.CAS)) ? 'danger' : 'success'
      },
      {
        label: 'Exact EC match',
        state: ecMatch ? 'Found' : stagedSubstance.EC && !this.validateEc(stagedSubstance.EC) ? 'Warning' : 'Not found',
        detail: ecMatch ? 'A Substance Library record already has this EC number.' : stagedSubstance.EC && !this.validateEc(stagedSubstance.EC) ? 'EC format failed.' : 'No exact EC match was found.',
        severity: ecMatch || (stagedSubstance.EC && !this.validateEc(stagedSubstance.EC)) ? 'danger' : 'success'
      },
      {
        label: 'Alias/name similarity',
        state: aliasMatch ? 'Warning' : 'Not found',
        detail: aliasMatch ? 'A similar name or alias exists. Review candidate comparison before creating a new record.' : 'No duplicate name or alias similarity was detected.',
        severity: aliasMatch ? 'warn' : 'success'
      },
      {
        label: 'No duplicate found',
        state: !casMatch && !ecMatch && !aliasMatch ? 'Not found' : 'Warning',
        detail: !casMatch && !ecMatch && !aliasMatch ? 'The staged record is clear for create-new review.' : 'Resolve duplicate risk before creating a new authoritative substance.',
        severity: !casMatch && !ecMatch && !aliasMatch ? 'success' : 'warn'
      }
    ];
  }

  statusSeverity(status: string): Severity {
    if (['Active', 'Ready', 'Clean', 'Available', 'Committed', 'Published', 'Approved', 'Archive Approved', 'Match Found', 'Found', 'Sent'].includes(status)) {
      return 'success';
    }
    if (['Draft', 'Draft add', 'Draft edit', 'Draft remove', 'Draft saved', 'Current draft', 'Pending', 'Pending validation', 'Pending Investigation', 'Archive Requested', 'Impact Assessment Generating', 'Impact Assessment Generated', 'In Review', 'Ready for Review', 'Required', 'Requested', 'Queued', 'Potential Match', 'Needs Review', 'Expiring', 'Expiring soon', 'Staged', 'Needs review', 'Needs verification', 'Reviewing', 'Retry needed', 'Locked', 'Warning'].includes(status)) {
      return 'warn';
    }
	    if (['Blocked', 'Archived', 'Archive Cancelled', 'Missing', 'Expired', 'Rejected', 'Duplicate Risk'].includes(status)) {
	      return 'danger';
	    }
    return 'info';
  }

  recommendationSeverity(recommendation: string): Severity {
    if (recommendation === 'Link existing') {
      return 'success';
    }
    if (recommendation === 'Create new') {
      return 'info';
    }
    return 'warn';
  }

  comparisonStagedValue(field: string, staged: StagedSubstance): string {
    const values: Record<string, string> = {
      'Substance name': staged.substanceName,
      CAS: staged.CAS || 'Not provided',
      EC: staged.EC || 'Not provided',
      Aliases: staged.aliases.join(', ') || 'No aliases',
      'Source / Authority': `${staged.source} | ${staged.sourceType}`,
      'Match score': 'Source record',
      'Match reason': staged.matchStatus,
      'Match type': 'Incoming staged record',
      'Existing DSL usage count': 'Not authoritative yet',
      'Last updated': staged.dateReceived
    };
    return values[field] || '-';
  }

  comparisonCandidateValue(field: string, candidate: SubstanceLibraryCandidate | undefined): string {
    if (!candidate) {
      return '-';
    }
    const values: Record<string, string> = {
      'Substance name': candidate.substanceName,
      CAS: candidate.CAS || 'Not provided',
      EC: candidate.EC || 'Not provided',
      Aliases: candidate.aliases.join(', ') || 'No aliases',
      'Source / Authority': `${candidate.source} | ${candidate.authority}`,
      'Match score': `${candidate.matchScore}%`,
      'Match reason': candidate.matchReason,
      'Match type': candidate.matchType,
      'Existing DSL usage count': `${candidate.existingDslUsageCount}`,
      'Last updated': candidate.lastUpdated
    };
    return values[field] || '-';
  }

  groupQuickFilterCount(filter: GroupQuickFilter): number {
    return this.filterGroupsByQuick(this.groupScopeRows(), filter).length;
  }

  filterMatchesActiveGroup(filter: GroupQuickFilter): boolean {
    return this.groupFilter === filter;
  }

  substanceReviewFilterCount(filter: SubstanceReviewFilter): number {
    return this.filterSubstancesByReview(this.substances, filter).length;
  }

  filterMatchesActiveSubstanceReview(filter: SubstanceReviewFilter): boolean {
    return this.substanceReviewFilter === filter;
  }

  private defaultExportConfig(): ExportConfig {
    return {
      exportFormat: 'Excel',
      includeArchived: false,
      includeMetadata: true,
      includeHierarchyColumns: true,
      includeExportTimestamp: true,
      notes: '',
      confirmEmptyExport: false
    };
  }

  private createExportRequest(source: ExportSource, config: ExportConfig, estimate: ExportEstimate, status: ExportStatus): ExportRequest {
    const requestedDate = this.formattedWorkflowTimestamp();
    this.exportSequence += 1;
    return {
      exportRequestId: `EXREQ-20260701-${String(this.exportSequence).padStart(3, '0')}`,
      sourceId: source.sourceId,
      sourceType: source.sourceType,
      sourceName: source.sourceName,
      parentDSL: source.parentDSL,
      parentGroup: source.parentGroup,
      requestedBy: 'You',
      requestedDate,
      exportFormat: config.exportFormat,
      includeArchived: config.includeArchived,
      includeMetadata: config.includeMetadata,
      includeHierarchyColumns: config.includeHierarchyColumns,
      includeExportTimestamp: config.includeExportTimestamp,
      estimatedRows: estimate.rows,
      estimatedFileSize: estimate.fileSize,
      status,
      fileName: this.buildExportFileName(source, config.exportFormat),
      rowCount: estimate.rows,
      notes: config.notes
    };
  }

  private createExportFile(request: ExportRequest): ExportFile {
    const existingFile = this.exportFiles.find((file) => file.exportRequestId === request.exportRequestId);
    if (existingFile) {
      existingFile.status = request.status;
      existingFile.generatedDate = request.generatedDate || this.formattedWorkflowTimestamp();
      return existingFile;
    }
    const file: ExportFile = {
      exportFileId: `EXFILE-20260701-${String(this.exportFiles.length + 1).padStart(3, '0')}`,
      exportRequestId: request.exportRequestId,
      fileName: request.fileName,
      fileFormat: request.exportFormat,
      rowCount: request.rowCount,
      generatedDate: request.generatedDate || this.formattedWorkflowTimestamp(),
      downloadUrl: '#',
      status: request.status
    };
    this.exportFiles.unshift(file);
    return file;
  }

  private buildExportFileName(source: ExportSource, format: ExportFormat): string {
    const extension = format === 'Excel' ? 'xlsx' : 'csv';
    const safeName = source.sourceName.replace(/[^A-Za-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    return `${safeName}_export_2026_07_01.${extension}`;
  }

  private formattedWorkflowTimestamp(): string {
    return '2026-07-01 10:30';
  }

  private createExportFileId(page: PageKey): string {
    this.exportSequence += 1;
    const prefixByPage: Partial<Record<PageKey, string>> = {
      substances: 'SUB-REV',
      groups: 'GRP-REV',
      exemptions: 'EXM-REV',
      lists: 'DSL-REV',
      modules: 'MOD-REV',
      downloads: 'EXP-REV',
      bulk: 'BLK-REV',
      publish: 'DEP-REV',
      preview: 'PRV-REV',
      log: 'LOG-REV'
    };
    return `${prefixByPage[page] || 'EXP-REV'}-20260624-${String(this.exportSequence).padStart(3, '0')}`;
  }

  private formattedDownloadTimestamp(): string {
    const now = new Date();
    const date = new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: '2-digit',
      year: 'numeric'
    }).format(now);
    const time = new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    }).format(now);
    return `${date} ${time}`;
  }

  private defaultExportFields(page: PageKey): string {
    if (page === 'lists') {
      return 'Parent item, downloaded date, substance name, aliases, CAS #, EC #, effective date, internal/external notes';
    }
    if (page === 'groups') {
      return 'Parent group, subgroup path, substance name, aliases, CAS #, EC #, DSL references';
    }
    if (page === 'exemptions') {
      return 'Exemption set, code, threshold, applicability, expiry, attached DSLs';
    }
    if (page === 'substances') {
      return 'Name, aliases, CAS #, EC #, source, status, dependency counts';
    }
    if (page === 'modules') {
      return 'Module package, primary DSL list, resources, readiness checks, version note';
    }
    return 'Review context, downloaded date, source object, status, activity evidence';
  }

  private dslReviewExportRecordCount(list: DslList): string {
    return `${list.substances.toLocaleString()} substances + ${list.groups} groups/subgroups + ${list.exemptionSets} exemption set${list.exemptionSets === 1 ? '' : 's'}`;
  }

  private guardActiveDslReviewLock(action: string): boolean {
    const lock = this.activeDslReviewLock;
    if (!lock) {
      return false;
    }
    this.messages.add({
      severity: 'warn',
      summary: 'Review lock active',
      detail: `Commit or release ${lock.fileId} before you ${action}.`
    });
    return true;
  }

  private lastDslContentPageFirst(totalRecords: number): number {
    if (totalRecords <= this.dslContentRows) {
      return 0;
    }
    return Math.floor((totalRecords - 1) / this.dslContentRows) * this.dslContentRows;
  }

  private filterSubstancesByReview(rows: Substance[], filter: SubstanceReviewFilter): Substance[] {
    if (filter === 'all') {
      return rows;
    }

    return rows.filter((substance) => {
      if (filter === 'needs-review') {
        return Boolean(substance.reviewIssue);
      }
      if (filter === 'duplicates') {
        return substance.reviewIssue?.key === 'duplicate';
      }
      if (filter === 'check-digit') {
        return substance.reviewIssue?.key === 'cas-check' || substance.reviewIssue?.key === 'ec-check';
      }
      if (filter === 'alias-conflicts') {
        return substance.reviewIssue?.key === 'alias-conflict';
      }
      if (filter === 'staged') {
        return substance.reviewIssue?.key === 'staged';
      }
      return true;
    });
  }

  private groupScopeRows(): SubstanceGroup[] {
    return this.groups.filter((group) => group.status !== 'Closed subset');
  }

  private filterGroupsByQuick(rows: SubstanceGroup[], filter: GroupQuickFilter): SubstanceGroup[] {
    if (filter === 'all') {
      return rows;
    }

    return rows.filter((group) => {
      if (filter === 'drafts') {
        return group.status === 'Draft';
      }
      if (filter === 'active') {
        return group.status === 'Active';
      }
      if (filter === 'most-used') {
        return group.dslCount >= 12;
      }
      if (filter === 'largest') {
        return group.members >= 1000 || group.signal === 'Largest';
      }
      return true;
    });
  }

	  private filterDslLists(rows: DslList[], filter: DslListFilter): DslList[] {
	    if (filter === 'all') {
	      return rows;
	    }

    return rows.filter((list) => {
      if (filter === 'drafts') {
        return list.status === 'Draft';
      }
      if (filter === 'large') {
        return list.substances + list.groups >= 2500;
      }
      if (filter === 'custom') {
        return list.scope === 'Custom';
      }
	      return true;
	    });
	  }

	  private filterModules(rows: ModuleRecord[], filter: ModuleFilter): ModuleRecord[] {
	    if (filter === 'all') {
	      return rows;
	    }

	    return rows.filter((module) => {
	      if (filter === 'drafts') {
	        return module.status === 'Draft';
	      }
	      if (filter === 'ready') {
	        return module.status === 'Ready';
	      }
	      if (filter === 'blocked') {
	        return module.status === 'Blocked';
	      }
	      return true;
	    });
	  }

  private sortGroupsForFilter(rows: SubstanceGroup[]): SubstanceGroup[] {
    if (this.groupFilter === 'most-used') {
      return [...rows].sort((a, b) => b.dslCount - a.dslCount);
    }
    if (this.groupFilter === 'largest') {
      return [...rows].sort((a, b) => b.members - a.members);
    }
    return rows;
  }

  private filterExemptionSets(rows: ExemptionSet[], filter: ExemptionSetFilter): ExemptionSet[] {
    const filtered = filter === 'all'
      ? rows
      : rows.filter((set) => {
          if (filter === 'drafts') {
            return set.status === 'Draft' || set.version.startsWith('Draft');
          }
          if (filter === 'published') {
            return set.status === 'Published';
          }
          if (filter === 'expiry-risk') {
            return set.expiryWatchCount > 0 || set.status === 'Expiring soon' || set.status === 'Expired';
          }
          if (filter === 'warnings') {
            return this.exemptionWarningCountForSet(set) > 0;
          }
          if (filter === 'archived') {
            return set.status === 'Archived';
          }
          return true;
        });

    if (filter === 'expiry-risk') {
      return [...filtered].sort((left, right) => right.expiryWatchCount - left.expiryWatchCount);
    }
    if (filter === 'warnings') {
      return [...filtered].sort((left, right) => this.exemptionWarningCountForSet(right) - this.exemptionWarningCountForSet(left));
    }
    return filtered;
  }

  exemptionWarningCountForSet(set: ExemptionSet): number {
    const warnings = new Set<ExemptionWarningKey>(set.warnings);
    this.exemptionRecords
      .filter((exemption) => exemption.setCode === set.code)
      .forEach((exemption) => {
        this.collectExemptionWarningKeys(exemption).forEach((warning) => warnings.add(warning));
      });
    return warnings.size;
  }

  exemptionWarningLabel(warning: ExemptionWarningKey): string {
    const labels: Record<ExemptionWarningKey, string> = {
      'duplicate-code': 'Duplicate exemption code',
      'threshold-conflict': 'Threshold conflict',
      'missing-threshold': 'Missing threshold value',
      'missing-applicability': 'Missing applicability',
      'missing-expiry': 'Missing expiry date',
      expired: 'Expired exemption'
    };
    return labels[warning];
  }

  exemptionWarningSeverity(warning: ExemptionWarningKey): Severity {
    if (warning === 'expired' || warning === 'duplicate-code' || warning === 'threshold-conflict') {
      return 'danger';
    }
    return 'warn';
  }

  exemptionThresholdRange(exemption: ExemptionRecord): string {
    if (!exemption.thresholdMin && !exemption.thresholdMax) {
      return 'Threshold missing';
    }
    if (!exemption.thresholdMin || !exemption.thresholdMax) {
      return `${exemption.thresholdMin || 'Min missing'} to ${exemption.thresholdMax || 'Max missing'}`;
    }
    return `${exemption.thresholdMin} to ${exemption.thresholdMax}`;
  }

  exemptionApplicabilitySummary(exemption: ExemptionRecord): string {
    if (!exemption.applicability.length) {
      return 'No applicability selected';
    }
    const substanceCount = exemption.applicability.filter((record) => record.kind === 'Substance').length;
    const groupCount = exemption.applicability.filter((record) => record.kind === 'Group').length;
    const parts = [
      substanceCount ? `${substanceCount} substance${substanceCount === 1 ? '' : 's'}` : '',
      groupCount ? `${groupCount} group${groupCount === 1 ? '' : 's'}` : ''
    ].filter(Boolean);
    return parts.join(', ');
  }

  hasExemptionWarning(exemption: ExemptionRecord, warning: ExemptionWarningKey): boolean {
    return this.collectExemptionWarningKeys(exemption).includes(warning);
  }

  isExpiredDate(date: string): boolean {
    const parsed = this.parseDateOnly(date);
    if (!parsed) {
      return false;
    }
    return parsed.getTime() < new Date('2026-06-25T00:00:00').getTime();
  }

  isExpiringSoonDate(date: string): boolean {
    const parsed = this.parseDateOnly(date);
    if (!parsed) {
      return false;
    }
    const now = new Date('2026-06-25T00:00:00');
    const ninetyDays = 90 * 24 * 60 * 60 * 1000;
    const delta = parsed.getTime() - now.getTime();
    return delta >= 0 && delta <= ninetyDays;
  }

  collectExemptionWarningKeys(exemption: ExemptionRecord): ExemptionWarningKey[] {
    const warnings = new Set<ExemptionWarningKey>(exemption.warningKeys || []);
    const thresholdMin = this.parseThreshold(exemption.thresholdMin);
    const thresholdMax = this.parseThreshold(exemption.thresholdMax);

    if (!exemption.thresholdMin || !exemption.thresholdMax) {
      warnings.add('missing-threshold');
    }
    if (thresholdMin !== undefined && thresholdMax !== undefined && thresholdMin > thresholdMax) {
      warnings.add('threshold-conflict');
    }
    if (!exemption.applicability.length) {
      warnings.add('missing-applicability');
    }
    if (!exemption.expiryDate) {
      warnings.add('missing-expiry');
    }
    if (this.isExpiredDate(exemption.expiryDate) || exemption.status === 'Expired') {
      warnings.add('expired');
    }
    if (this.hasDuplicateExemptionCode(exemption)) {
      warnings.add('duplicate-code');
    }
    if (this.hasOverlappingExemptionThreshold(exemption)) {
      warnings.add('threshold-conflict');
    }
    return [...warnings];
  }

  private hasDuplicateExemptionCode(exemption: ExemptionRecord): boolean {
    const code = this.normalizeQuery(exemption.code);
    if (!code) {
      return false;
    }
    return this.exemptionRecords.some((candidate) =>
      candidate.id !== exemption.id &&
      candidate.setCode === exemption.setCode &&
      this.normalizeQuery(candidate.code) === code &&
      candidate.status !== 'Archived'
    );
  }

  private hasOverlappingExemptionThreshold(exemption: ExemptionRecord): boolean {
    const range = this.thresholdRange(exemption);
    if (!range || !exemption.applicability.length) {
      return false;
    }
    const applicabilityKeys = new Set(exemption.applicability.map((record) => `${record.kind}-${record.id}`));
    return this.exemptionRecords.some((candidate) => {
      if (candidate.id === exemption.id || candidate.setCode !== exemption.setCode || candidate.status === 'Archived') {
        return false;
      }
      const candidateRange = this.thresholdRange(candidate);
      if (!candidateRange) {
        return false;
      }
      const sharesApplicability = candidate.applicability.some((record) => applicabilityKeys.has(`${record.kind}-${record.id}`));
      return sharesApplicability && range.min <= candidateRange.max && candidateRange.min <= range.max;
    });
  }

  private isThresholdRangeInvalid(exemption: ExemptionRecord): boolean {
    const min = this.parseThreshold(exemption.thresholdMin);
    const max = this.parseThreshold(exemption.thresholdMax);
    return min !== undefined && max !== undefined && min > max;
  }

  private thresholdRange(exemption: ExemptionRecord): { min: number; max: number } | undefined {
    const min = this.parseThreshold(exemption.thresholdMin);
    const max = this.parseThreshold(exemption.thresholdMax);
    if (min === undefined || max === undefined) {
      return undefined;
    }
    return { min, max };
  }

  private parseThreshold(value: string): number | undefined {
    const normalized = value.replace('%', '').trim();
    if (!normalized) {
      return undefined;
    }
    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : undefined;
  }

  private parseDateOnly(value: string): Date | undefined {
    if (!value || value === 'Not published yet' || value === 'Draft') {
      return undefined;
    }
    const parsed = new Date(`${value}T00:00:00`);
    return Number.isNaN(parsed.getTime()) ? undefined : parsed;
  }

  private sortStagedSubstances(records: StagedSubstance[]): StagedSubstance[] {
    const sorted = [...records];
    if (this.stagingFilters.sort === 'Oldest first') {
      return sorted.sort((left, right) => this.stagingDateValue(left) - this.stagingDateValue(right));
    }
    if (this.stagingFilters.sort === 'Confidence high to low') {
      return sorted.sort((left, right) => this.confidenceRank(right.dataConfidence) - this.confidenceRank(left.dataConfidence));
    }
    if (this.stagingFilters.sort === 'Completeness low to high') {
      return sorted.sort((left, right) => left.completenessScore - right.completenessScore);
    }
    return sorted.sort((left, right) => this.stagingDateValue(right) - this.stagingDateValue(left));
  }

  private stagingDateValue(record: StagedSubstance): number {
    const parsed = new Date(`${record.dateReceived}T00:00:00`);
    return Number.isNaN(parsed.getTime()) ? 0 : parsed.getTime();
  }

  private confidenceRank(confidence: DataConfidence): number {
    const ranks: Record<DataConfidence, number> = {
      High: 3,
      Medium: 2,
      Low: 1
    };
    return ranks[confidence];
  }

  private formattedAuditTimestamp(): string {
    const now = new Date();
    const date = new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(now);
    const time = new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    }).format(now);
    return `${date} ${time}`;
  }

  private sortSubstancesForReview(rows: Substance[]): Substance[] {
    if (this.substanceReviewFilter === 'all') {
      return rows;
    }

    return [...rows].sort((left, right) => {
      const priorityDelta = (right.reviewIssue?.priority || 0) - (left.reviewIssue?.priority || 0);
      if (priorityDelta) {
        return priorityDelta;
      }
      return left.name.localeCompare(right.name);
    });
  }

  private cloneSubstance(substance: Substance): Substance {
    return {
      ...substance,
      reviewIssue: substance.reviewIssue ? { ...substance.reviewIssue } : undefined,
      references: { ...substance.references }
    };
  }

  private defaultSubstanceHistory(substance: Substance): SubstanceActivityRecord[] {
    return [
      {
        id: `TXN-${substance.id}-001`,
        date: '2026-05-25 09:10',
        status: 'Reviewed',
        type: 'Record review',
        summary: `${substance.name || 'Substance'} opened for governed review.`,
        rationale: 'The record needs traceability for source, identifiers, and downstream references before edits are saved.',
        source: substance.source || 'Assent master data',
        impact: `${this.downstreamReferenceTotal(substance)} downstream references visible before archive or activation.`,
        user: 'System'
      },
      {
        id: `TXN-${substance.id}-000`,
        date: substance.modified === 'Just now' ? 'Just now' : '2026-05-18 13:30',
        status: substance.status === 'Archived' ? 'Blocked' : 'Active',
        type: 'Master record state',
        summary: `Current ${substance.status.toLowerCase()} state captured for audit.`,
        rationale: 'Status, authority, source, and identifiers are the minimum defensible record state.',
        source: substance.authority || 'Authority pending',
        impact: substance.status === 'Archived'
          ? 'Historical declarations stay pinned to prior active state.'
          : 'Available to referenced DSL objects and product composition APIs.',
        user: 'Regulatory'
      }
    ];
  }

  private defaultGroupHistory(group: SubstanceGroup): SubstanceActivityRecord[] {
    const draftStatus = group.status === 'Draft' ? 'Draft saved' : 'Reviewed';
    return [
      {
        id: `GTXN-${group.id}-001`,
        date: group.modified === 'Just now' ? 'Just now' : '2026-05-22 09:20',
        status: draftStatus,
        type: 'Group review',
        summary: `${group.name} group record reviewed.`,
        rationale: 'Group metadata, member count, associated DSL count, and current version state were checked.',
        source: `${group.id} governed group record`,
        impact: group.status === 'Draft'
          ? 'Draft edits remain inactive until activation impact is approved.'
          : 'No draft change is currently waiting for activation.',
        user: 'Regulatory'
      },
      {
        id: `GTXN-${group.id}-000`,
        date: group.lastActivated,
        status: group.lastActivated === 'Not active yet' ? 'Draft saved' : 'Active',
        type: 'Active state',
        summary: group.lastActivated === 'Not active yet'
          ? 'No active group version exists yet.'
          : `${group.version} remains the current active group definition.`,
        rationale: group.lastActivated === 'Not active yet'
          ? 'The group can be drafted before any DSL list references it.'
          : 'Existing DSLs keep using this version until a new group version is approved for them.',
        source: 'Version history',
        impact: `${group.dslCount} associated DSL${group.dslCount === 1 ? '' : 's'} tracked for activation impact.`,
        user: 'System'
      }
    ];
  }

  private defaultExemptionSetHistory(set: ExemptionSet): SubstanceActivityRecord[] {
    return [
      {
        id: `EXTXN-${set.code}-002`,
        date: set.modified === 'Just now' ? 'Just now' : '2026-06-24 10:00',
        status: set.status === 'Published' ? 'Published' : set.status === 'Archived' ? 'Archived' : 'Draft saved',
        type: 'Exemption set review',
        summary: `${set.name} lifecycle and warnings reviewed.`,
        rationale: 'Exemption sets are reusable governed records with threshold, applicability, expiry, and DSL reference impact.',
        source: `${set.code} exemption set record`,
        impact: `${set.exemptions} exemption${set.exemptions === 1 ? '' : 's'}, ${set.dslReferenceCount} DSL reference${set.dslReferenceCount === 1 ? '' : 's'}, ${set.expiryWatchCount} expiry watch item${set.expiryWatchCount === 1 ? '' : 's'}.`,
        user: set.owner
      },
      {
        id: `EXTXN-${set.code}-001`,
        date: set.lastPublished,
        status: set.lastPublished === 'Not published yet' ? 'Draft saved' : 'Published',
        type: 'Version state',
        summary: `${set.lastPublishedVersion} is the last published exemption set version.`,
        rationale: set.versionNote,
        source: 'Version history',
        impact: set.lastPublished === 'Not published yet'
          ? 'No DSL can rely on this draft until it is published.'
          : 'Published version remains authoritative until a new draft is published.',
        user: set.publishedBy
      },
      {
        id: `EXTXN-${set.code}-000`,
        date: set.created,
        status: 'Draft saved',
        type: 'Exemption set created',
        summary: `${set.name} created as a reusable exemption set.`,
        rationale: 'Creation metadata is retained for audit and downstream DSL reference review.',
        source: 'DSL Builder',
        impact: 'Future DSL assignments reference this set rather than copying exemptions.',
        user: set.owner
      }
    ];
  }

	  private defaultDslHistory(list: DslList): SubstanceActivityRecord[] {
	    return [
      {
        id: `LTXN-${list.id}-002`,
        date: list.modified === 'Just now' ? 'Just now' : '2026-06-10 14:45',
        status: list.status === 'Active' ? 'Reviewed' : 'Draft saved',
        type: 'List content review',
        summary: `${list.name} contents reviewed by reference.`,
        rationale: 'Substances, groups, subgroups, and exemption sets keep effective dates and notes on the DSL membership record.',
        source: `${list.id} governed list record`,
        impact: `${list.substances.toLocaleString()} listed substances, ${list.groups} groups, and ${list.exemptionSets} exemption set${list.exemptionSets === 1 ? '' : 's'} are traceable.`,
        user: list.owner
      },
      {
        id: `LTXN-${list.id}-001`,
        date: list.effective,
        status: list.status,
        type: 'Version state',
        summary: `${list.version} is the current list version state.`,
        rationale: list.versionNote,
        source: list.authority,
        impact: `${list.modules} module${list.modules === 1 ? '' : 's'} consume this list; downstream module deployment is reviewed separately.`,
        user: 'System'
      },
      {
        id: `LTXN-${list.id}-000`,
        date: list.created,
        status: 'Active',
        type: 'List created',
        summary: `${list.name} created as a governed DSL list.`,
        rationale: 'Creation metadata is retained so historical declarations can resolve against prior list state.',
        source: 'DSL Builder',
        impact: 'Historical versions remain available for audit and compatibility checks.',
        user: 'Regulatory'
      }
	    ];
	  }

	  private defaultModuleHistory(module: ModuleRecord): SubstanceActivityRecord[] {
	    return [
	      {
	        id: `MTXN-${module.id}-003`,
	        date: module.modified === 'Just now' ? 'Just now' : '2026-06-10 15:20',
	        status: module.status === 'Ready' ? 'Ready' : module.status,
	        type: 'Module readiness',
	        summary: `${module.name} readiness reviewed.`,
	        rationale: 'Required module components were checked before the package could be marked Ready.',
	        source: `${module.id} module package`,
	        impact: module.impact,
	        user: module.owner
	      },
	      {
	        id: `MTXN-${module.id}-002`,
	        date: '2026-06-10 14:45',
	        status: module.listId === 'Not selected' ? 'Blocked' : 'Reviewed',
	        type: 'Primary DSL list',
	        summary: `${module.list} selected as the primary DSL list.`,
	        rationale: 'Modules package one primary DSL list and supporting resources as a reusable, licensable artifact for downstream consumption.',
	        source: module.listId,
	        impact: `${module.groups} group references and ${module.exemptionSets} exemption set references are included through the DSL list.`,
	        user: module.owner
	      },
	      {
	        id: `MTXN-${module.id}-001`,
	        date: module.created,
	        status: 'Draft saved',
	        type: 'Module created',
	        summary: `${module.name} created as a customer-facing module package.`,
	        rationale: module.versionNote,
	        source: 'DSL Builder',
	        impact: 'No downstream deployment occurs until the module is Ready and queued for deployment review.',
	        user: module.owner
	      }
	    ];
	  }

	  private moduleReadinessChecks(module: ModuleRecord): ModuleReadinessCheck[] {
	    const selectedList = this.dslLists.find((list) => list.id === module.listId);
	    const hasPrimaryList = module.listId !== 'Not selected';
	    const hasModuleIdentity = module.id.trim().length > 0 && module.name.trim().length > 0;
	    const resourcesReady = module.resources.length > 0 && module.resources.every((resource) => resource.status === 'Ready');
	    const noteComplete = module.versionNote.trim().length >= 20 && !module.versionNote.toLowerCase().includes('required');
	    const sourceIsActive = selectedList?.status === 'Active' || module.status === 'Ready';
	    const notBlocked = module.status !== 'Blocked';

	    return [
	      {
	        label: 'Reusable module identity',
	        status: hasModuleIdentity ? 'Ready' : 'Blocked',
	        detail: hasModuleIdentity
	          ? `${module.id} identifies the reusable, licensable package. Pricing and entitlement mechanics stay out of this workflow.`
	          : 'Add a module name and ID before this can become a reusable package.',
	        severity: hasModuleIdentity ? 'success' : 'danger'
	      },
	      {
	        label: 'Primary DSL list selected',
	        status: hasPrimaryList ? 'Ready' : 'Blocked',
	        detail: hasPrimaryList ? `${module.list} is the module source list.` : 'Choose the DSL list this module packages.',
	        severity: hasPrimaryList ? 'success' : 'danger'
	      },
	      {
	        label: 'Primary list is active',
	        status: sourceIsActive ? 'Ready' : 'Needs review',
	        detail: sourceIsActive ? 'The module can consume the active list state.' : 'The selected DSL list has draft changes. Activate the list before finalizing the module.',
	        severity: sourceIsActive ? 'success' : 'warn'
	      },
	      {
	        label: 'Supporting resources attached',
	        status: resourcesReady ? 'Ready' : 'Needs review',
	        detail: resourcesReady ? `${module.resources.length} support resource${module.resources.length === 1 ? '' : 's'} checked.` : 'Resolve missing or draft resources before marking the module Ready.',
	        severity: resourcesReady ? 'success' : 'warn'
	      },
	      {
	        label: 'Version note complete',
	        status: noteComplete ? 'Ready' : 'Needs review',
	        detail: noteComplete ? 'The note explains why this module version exists.' : 'Add a clear note for reviewers before finalization.',
	        severity: noteComplete ? 'success' : 'warn'
	      },
	      {
	        label: 'Ready for downstream consumption',
	        status: notBlocked ? 'Ready' : 'Blocked',
	        detail: notBlocked ? 'No blocking source-target issue is attached to this module.' : 'Resolve the blocker before this module can become Ready.',
	        severity: notBlocked ? 'success' : 'danger'
	      }
	    ];
	  }

  private resetDslEntryFields(): void {
    this.dslEntryEffectiveDate = this.activeDslList?.effective || '2026-06-23';
    this.dslEntryInclusion = 'Declarable when present above the reporting threshold.';
    this.dslEntryInternalNote = 'Confirm authority source before activation.';
    this.dslEntryExternalNote = 'Report this item when it is present or reasonably expected.';
  }

  private syncActiveDslDraftState(): void {
    if (!this.activeDslList) {
      return;
    }
    this.activeDslList.substances = this.activeDslContents.filter((item) => item.kind === 'Substance').length;
    this.activeDslList.groups = this.activeDslContents.filter((item) => item.kind === 'Group').length;
    this.activeDslList.exemptionSets = this.activeDslExemptionReferences.length;
    this.activeDslList.status = 'Draft';
    this.activeDslList.modified = 'Just now';
    if (!this.activeDslList.version.startsWith('Draft')) {
      this.activeDslList.version = `Draft ${this.activeDslList.version}`;
    }
  }

  private nextSubstanceId(): string {
    const highest = Math.max(
      ...this.substances.map((substance) => Number(substance.id.replace('MS-', '')) || 0)
    );
    return `MS-${String(highest + 1).padStart(7, '0')}`;
  }

  private addConnectedChange(title: string, body: string, severity: Severity, icon: string): void {
    this.lastChangeSummary = body;
    this.actionLog.unshift({ title, body, time: 'Just now', icon, severity });
    this.dslLists[0] = { ...this.dslLists[0], status: 'Draft' };
    this.modules[0] = { ...this.modules[0], status: 'Draft', checks: Math.min(this.modules[0].checks, 82), impact: body };
    this.sourceTargetChecks[0] = {
      ...this.sourceTargetChecks[0],
      state: 'Reviewing',
      detail: body,
      severity
    };
  }

  private currentGroupMemberList(): GroupMember[] {
    if (this.activeGroup?.id.startsWith('GRP-DRAFT')) {
      return this.groupDraftMembers;
    }
    return this.groupMembers;
  }

  private syncActiveGroupDraftState(): void {
    if (!this.activeGroup) {
      return;
    }
    const visibleMemberCount = this.currentGroupMemberList()
      .filter((member) => member.status !== 'Draft remove')
      .reduce((count, member) => count + (member.children?.length || 1), 0);
    this.activeGroup.members = visibleMemberCount;
    this.activeGroup.status = 'Draft';
    this.activeGroup.signal = this.activeGroup.signal || 'Draft v4.3';
    this.activeGroup.modified = 'Just now';
  }

  private syncActiveExemptionSetDraftState(): void {
    if (!this.activeExemptionSet) {
      return;
    }
    const visibleExemptions = this.activeExemptionSetExemptions.filter((exemption) => exemption.status !== 'Archived');
    this.activeExemptionSet.exemptions = visibleExemptions.length;
    this.activeExemptionSet.expiryWatchCount = visibleExemptions.filter((exemption) =>
      exemption.status === 'Expired' ||
      exemption.status === 'Expiring soon' ||
      this.isExpiredDate(exemption.expiryDate) ||
      this.isExpiringSoonDate(exemption.expiryDate)
    ).length;
    this.activeExemptionSet.warnings = this.activeExemptionSetWarnings;
    this.activeExemptionSet.status = 'Draft';
    this.activeExemptionSet.modified = 'Just now';
    if (!this.activeExemptionSet.version.startsWith('Draft')) {
      this.activeExemptionSet.version = `Draft ${this.activeExemptionSet.draftVersion}`;
    }
  }

  private normalizeQuery(query: string): string {
    return query.trim().toLowerCase();
  }

  private toggleId(ids: string[], id: string): string[] {
    return ids.includes(id)
      ? ids.filter((candidate) => candidate !== id)
      : [...ids, id];
  }

  private findIndexedSubstanceMatches(query: string): Substance[] {
    return this.substances.filter((substance) => this.substanceSearchText(substance).includes(query));
  }

  private substanceSearchText(substance: Substance): string {
    return [
      substance.id,
      substance.name,
      substance.cas,
      substance.ec,
      substance.authority,
      substance.aliasNames,
      substance.alternativeIds,
      substance.source,
      substance.created,
      substance.status,
      substance.apiStatus,
      substance.reviewIssue?.label || '',
      substance.reviewIssue?.detail || ''
    ].join(' ').toLowerCase();
  }

  private withSubstanceGovernance(substance: SubstanceSeed, index: number): Substance {
    const aliases = substance.aliasNames || this.defaultAliasNames(substance.name, substance.aliases);
    const reviewIssueKey = this.reviewIssueBySubstanceIndex.get(index);
    return {
      ...substance,
      aliasNames: aliases,
      alternativeIds: substance.alternativeIds || this.defaultAlternativeIds(substance, index),
      created: substance.created || this.defaultCreatedDate(index),
      apiStatus: substance.apiStatus || this.defaultApiStatus(substance),
      reviewIssue: substance.reviewIssue || (reviewIssueKey ? this.createReviewIssue(reviewIssueKey) : undefined)
    };
  }

  private createReviewIssue(key: SubstanceReviewIssueKey): SubstanceReviewIssue {
    const issueMap: Record<SubstanceReviewIssueKey, SubstanceReviewIssue> = {
      duplicate: {
        key: 'duplicate',
        label: 'Duplicate',
        detail: 'Potential duplicate record based on overlapping name, CAS, EC, or alternative ID evidence.',
        resolutionSummary: 'Compare possible matching records before creating or changing the master substance.',
        recommendedAction: 'Decide whether this is a duplicate, an alias for an existing master, or a separate substance.',
        resolutionOptions: ['Merge duplicate', 'Add as alias', 'Keep separate', 'Defer'],
        severity: 'warn',
        priority: 90
      },
      'alias-conflict': {
        key: 'alias-conflict',
        label: 'Alias conflict',
        detail: 'Alias appears to point at more than one master substance and needs reviewer confirmation.',
        resolutionSummary: 'Confirm which master substance owns the alias before saving changes.',
        recommendedAction: 'Assign the alias to the right master, remove it, or leave the conflict in review.',
        resolutionOptions: ['Assign alias', 'Remove alias', 'Keep for review', 'Defer'],
        severity: 'warn',
        priority: 85
      },
      'cas-check': {
        key: 'cas-check',
        label: 'CAS check',
        detail: 'CAS format or check digit needs confirmation before this record can be trusted.',
        resolutionSummary: 'Validate the CAS value against source evidence before it is trusted downstream.',
        recommendedAction: 'Correct the CAS value, mark it unknown, or send the record to staging for follow-up.',
        resolutionOptions: ['Correct CAS', 'Mark unknown', 'Send to staging', 'Defer'],
        severity: 'warn',
        priority: 80
      },
      'ec-check': {
        key: 'ec-check',
        label: 'EC check',
        detail: 'EC number format or check digit needs confirmation before this record can be trusted.',
        resolutionSummary: 'Validate the EC value against source evidence before it is trusted downstream.',
        recommendedAction: 'Correct the EC value, mark it unknown, or send the record to staging for follow-up.',
        resolutionOptions: ['Correct EC', 'Mark unknown', 'Send to staging', 'Defer'],
        severity: 'warn',
        priority: 75
      },
      staged: {
        key: 'staged',
        label: 'Staged intake',
        detail: 'Incoming source data is not yet promoted into the authoritative library.',
        resolutionSummary: 'Treat this as untrusted intake until Regulatory decides how it enters the library.',
        recommendedAction: 'Promote it, link it to an existing master, add it as an alias, reject it, or defer it.',
        resolutionOptions: ['Promote to master', 'Link existing', 'Add alias', 'Reject', 'Defer'],
        severity: 'warn',
        priority: 65
      }
    };

    return { ...issueMap[key] };
  }

  private defaultAliasNames(name: string, aliasCount: number): string {
    const shortName = name.length > 24 ? name.replace(/\(.+?\)/g, '').trim() : name;
    const compactName = shortName
      .split(/\s+/)
      .map((part) => part.charAt(0))
      .join('')
      .toUpperCase();

    const examples = [`${shortName} synonym`, compactName.length > 1 ? compactName : `${shortName} metal`];
    if (aliasCount > 2) {
      examples.push(`${name} alternate name`);
    }
    return examples.slice(0, Math.min(aliasCount || 1, 3)).join('; ');
  }

  private defaultAlternativeIds(substance: SubstanceSeed, index: number): string {
    const authorityPrefix = substance.authority.includes('EPA') ? 'EPA' : 'ECHA';
    const numericId = String(100028320 + index * 137).replace(/(\d{3})(\d{3})(\d+)/, '$1.$2.$3');
    return `${authorityPrefix}-${numericId}; IPC-${String(1752 + index).padStart(4, '0')}`;
  }

  private defaultCreatedDate(index: number): string {
    const months = ['Jan', 'Mar', 'Apr', 'Jun', 'Aug', 'Oct', 'Nov'];
    const month = months[index % months.length];
    const day = String((index % 24) + 3).padStart(2, '0');
    const year = 2018 + (index % 7);
    return `${month} ${day}, ${year}`;
  }

  private defaultApiStatus(substance: Pick<Substance, 'status'>): SubstanceApiStatus {
    if (substance.status === 'Active') {
      return 'Available';
    }
    if (substance.status === 'Staged') {
      return 'Pending validation';
    }
    return 'Blocked';
  }

  private detectBulkContentType(fileName: string): string {
    const name = fileName.toLowerCase();
    if (name.includes('group')) {
      return 'Groups and subgroups';
    }
    if (name.includes('dsl') || name.includes('list')) {
      return 'DSL lists';
    }
    if (name.includes('exemption')) {
      return 'Exemption sets';
    }
    if (name.includes('module')) {
      return 'DSL modules';
    }
    return this.selectedBulkTemplate?.label || 'Content type pending';
  }

  private createSubstanceServiceResults(query: string): Substance[] {
    const titleCaseQuery = query
      .split(/\s+/)
      .filter(Boolean)
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
      .join(' ');

    const catalog = ([
      { id: 'MS-0198842', name: 'Arsenic', cas: '7440-38-2', ec: '231-148-6', authority: 'ECHA, EPA', aliases: 4, source: 'Substance service', status: 'Active', modified: 'Service result', references: { lists: 6, groups: 7, materials: 284 } },
      { id: 'MS-0198843', name: 'Nickel', cas: '7440-02-0', ec: '231-111-4', authority: 'ECHA', aliases: 6, source: 'Substance service', status: 'Active', modified: 'Service result', references: { lists: 9, groups: 8, materials: 493 } },
      { id: 'MS-0198844', name: 'Cobalt dichloride', cas: '7646-79-9', ec: '231-589-4', authority: 'ECHA', aliases: 3, source: 'Substance service', status: 'Active', modified: 'Service result', references: { lists: 7, groups: 5, materials: 176 } },
      { id: 'MS-0198845', name: 'Bisphenol A', cas: '80-05-7', ec: '201-245-8', authority: 'ECHA', aliases: 8, source: 'Substance service', status: 'Active', modified: 'Service result', references: { lists: 12, groups: 4, materials: 802 } },
      { id: 'MS-0198846', name: 'Phenol', cas: '108-95-2', ec: '203-632-7', authority: 'ECHA, EPA', aliases: 5, source: 'Substance service', status: 'Active', modified: 'Service result', references: { lists: 5, groups: 3, materials: 219 } }
    ] as SubstanceSeed[]).map((substance, index) => this.withSubstanceGovernance(substance, index + 90));

    const matches = catalog.filter((substance) => this.substanceSearchText(substance).includes(query));
    if (matches.length) {
      return matches;
    }

    return [
      this.withSubstanceGovernance({
        id: 'MS-SVC-0001',
        name: `${titleCaseQuery || 'Unindexed'} candidate`,
        cas: 'Pending',
        ec: 'Pending',
        authority: 'Service match',
        aliases: 0,
        source: 'Substance service',
        status: 'Staged',
        modified: 'Service result',
        references: { lists: 0, groups: 0, materials: 0 }
      }, 96)
    ];
  }

  private createIndexedSubstanceRows(): Substance[] {
    const seeds: Array<[string, string, string, string, string, Substance['status']]> = [
      ['Acetic acid', '64-19-7', '200-580-7', 'ECHA', 'Assent', 'Active'],
      ['Acrylamide', '79-06-1', '201-173-7', 'ECHA', 'ECHA import', 'Active'],
      ['Aluminum oxide', '1344-28-1', '215-691-6', 'ECHA', 'Assent', 'Active'],
      ['Antimony trioxide', '1309-64-4', '215-175-0', 'ECHA', 'Assent', 'Active'],
      ['Barium sulfate', '7727-43-7', '231-784-4', 'ECHA', 'Assent', 'Active'],
      ['Benzene', '71-43-2', '200-753-7', 'ECHA, EPA', 'EPA', 'Active'],
      ['Beryllium', '7440-41-7', '231-150-7', 'ECHA', 'Assent', 'Active'],
      ['Boric acid', '10043-35-3', '233-139-2', 'ECHA', 'ECHA import', 'Active'],
      ['Carbon black', '1333-86-4', '215-609-9', 'ECHA', 'Assent', 'Active'],
      ['Chloroform', '67-66-3', '200-663-8', 'ECHA, EPA', 'EPA', 'Active'],
      ['Cyclohexane', '110-82-7', '203-806-2', 'ECHA', 'Assent', 'Active'],
      ['Diarsenic trioxide', '1327-53-3', '215-481-4', 'ECHA', 'ECHA import', 'Active'],
      ['Dimethylformamide', '68-12-2', '200-679-5', 'ECHA', 'Assent', 'Active'],
      ['Ethylene glycol', '107-21-1', '203-473-3', 'ECHA', 'Assent', 'Active'],
      ['Hydrazine', '302-01-2', '206-114-9', 'ECHA', 'ECHA import', 'Staged'],
      ['Imidazolidinyl urea', '39236-46-9', '254-372-6', 'ECHA', 'Assent', 'Active'],
      ['Methanol', '67-56-1', '200-659-6', 'ECHA', 'Assent', 'Active'],
      ['Methyl ethyl ketone', '78-93-3', '201-159-0', 'ECHA', 'Assent', 'Active'],
      ['Molybdenum trioxide', '1313-27-5', '215-204-7', 'ECHA', 'ECHA import', 'Active'],
      ['Phenanthrene', '85-01-8', '201-581-5', 'ECHA', 'Assent', 'Active'],
      ['Potassium chromate', '7789-00-6', '232-140-5', 'ECHA', 'ECHA import', 'Active'],
      ['Sodium dichromate', '10588-01-9', '234-190-3', 'ECHA', 'ECHA import', 'Active'],
      ['Styrene', '100-42-5', '202-851-5', 'ECHA, EPA', 'EPA', 'Active'],
      ['Toluene', '108-88-3', '203-625-9', 'ECHA', 'Assent', 'Active'],
      ['Trichloroethylene', '79-01-6', '201-167-4', 'ECHA', 'ECHA import', 'Active'],
      ['Vinyl chloride', '75-01-4', '200-831-0', 'ECHA, EPA', 'EPA', 'Active'],
      ['Zinc borate', '1332-07-6', '215-566-6', 'ECHA', 'Assent', 'Active'],
      ['Cresol', '1319-77-3', '215-293-2', 'ECHA', 'Assent', 'Active'],
      ['1,2-Dichloroethane', '107-06-2', '203-458-1', 'ECHA', 'ECHA import', 'Active'],
      ['2-Methoxyethanol', '109-86-4', '203-713-7', 'ECHA', 'Assent', 'Active'],
      ['Benzidine', '92-87-5', '202-199-1', 'ECHA', 'ECHA import', 'Archived'],
      ['Diethylhexyl adipate', '103-23-1', '203-090-1', 'ECHA', 'Assent', 'Active'],
      ['Ethylene oxide', '75-21-8', '200-849-9', 'ECHA, EPA', 'EPA', 'Active'],
      ['Lead monoxide', '1317-36-8', '215-267-0', 'ECHA', 'Assent', 'Active'],
      ['Potassium dichromate', '7778-50-9', '231-906-6', 'ECHA', 'ECHA import', 'Active'],
      ['Resorcinol', '108-46-3', '203-585-2', 'ECHA', 'Assent', 'Active']
    ];

    return seeds.map(([name, cas, ec, authority, source, status], index) =>
      this.withSubstanceGovernance({
        id: `MS-${String(42837 + index).padStart(7, '0')}`,
        name,
        cas,
        ec,
        authority,
        aliases: (index % 7) + 1,
        source,
        status,
        modified: `${(index % 9) + 1}mo ago`,
        references: {
          lists: (index % 14) + (status === 'Archived' ? 0 : 2),
          groups: (index % 9) + (status === 'Archived' ? 0 : 1),
          materials: status === 'Archived' ? 0 : 80 + index * 23
        }
      }, index + 18)
    );
  }

  private clearSubstanceLoadTimer(): void {
    if (this.substanceLoadTimer) {
      clearTimeout(this.substanceLoadTimer);
      this.substanceLoadTimer = undefined;
    }
  }

  private simulateGroupLoad(mode: GroupLoadMode = 'filter', duration = 280): void {
    this.clearGroupLoadTimer();
    this.groupLoadMode = mode;
    this.isGroupLoading = true;
    this.groupLoadTimer = setTimeout(() => {
      this.isGroupLoading = false;
      this.groupLoadTimer = undefined;
    }, duration);
  }

  private simulateWorkspaceLoad(mode: WorkspaceLoadMode = 'page', duration = 180): void {
    this.clearWorkspaceLoadTimer();
    this.workspaceLoadMode = mode;
    this.isWorkspaceLoading = true;
    this.workspaceLoadTimer = setTimeout(() => {
      this.isWorkspaceLoading = false;
      this.workspaceLoadTimer = undefined;
    }, duration);
  }

  private completeImpactAssessmentGeneration(assessment: ImpactAssessment, candidate: ArchiveCandidateSubstance): void {
    this.clearAssessmentGenerationTimer();
    candidate.status = 'Impact Assessment Generated';
    assessment.status = 'Impact Assessment Generated';
    assessment.generatedDate = this.archiveNowLabel();
    this.assessmentGenerating = false;
    this.assessmentGenerationFailed = false;
    this.assessmentProgress = 100;
    this.assessmentSummaryOpen = true;
    this.addArchiveAuditEvent({
      user: assessment.generatedBy,
      dateTime: assessment.generatedDate,
      action: 'Impact assessment generated',
      object: candidate.substanceName,
      impactSeverity: assessment.overallImpactSeverity,
      decision: 'None',
      rationale: 'Supplier declarations, customer disclosures, match context, and data completeness were calculated before archival.',
      beforeStatus: 'Impact Assessment Generating',
      afterStatus: 'Impact Assessment Generated'
    });
    this.messages.add({
      severity: assessment.overallImpactSeverity === 'High' ? 'warn' : 'success',
      summary: 'Impact assessment generated',
      detail: `${candidate.substanceName} is ready for supplier, customer, match, and limitation review.`
    });
  }

  private createDefaultImpactAssessment(candidate: ArchiveCandidateSubstance): ImpactAssessment {
    return {
      assessmentId: `AIA-17320-${String(this.impactAssessments.length + 1).padStart(3, '0')}`,
      substanceId: candidate.substanceId,
      generatedDate: this.archiveNowLabel(),
      generatedBy: 'Maya Chen',
      status: 'Archive Requested',
      overallImpactSeverity: 'Unknown',
      supplierImpactCount: 0,
      customerImpactCount: 0,
      declarationCount: 0,
      disclosureCount: 0,
      matchContext: 'Name match',
      dataCompleteness: 'Unknown',
      assessmentLimitations: ['Impact data was not indexed for this mock substance.']
    };
  }

  private createDefaultMatchContext(assessment: ImpactAssessment, candidate: ArchiveCandidateSubstance): ArchiveMatchContext {
    return {
      assessmentId: assessment.assessmentId,
      matchType: assessment.matchContext,
      matchedOn: ['Name'],
      matchConfidence: 50,
      CASMatch: Boolean(candidate.CAS),
      ECMatch: Boolean(candidate.EC),
      aliasMatch: candidate.aliases.length > 0,
      nameMatch: true,
      explanation: `This substance appears in downstream records because it was matched using ${candidate.CAS ? 'CAS and name' : 'name or aliases'}.`
    };
  }

  private highestImpactSeverity(severities: ImpactSeverity[]): ImpactSeverity {
    const rank: Record<ImpactSeverity, number> = {
      Low: 1,
      Medium: 2,
      High: 3,
      Unknown: 4
    };
    if (!severities.length) {
      return 'Low';
    }
    return severities.reduce((highest, current) => rank[current] > rank[highest] ? current : highest, 'Low' as ImpactSeverity);
  }

  private archiveNowLabel(): string {
    const now = new Date();
    const date = new Intl.DateTimeFormat('en-CA', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(now);
    const time = new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    }).format(now);
    return `${date} ${time}`;
  }

  private clearGroupLoadTimer(): void {
    if (this.groupLoadTimer) {
      clearTimeout(this.groupLoadTimer);
      this.groupLoadTimer = undefined;
    }
  }

  private clearWorkspaceLoadTimer(): void {
    if (this.workspaceLoadTimer) {
      clearTimeout(this.workspaceLoadTimer);
      this.workspaceLoadTimer = undefined;
    }
  }

  private clearAssessmentGenerationTimer(): void {
    if (this.assessmentGenerationTimer) {
      clearInterval(this.assessmentGenerationTimer);
      this.assessmentGenerationTimer = undefined;
    }
  }
}
